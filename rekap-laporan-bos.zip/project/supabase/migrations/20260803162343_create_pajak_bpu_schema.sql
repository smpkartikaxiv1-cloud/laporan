/*
# Create Pajak BPU (Tax) Management Schema

## Overview
This migration creates the data model for managing tax payment records
(Pajak) associated with BPU (Bukti Pengeluaran Uang) documents. It includes
two interconnected tables: one for tax payment records and one for uploaded
tax receipt files (nota/bukti bayar).

## New Tables

### 1. Pajak_BPU (Tax payment records)
- `id` (uuid, primary key)
- `tax_number` (text, unique, auto-generated tax number e.g. "TAX-BPU01")
- `bpu_number` (text, foreign key -> Transaksi_BPU.no_bpu, ON DELETE CASCADE)
- `jenis_pajak` (text, tax type: PPN, PPh 21, PPh 22, PPh 23, etc.)
- `dasar_pengenaan_pajak` (numeric(18,2), DPP / tax base amount)
- `nominal_pajak` (numeric(18,2), tax amount, manually editable)
- `ntpn` (text, Nomor Tanda Penerimaan Negara)
- `tanggal_setor` (date, payment/settlement date)
- `status` (text, approval status: Draft, Menunggu Persetujuan, Disetujui, Ditolak)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### 2. Nota_Pajak_Files (Uploaded tax receipt files)
- `id` (uuid, primary key)
- `pajak_id` (uuid, foreign key -> Pajak_BPU.id, ON DELETE CASCADE)
- `file_name` (text, original uploaded file name)
- `file_path` (text, storage path in the nota-pajak bucket)
- `file_type` (text, MIME type: application/pdf, image/jpeg, image/png)
- `file_size` (bigint, file size in bytes)
- `created_at` (timestamptz)

## Storage
- Creates a public storage bucket "nota-pajak" for uploading tax receipt files.
  Allowed MIME types: PDF, JPG, PNG. Max file size enforced client-side at 5MB.

## Security
- RLS enabled on both tables.
- This is a single-tenant shared-data app with no Supabase Auth (hardcoded
  admin/admin123 login handled in the frontend). Policies use
  `TO anon, authenticated` with `USING (true)` because the data is
  intentionally shared across the single administrative user.

## Important Notes
1. The `tax_number` is generated client-side in the format "TAX-{bpu_number}"
   (e.g. "TAX-BPU01") and stored uniquely.
2. The `nominal_pajak` column is manually editable by the user even though
   an automatic calculation is provided as a starting point.
3. The `status` column tracks the approval workflow: Draft -> Menunggu
   Persetujuan -> Disetujui (or Ditolak). Only "Disetujui" records can be
  exported/printed.
*/

-- ============================================================
-- Pajak_BPU
-- ============================================================
CREATE TABLE IF NOT EXISTS Pajak_BPU (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tax_number text UNIQUE NOT NULL,
  bpu_number text NOT NULL REFERENCES Transaksi_BPU(no_bpu) ON DELETE CASCADE,
  jenis_pajak text NOT NULL DEFAULT 'PPN',
  dasar_pengenaan_pajak numeric(18,2) NOT NULL DEFAULT 0,
  nominal_pajak numeric(18,2) NOT NULL DEFAULT 0,
  ntpn text NOT NULL DEFAULT '',
  tanggal_setor date NOT NULL DEFAULT CURRENT_DATE,
  status text NOT NULL DEFAULT 'Draft',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE Pajak_BPU ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_pajak" ON Pajak_BPU;
CREATE POLICY "anon_select_pajak" ON Pajak_BPU
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_pajak" ON Pajak_BPU;
CREATE POLICY "anon_insert_pajak" ON Pajak_BPU
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_pajak" ON Pajak_BPU;
CREATE POLICY "anon_update_pajak" ON Pajak_BPU
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_pajak" ON Pajak_BPU;
CREATE POLICY "anon_delete_pajak" ON Pajak_BPU
  FOR DELETE TO anon, authenticated USING (true);

-- ============================================================
-- Nota_Pajak_Files
-- ============================================================
CREATE TABLE IF NOT EXISTS Nota_Pajak_Files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pajak_id uuid NOT NULL REFERENCES Pajak_BPU(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_path text NOT NULL,
  file_type text NOT NULL DEFAULT '',
  file_size bigint NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE Nota_Pajak_Files ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_nota_pajak" ON Nota_Pajak_Files;
CREATE POLICY "anon_select_nota_pajak" ON Nota_Pajak_Files
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_nota_pajak" ON Nota_Pajak_Files;
CREATE POLICY "anon_insert_nota_pajak" ON Nota_Pajak_Files
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_nota_pajak" ON Nota_Pajak_Files;
CREATE POLICY "anon_update_nota_pajak" ON Nota_Pajak_Files
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_nota_pajak" ON Nota_Pajak_Files;
CREATE POLICY "anon_delete_nota_pajak" ON Nota_Pajak_Files
  FOR DELETE TO anon, authenticated USING (true);

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_pajak_bpu_number ON Pajak_BPU(bpu_number);
CREATE INDEX IF NOT EXISTS idx_nota_pajak_id ON Nota_Pajak_Files(pajak_id);

-- ============================================================
-- Storage bucket for tax receipt files
-- ============================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('nota-pajak', 'nota-pajak', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: allow anon + authenticated to manage files in nota-pajak bucket
DROP POLICY IF EXISTS "anon_select_nota_pajak_storage" ON storage.objects;
CREATE POLICY "anon_select_nota_pajak_storage" ON storage.objects
  FOR SELECT TO anon, authenticated USING (bucket_id = 'nota-pajak');

DROP POLICY IF EXISTS "anon_insert_nota_pajak_storage" ON storage.objects;
CREATE POLICY "anon_insert_nota_pajak_storage" ON storage.objects
  FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'nota-pajak');

DROP POLICY IF EXISTS "anon_update_nota_pajak_storage" ON storage.objects;
CREATE POLICY "anon_update_nota_pajak_storage" ON storage.objects
  FOR UPDATE TO anon, authenticated USING (bucket_id = 'nota-pajak') WITH CHECK (bucket_id = 'nota-pajak');

DROP POLICY IF EXISTS "anon_delete_nota_pajak_storage" ON storage.objects;
CREATE POLICY "anon_delete_nota_pajak_storage" ON storage.objects
  FOR DELETE TO anon, authenticated USING (bucket_id = 'nota-pajak');
