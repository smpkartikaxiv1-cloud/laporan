/*
# Create BPU Documents and Document Logs Schema

## Overview
This migration creates two new tables for managing supporting documents
(kwitansi/faktur and foto barang) attached to BPU records, plus a log table
that tracks every upload, replace, and delete action.

## New Tables

### 1. bpu_documents
Stores uploaded document files linked to a BPU via a one-to-many relationship.
- `id` (uuid, primary key)
- `bpu_number` (text, foreign key -> transaksi_bpu.no_bpu, ON DELETE CASCADE)
- `doc_type` (text, category: "kwitansi" or "foto_barang")
- `file_name` (text, original uploaded file name)
- `file_path` (text, storage path in the bpu-documents bucket)
- `file_type` (text, MIME type)
- `file_size` (bigint, file size in bytes)
- `created_at` (timestamptz)

### 2. bpu_document_logs
Audit trail for every document action (upload, replace, delete).
- `id` (uuid, primary key)
- `bpu_number` (text, foreign key -> transaksi_bpu.no_bpu, ON DELETE CASCADE)
- `file_name` (text, name of the file involved in the action)
- `action` (text, "upload", "replace", or "delete")
- `user_name` (text, name of the user performing the action)
- `created_at` (timestamptz)

## Storage
- Creates a public storage bucket "bpu-documents" for uploading supporting files.
  Allowed MIME types: PDF, JPG, PNG. Max file size enforced client-side at 5MB.

## Security
- RLS enabled on both tables.
- Single-tenant shared-data app (no Supabase Auth). Policies use
  `TO anon, authenticated` with `USING (true)` because data is intentionally
  shared across the single administrative user.

## Important Notes
1. All document uploads are optional — BPU records can be saved without any documents.
2. The `doc_type` column distinguishes between receipt/invoice files ("kwitansi")
   and item photos ("foto_barang").
3. The log table records who changed what and when, providing a full audit trail.
*/

-- ============================================================
-- bpu_documents
-- ============================================================
CREATE TABLE IF NOT EXISTS bpu_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bpu_number text NOT NULL REFERENCES transaksi_bpu(no_bpu) ON DELETE CASCADE,
  doc_type text NOT NULL DEFAULT 'kwitansi',
  file_name text NOT NULL,
  file_path text NOT NULL,
  file_type text NOT NULL DEFAULT '',
  file_size bigint NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE bpu_documents ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_bpu_docs" ON bpu_documents;
CREATE POLICY "anon_select_bpu_docs" ON bpu_documents
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_bpu_docs" ON bpu_documents;
CREATE POLICY "anon_insert_bpu_docs" ON bpu_documents
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_bpu_docs" ON bpu_documents;
CREATE POLICY "anon_update_bpu_docs" ON bpu_documents
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_bpu_docs" ON bpu_documents;
CREATE POLICY "anon_delete_bpu_docs" ON bpu_documents
  FOR DELETE TO anon, authenticated USING (true);

-- ============================================================
-- bpu_document_logs
-- ============================================================
CREATE TABLE IF NOT EXISTS bpu_document_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bpu_number text NOT NULL REFERENCES transaksi_bpu(no_bpu) ON DELETE CASCADE,
  file_name text NOT NULL,
  action text NOT NULL DEFAULT 'upload',
  user_name text NOT NULL DEFAULT 'Admin',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE bpu_document_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_bpu_doc_logs" ON bpu_document_logs;
CREATE POLICY "anon_select_bpu_doc_logs" ON bpu_document_logs
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_bpu_doc_logs" ON bpu_document_logs;
CREATE POLICY "anon_insert_bpu_doc_logs" ON bpu_document_logs
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_bpu_doc_logs" ON bpu_document_logs;
CREATE POLICY "anon_update_bpu_doc_logs" ON bpu_document_logs
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_bpu_doc_logs" ON bpu_document_logs;
CREATE POLICY "anon_delete_bpu_doc_logs" ON bpu_document_logs
  FOR DELETE TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_bpu_docs_bpu_number ON bpu_documents(bpu_number);
CREATE INDEX IF NOT EXISTS idx_bpu_doc_logs_bpu_number ON bpu_document_logs(bpu_number);

-- ============================================================
-- Storage bucket for BPU supporting documents
-- ============================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('bpu-documents', 'bpu-documents', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies
DROP POLICY IF EXISTS "anon_select_bpu_docs_storage" ON storage.objects;
CREATE POLICY "anon_select_bpu_docs_storage" ON storage.objects
  FOR SELECT TO anon, authenticated USING (bucket_id = 'bpu-documents');

DROP POLICY IF EXISTS "anon_insert_bpu_docs_storage" ON storage.objects;
CREATE POLICY "anon_insert_bpu_docs_storage" ON storage.objects
  FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'bpu-documents');

DROP POLICY IF EXISTS "anon_update_bpu_docs_storage" ON storage.objects;
CREATE POLICY "anon_update_bpu_docs_storage" ON storage.objects
  FOR UPDATE TO anon, authenticated USING (bucket_id = 'bpu-documents') WITH CHECK (bucket_id = 'bpu-documents');

DROP POLICY IF EXISTS "anon_delete_bpu_docs_storage" ON storage.objects;
CREATE POLICY "anon_delete_bpu_docs_storage" ON storage.objects
  FOR DELETE TO anon, authenticated USING (bucket_id = 'bpu-documents');
