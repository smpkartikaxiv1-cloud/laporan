/*
# Create SPJ Document Management Schema for SMP Kartika XIV-1 Banda Aceh

## Overview
This migration creates the complete data model for managing Dana BOS expense
documents (SPJ) grouped by BPU (Bukti Pengeluaran Uang). It includes four
interconnected tables plus seed data for default officers.

## New Tables

### 1. Master_Pejabat (Officer master data)
- `id` (uuid, primary key)
- `peran` (text, role name e.g. "Kepala Sekolah", "Bendahara BOSP", "Pengurus Barang")
- `nama` (text, officer full name, editable via Settings page)
- `nip` (text, officer NIP number, editable via Settings page)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### 2. Master_Vendor (Vendor/shop master data)
- `id` (uuid, primary key)
- `nama_toko` (text, shop name e.g. "CV. DUNIA KOMPUTER")
- `alamat_toko` (text, shop address)
- `telepon` (text, shop phone number)
- `created_at` (timestamptz)

### 3. Transaksi_BPU (BPU header)
- `no_bpu` (text, primary key / unique, e.g. "BPU01")
- `tanggal_pesanan` (date, order date)
- `tanggal_pembayaran` (date, payment date)
- `kode_kegiatan` (text, activity code e.g. "06.05.09.")
- `kode_rekening` (text, account code e.g. "5.1.02.01.01.0030")
- `vendor_id` (uuid, foreign key -> Master_Vendor.id)
- `created_at` (timestamptz)

### 4. Detail_Barang_BPU (BPU line items)
- `id` (uuid, primary key)
- `bpu_id` (text, foreign key -> Transaksi_BPU.no_bpu, ON DELETE CASCADE)
- `nama_barang` (text, item name)
- `banyak_nya` (integer, quantity)
- `satuan` (text, unit e.g. "Unit", "buah", "kotak", "pack")
- `harga_satuan` (numeric(18,2), unit price)
- `pengeluaran` (numeric(18,2), computed: banyak_nya * harga_satuan)
- `created_at` (timestamptz)

## Security
- RLS enabled on all tables.
- This app uses a hardcoded admin login (admin/admin123) handled entirely in
  the frontend; it is a single-tenant shared-data app with no Supabase Auth.
  Policies use `TO anon, authenticated` with `USING (true)` because the data
  is intentionally shared across the single administrative user.

## Seed Data
- Master_Pejabat seeded with three default officers (Kepala Sekolah,
  Bendahara BOSP, Pengurus Barang).
*/

-- ============================================================
-- Master_Pejabat
-- ============================================================
CREATE TABLE IF NOT EXISTS Master_Pejabat (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  peran text NOT NULL UNIQUE,
  nama text NOT NULL,
  nip text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE Master_Pejabat ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_pejabat" ON Master_Pejabat;
CREATE POLICY "anon_select_pejabat" ON Master_Pejabat
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_pejabat" ON Master_Pejabat;
CREATE POLICY "anon_insert_pejabat" ON Master_Pejabat
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_pejabat" ON Master_Pejabat;
CREATE POLICY "anon_update_pejabat" ON Master_Pejabat
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_pejabat" ON Master_Pejabat;
CREATE POLICY "anon_delete_pejabat" ON Master_Pejabat
  FOR DELETE TO anon, authenticated USING (true);

-- ============================================================
-- Master_Vendor
-- ============================================================
CREATE TABLE IF NOT EXISTS Master_Vendor (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nama_toko text NOT NULL,
  alamat_toko text NOT NULL DEFAULT '',
  telepon text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE Master_Vendor ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_vendor" ON Master_Vendor;
CREATE POLICY "anon_select_vendor" ON Master_Vendor
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_vendor" ON Master_Vendor;
CREATE POLICY "anon_insert_vendor" ON Master_Vendor
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_vendor" ON Master_Vendor;
CREATE POLICY "anon_update_vendor" ON Master_Vendor
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_vendor" ON Master_Vendor;
CREATE POLICY "anon_delete_vendor" ON Master_Vendor
  FOR DELETE TO anon, authenticated USING (true);

-- ============================================================
-- Transaksi_BPU
-- ============================================================
CREATE TABLE IF NOT EXISTS Transaksi_BPU (
  no_bpu text PRIMARY KEY,
  tanggal_pesanan date NOT NULL,
  tanggal_pembayaran date NOT NULL,
  kode_kegiatan text NOT NULL DEFAULT '',
  kode_rekening text NOT NULL DEFAULT '',
  vendor_id uuid REFERENCES Master_Vendor(id) ON DELETE RESTRICT,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE Transaksi_BPU ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_bpu" ON Transaksi_BPU;
CREATE POLICY "anon_select_bpu" ON Transaksi_BPU
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_bpu" ON Transaksi_BPU;
CREATE POLICY "anon_insert_bpu" ON Transaksi_BPU
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_bpu" ON Transaksi_BPU;
CREATE POLICY "anon_update_bpu" ON Transaksi_BPU
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_bpu" ON Transaksi_BPU;
CREATE POLICY "anon_delete_bpu" ON Transaksi_BPU
  FOR DELETE TO anon, authenticated USING (true);

-- ============================================================
-- Detail_Barang_BPU
-- ============================================================
CREATE TABLE IF NOT EXISTS Detail_Barang_BPU (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bpu_id text NOT NULL REFERENCES Transaksi_BPU(no_bpu) ON DELETE CASCADE,
  nama_barang text NOT NULL,
  banyak_nya integer NOT NULL DEFAULT 0,
  satuan text NOT NULL DEFAULT '',
  harga_satuan numeric(18,2) NOT NULL DEFAULT 0,
  pengeluaran numeric(18,2) GENERATED ALWAYS AS (banyak_nya * harga_satuan) STORED,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE Detail_Barang_BPU ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_detail" ON Detail_Barang_BPU;
CREATE POLICY "anon_select_detail" ON Detail_Barang_BPU
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_detail" ON Detail_Barang_BPU;
CREATE POLICY "anon_insert_detail" ON Detail_Barang_BPU
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_detail" ON Detail_Barang_BPU;
CREATE POLICY "anon_update_detail" ON Detail_Barang_BPU
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_detail" ON Detail_Barang_BPU;
CREATE POLICY "anon_delete_detail" ON Detail_Barang_BPU
  FOR DELETE TO anon, authenticated USING (true);

-- Index for faster lookups of line items by BPU
CREATE INDEX IF NOT EXISTS idx_detail_bpu_id ON Detail_Barang_BPU(bpu_id);

-- ============================================================
-- Seed Master_Pejabat with default officers
-- ============================================================
INSERT INTO Master_Pejabat (peran, nama, nip) VALUES
  ('Kepala Sekolah', 'Sabriadi, S.Pd', '197705092007011016'),
  ('Bendahara BOSP', 'Rina Diana, S.Pd.I., M.Pd', '198007302006042014'),
  ('Pengurus Barang', 'Khairuddin, S.Sos', '198004242005011007')
ON CONFLICT (peran) DO NOTHING;
