/*
# Add pph column to detail_barang_bpu and make nama_toko unique

## Changes
### detail_barang_bpu
- Added `pph` (text, nullable) — stores PPh withholding info per line item.

### master_vendor
- Added UNIQUE constraint on `nama_toko` to prevent duplicates.
  The Excel upload engine relies on this to safely upsert vendors by name.

## Notes
- Both changes are additive and non-destructive.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'detail_barang_bpu' AND column_name = 'pph'
  ) THEN
    ALTER TABLE detail_barang_bpu ADD COLUMN pph text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'master_vendor_nama_toko_key'
  ) THEN
    ALTER TABLE master_vendor ADD CONSTRAINT master_vendor_nama_toko_key UNIQUE (nama_toko);
  END IF;
END $$;
