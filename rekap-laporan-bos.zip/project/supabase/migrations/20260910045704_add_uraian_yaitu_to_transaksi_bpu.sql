/*
# Add uraian_yaitu column to transaksi_bpu

1. Changes
- Add `uraian_yaitu` column (text, nullable) to `transaksi_bpu`.
  This column stores a custom override for the "YAITU" text shown on
  Tanda Penerimaan documents. When NULL, the system auto-generates
  the text from item names. When set, the custom text is used instead.

2. Security
- No RLS policy changes needed. The table already has existing policies.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transaksi_bpu'
    AND column_name = 'uraian_yaitu'
  ) THEN
    ALTER TABLE transaksi_bpu ADD COLUMN uraian_yaitu text;
  END IF;
END $$;