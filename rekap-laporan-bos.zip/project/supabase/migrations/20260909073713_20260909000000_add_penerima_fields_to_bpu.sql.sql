/*
# Add Penerima (Receiver) Fields to transaksi_bpu

## Overview
Adds three new columns to `transaksi_bpu` to store the receiver data
printed on the "Yang menerima" block of the Tanda Penerimaan document.
Previously the document pulled receiver name/address from the linked
vendor; now the user can fill them manually or pick a vendor from a
dropdown, and the chosen values are persisted on the BPU itself.

## Modified Tables
### transaksi_bpu
- `penerima_nama` (text, not null, default '') — Nama penerima on the
  "Yang menerima" section. Free text, user-editable.
- `penerima_pekerjaan` (text, not null, default '') — Nama tempat
  pembelian / vendor label. Can be a vendor name (from dropdown) or a
  manually typed value.
- `penerima_alamat` (text, not null, default '') — Alamat penerima.
  Auto-filled when a vendor is picked, but editable.

## Security
- No new tables. Existing RLS policies on transaksi_bpu already cover
  the new columns (they are standard text columns with no privilege
  restrictions). No policy changes required.

## Notes
- Columns default to '' so existing rows and inserts that omit them
  remain valid (backward compatible).
- The frontend will populate these fields either from the selected
  vendor (nama_toko / alamat_toko) or from manual user input.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transaksi_bpu' AND column_name = 'penerima_nama'
  ) THEN
    ALTER TABLE transaksi_bpu ADD COLUMN penerima_nama text NOT NULL DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transaksi_bpu' AND column_name = 'penerima_pekerjaan'
  ) THEN
    ALTER TABLE transaksi_bpu ADD COLUMN penerima_pekerjaan text NOT NULL DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'transaksi_bpu' AND column_name = 'penerima_alamat'
  ) THEN
    ALTER TABLE transaksi_bpu ADD COLUMN penerima_alamat text NOT NULL DEFAULT '';
  END IF;
END $$;
