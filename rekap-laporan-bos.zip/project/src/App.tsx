import { useState } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { LogoProvider } from '@/context/LogoContext';
import { SchoolProvider } from '@/context/SchoolContext';
import AppLayout, { PageKey } from '@/components/AppLayout';
import LoginPage from '@/pages/LoginPage';
import DashboardPage from '@/pages/DashboardPage';
import CreateBpuPage from '@/pages/CreateBpuPage';
import VendorsPage from '@/pages/VendorsPage';
import SettingsPage from '@/pages/SettingsPage';
import PajakPage from '@/pages/PajakPage';
import RekapDokumenPage from '@/pages/RekapDokumenPage';
import LaporanRekapPage from '@/pages/LaporanRekapPage';
import PanduanPage from '@/pages/PanduanPage';

function AppContent() {
  const { isAuthenticated } = useAuth();
  const [page, setPage] = useState<PageKey>('dashboard');

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  function handleNavigate(p: PageKey) {
    setPage(p);
  }

  return (
    <AppLayout current={page} onNavigate={handleNavigate}>
      {page === 'dashboard' && (
        <DashboardPage onCreateNew={() => setPage('create')} />
      )}
      {page === 'create' && (
        <CreateBpuPage
          onDone={() => setPage('dashboard')}
          onCancel={() => setPage('dashboard')}
        />
      )}
      {page === 'vendors' && <VendorsPage />}
      {page === 'pajak' && <PajakPage />}
      {page === 'rekap' && <RekapDokumenPage />}
      {page === 'laporan' && <LaporanRekapPage />}
      {page === 'settings' && <SettingsPage />}
      {page === 'panduan' && <PanduanPage />}
    </AppLayout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <LogoProvider>
        <SchoolProvider>
          <AppContent />
        </SchoolProvider>
      </LogoProvider>
    </AuthProvider>
  );
}
