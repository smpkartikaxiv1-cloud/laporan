import { ReactNode, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useSchoolIdentity } from '@/context/SchoolContext';
import { LayoutDashboard, FilePlus, Store, Settings, LogOut, Menu, X, ShieldCheck, Receipt, FolderArchive, ClipboardList, BookOpen } from 'lucide-react';

export type PageKey = 'dashboard' | 'create' | 'vendors' | 'settings' | 'pajak' | 'rekap' | 'laporan' | 'panduan';

interface LayoutProps {
  current: PageKey;
  onNavigate: (page: PageKey) => void;
  children: ReactNode;
}

const NAV_ITEMS: { key: PageKey; label: string; icon: typeof LayoutDashboard }[] = [
  { key: 'dashboard', label: 'Dashboard BPU', icon: LayoutDashboard },
  { key: 'create', label: 'Input BPU Baru', icon: FilePlus },
  { key: 'vendors', label: 'Data Vendor', icon: Store },
  { key: 'pajak', label: 'Form Pajak', icon: Receipt },
  { key: 'rekap', label: 'Rekap Dokumen', icon: FolderArchive },
  { key: 'laporan', label: 'Laporan Rekap BPU', icon: ClipboardList },
  { key: 'settings', label: 'Pengaturan Pejabat', icon: Settings },
  { key: 'panduan', label: 'Panduan Penggunaan', icon: BookOpen },
];

export default function AppLayout({ current, onNavigate, children }: LayoutProps) {
  const { logout } = useAuth();
  const { identity: school } = useSchoolIdentity();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNav = (page: PageKey) => {
    onNavigate(page);
    setMobileOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-slate-900/50 z-30 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 left-0 z-40 h-screen w-64 bg-slate-900 text-slate-300 flex flex-col transition-transform duration-300 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Logo */}
        <div className="px-6 py-6 border-b border-slate-700/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-white font-bold text-sm leading-tight">SPJ BOS Manager</h1>
              <p className="text-slate-400 text-xs">{school.namaSekolah}</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = current === item.key;
            return (
              <button
                key={item.key}
                onClick={() => handleNav(item.key)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                  active
                    ? 'bg-gradient-to-r from-amber-500/20 to-amber-600/10 text-amber-400 shadow-inner'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-5 h-5 ${active ? 'text-amber-400' : ''}`} />
                {item.label}
                {active && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-amber-400" />}
              </button>
            );
          })}
        </nav>

        {/* Logout */}
        <div className="px-3 py-4 border-t border-slate-700/50">
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition"
          >
            <LogOut className="w-5 h-5" />
            Keluar
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile header */}
        <header className="lg:hidden sticky top-0 z-20 bg-slate-900 text-white px-4 py-3 flex items-center justify-between shadow-md">
          <button onClick={() => setMobileOpen(true)} className="p-1.5 rounded-lg hover:bg-slate-800">
            <Menu className="w-6 h-6" />
          </button>
          <span className="font-semibold text-sm">SPJ BOS Manager</span>
          <div className="w-8" />
        </header>

        {/* Mobile menu panel */}
        {mobileOpen && (
          <div className="lg:hidden fixed top-0 left-0 z-50 h-screen w-64 bg-slate-900 text-slate-300 flex flex-col">
            <div className="flex items-center justify-between px-6 py-6 border-b border-slate-700/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
                  <ShieldCheck className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-white font-bold text-sm">SPJ BOS Manager</h1>
                  <p className="text-slate-400 text-xs">{school.namaSekolah}</p>
                </div>
              </div>
              <button onClick={() => setMobileOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 px-3 py-4 space-y-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = current === item.key;
                return (
                  <button
                    key={item.key}
                    onClick={() => handleNav(item.key)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition ${
                      active ? 'bg-amber-500/20 text-amber-400' : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {item.label}
                  </button>
                );
              })}
            </nav>
            <div className="px-3 py-4 border-t border-slate-700/50">
              <button
                onClick={logout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition"
              >
                <LogOut className="w-5 h-5" />
                Keluar
              </button>
            </div>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">{children}</main>
      </div>
    </div>
  );
}
