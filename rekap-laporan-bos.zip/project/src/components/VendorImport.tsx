import { useState, useRef, useCallback } from 'react';
import * as XLSX from 'xlsx';
import { supabase } from '@/lib/supabase';
import { BpuFull } from '@/lib/types';
import {
  Building2, Upload, Download, X, Loader2, AlertCircle, CheckCircle2, FileSpreadsheet,
} from 'lucide-react';

interface VendorImportProps {
  bpus: BpuFull[];
  onImported: () => void;
}

interface VendorRow {
  no_bpu: string;
  nama_perusahaan: string;
  alamat: string;
  pimpinan: string;
}

export default function VendorImport({ bpus, onImported }: VendorImportProps) {
  const [showModal, setShowModal] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const [fileName, setFileName] = useState('');
  const [parsedCount, setParsedCount] = useState<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const reset = useCallback(() => {
    setError('');
    setSuccess('');
    setFileName('');
    setParsedCount(null);
  }, []);

  function downloadTemplate() {
    const headers = ['NO. BPU', 'NAMA PERUSAHAAN', 'ALAMAT', 'PIMPINAN'];
    const sampleRow = ['BPU01', 'CV. CONTOH SEJAHTERA', 'Jl. Contoh No. 123, Banda Aceh', 'Budi Santoso'];
    const ws = XLSX.utils.aoa_to_sheet([headers, sampleRow]);
    ws['!cols'] = [{ wch: 12 }, { wch: 30 }, { wch: 40 }, { wch: 20 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Template Vendor');
    XLSX.writeFile(wb, 'Template_Import_Vendor_Pihak_Kedua.xlsx');
  }

  function normalizeHeader(header: string): string {
    const h = header.toLowerCase().trim().replace(/[\s._\-]+/g, '_').replace(/^_+|_+$/g, '');
    const map: Record<string, string> = {
      'no_bpu': 'no_bpu', 'no': 'no_bpu', 'nomor_bpu': 'no_bpu', 'bpu': 'no_bpu', 'nomor': 'no_bpu',
      'nama_perusahaan': 'nama_perusahaan', 'perusahaan': 'nama_perusahaan', 'nama_toko': 'nama_perusahaan', 'toko': 'nama_perusahaan', 'vendor': 'nama_perusahaan', 'nama_vendor': 'nama_perusahaan', 'pihak_kedua': 'nama_perusahaan',
      'alamat': 'alamat', 'alamat_toko': 'alamat', 'alamat_perusahaan': 'alamat', 'alamat_vendor': 'alamat',
      'pimpinan': 'pimpinan', 'nama_pimpinan': 'pimpinan', 'kepala': 'pimpinan', 'penanggung_jawab': 'pimpinan',
    };
    return map[h] || h;
  }

  function isRowEmpty(row: Record<string, unknown>): boolean {
    return Object.values(row).every((v) => String(v ?? '').trim() === '');
  }

  async function processFile(file: File) {
    setProcessing(true);
    setError('');
    setSuccess('');

    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(firstSheet, { defval: '' });

      if (rawRows.length === 0) {
        throw new Error('File Excel kosong atau tidak memiliki data.');
      }

      // Normalize headers (case-insensitive, ignores spaces/dots/dashes)
      const normalizedRows: Record<string, unknown>[] = [];
      for (const row of rawRows) {
        if (isRowEmpty(row)) continue; // skip empty rows
        const newRow: Record<string, unknown> = {};
        for (const key of Object.keys(row)) {
          newRow[normalizeHeader(key)] = row[key];
        }
        normalizedRows.push(newRow);
      }

      // Parse vendor rows with trim on all cell values
      const vendorRows: VendorRow[] = normalizedRows
        .map((r) => ({
          no_bpu: String(r['no_bpu'] ?? '').trim(),
          nama_perusahaan: String(r['nama_perusahaan'] ?? '').trim(),
          alamat: String(r['alamat'] ?? '').trim(),
          pimpinan: String(r['pimpinan'] ?? '').trim(),
        }))
        .filter((r) => r.no_bpu && r.nama_perusahaan);

      setParsedCount(vendorRows.length);

      if (vendorRows.length === 0) {
        throw new Error('Tidak ada baris valid. Pastikan kolom NO. BPU dan NAMA PERUSAHAAN terisi.');
      }

      // Match against existing BPUs
      const existingBpuSet = new Set(bpus.map((b) => b.no_bpu));
      const matched = vendorRows.filter((r) => existingBpuSet.has(r.no_bpu));
      const unmatched = vendorRows.filter((r) => !existingBpuSet.has(r.no_bpu));

      if (matched.length === 0) {
        const unmatchedList = vendorRows.map((r) => r.no_bpu).join(', ');
        throw new Error(`Tidak ada NO. BPU yang cocok. BPU di Excel: ${unmatchedList}. Pastikan NO. BPU sudah ada di dashboard.`);
      }

      // Collect unique vendor names (nama_perusahaan) from matched rows
      const vendorInfoMap = new Map<string, { nama: string; alamat: string; pimpinan: string }>();
      for (const r of matched) {
        if (!vendorInfoMap.has(r.nama_perusahaan)) {
          vendorInfoMap.set(r.nama_perusahaan, { nama: r.nama_perusahaan, alamat: r.alamat, pimpinan: r.pimpinan });
        }
      }

      // Fetch existing vendors to avoid duplicates
      const { data: existingVendors } = await supabase.from('master_vendor').select('*');
      const vendorByName = new Map<string, { id: string }>();
      (existingVendors || []).forEach((v: { id: string; nama_toko: string }) => vendorByName.set(v.nama_toko, { id: v.id }));

      // Create missing vendors
      for (const [nama, info] of vendorInfoMap) {
        if (!vendorByName.has(nama)) {
          const { data: newVendor, error } = await supabase
            .from('master_vendor')
            .insert({ nama_toko: nama, alamat_toko: info.alamat, telepon: '' })
            .select('*')
            .single();
          if (!error && newVendor) {
            vendorByName.set(nama, { id: (newVendor as { id: string }).id });
          }
        }
      }

      // Update each matched BPU with vendor_id
      let updateCount = 0;
      for (const r of matched) {
        const vendor = vendorByName.get(r.nama_perusahaan);
        if (!vendor) continue;
        const { error: updateError } = await supabase
          .from('transaksi_bpu')
          .update({ vendor_id: vendor.id })
          .eq('no_bpu', r.no_bpu);
        if (!updateError) updateCount++;
      }

      let msg = `Berhasil memperbarui ${updateCount} data vendor berdasarkan BPU`;
      if (unmatched.length > 0) {
        msg += `. ${unmatched.length} BPU tidak ditemukan di dashboard (${unmatched.map((r) => r.no_bpu).join(', ')}).`;
      }
      setSuccess(msg);
      onImported();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal memproses file Excel');
    }
    setProcessing(false);
  }

  function handleFileSelect(file: File | undefined) {
    if (!file) return;
    const validExts = ['.xlsx', '.xls', '.csv'];
    const ext = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    if (!validExts.includes(ext)) {
      setError('Format file tidak didukung. Gunakan .xlsx, .xls, atau .csv');
      return;
    }
    setFileName(file.name);
    setParsedCount(null);
    processFile(file);
  }

  return (
    <>
      <button
        onClick={() => { reset(); setShowModal(true); }}
        className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-indigo-600 text-white font-semibold text-sm shadow-lg shadow-indigo-500/20 hover:from-indigo-600 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 transition"
      >
        <Building2 className="w-4 h-4" />
        Import Excel Pihak Kedua
      </button>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-indigo-100 flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-slate-800">Import Data Vendor (Pihak Kedua)</h2>
                  <p className="text-xs text-slate-500">Sinkronkan vendor ke BPU berdasarkan NO. BPU</p>
                </div>
              </div>
              <button
                onClick={() => { setShowModal(false); reset(); }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              {/* Template Download */}
              <div className="flex items-center justify-between rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3">
                <div className="flex items-center gap-2.5">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-emerald-800">Download Template Excel</p>
                    <p className="text-xs text-emerald-600">Kolom: NO. BPU, NAMA PERUSAHAAN, ALAMAT, PIMPINAN</p>
                  </div>
                </div>
                <button
                  onClick={downloadTemplate}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 text-white font-medium text-xs hover:bg-emerald-700 transition shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  Template
                </button>
              </div>

              {/* Upload Area */}
              <div
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragOver(false);
                  handleFileSelect(e.dataTransfer.files?.[0]);
                }}
                onClick={() => inputRef.current?.click()}
                className={`relative border-2 border-dashed rounded-xl px-6 py-10 text-center cursor-pointer transition ${
                  dragOver ? 'border-indigo-500 bg-indigo-50' : 'border-slate-300 hover:border-indigo-400 hover:bg-slate-50'
                }`}
              >
                <input
                  ref={inputRef}
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  className="hidden"
                  onChange={(e) => handleFileSelect(e.target.files?.[0])}
                />
                {processing ? (
                  <div className="flex flex-col items-center gap-2">
                    <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
                    <p className="text-sm text-slate-600">Memproses {fileName}...</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <Upload className="w-8 h-8 text-slate-400" />
                    <p className="text-sm font-medium text-slate-600">
                      Klik atau seret file Excel ke sini
                    </p>
                    <p className="text-xs text-slate-400">Mendukung .xlsx, .xls, .csv</p>
                  </div>
                )}
              </div>

              {/* Parsed count log */}
              {parsedCount !== null && parsedCount > 0 && !error && (
                <div className="flex items-center gap-2.5 rounded-xl bg-blue-50 border border-blue-200 px-4 py-3 text-sm text-blue-700">
                  <FileSpreadsheet className="w-4 h-4 flex-shrink-0" />
                  <span>Terdeteksi {parsedCount} baris data siap disinkronkan</span>
                </div>
              )}

              {/* Error */}
              {error && (
                <div className="flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
                  <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              {/* Success */}
              {success && (
                <div className="flex items-start gap-2.5 rounded-xl bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-700">
                  <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <span>{success}</span>
                </div>
              )}

              {/* Info */}
              <div className="rounded-xl bg-slate-50 border border-slate-200 px-4 py-3">
                <p className="text-xs text-slate-600 leading-relaxed">
                  <strong className="text-slate-700">Cara kerja:</strong> Sistem akan membaca kolom NO. BPU dari Excel,
                  mencocokkannya dengan data BPU yang sudah ada di dashboard, lalu memperbarui kolom Vendor (Pihak Kedua)
                  secara massal. Data pesanan, tanggal, dan total nominal yang sudah tercatat tidak akan berubah.
                </p>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex justify-end gap-3 px-6 py-4 border-t border-slate-100 bg-slate-50/50">
              <button
                onClick={() => { setShowModal(false); reset(); }}
                className="px-4 py-2.5 rounded-xl text-slate-600 font-medium text-sm hover:bg-slate-100 transition"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
