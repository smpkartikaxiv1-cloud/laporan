import { BpuFull, Pejabat } from '@/lib/types';
import { ALL_DOC_TYPES, renderDoc } from '@/components/DocTemplates';

interface PrintBundleProps {
  bpu: BpuFull;
  pejabat: Record<string, Pejabat>;
}

export default function PrintBundle({ bpu, pejabat }: PrintBundleProps) {
  return (
    <div style={{ fontFamily: "'Arial',sans-serif", color: '#000', maxWidth: '800px', margin: '0 auto' }}>
      {ALL_DOC_TYPES.map((type) => (
        <div key={type} className="print-page">
          {renderDoc(type, { bpu, pejabat })}
        </div>
      ))}
    </div>
  );
}
