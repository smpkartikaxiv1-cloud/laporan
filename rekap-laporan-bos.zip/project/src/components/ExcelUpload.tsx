import { useState, useRef, useCallback } from 'react';
import * as XLSX from 'xlsx';
import { supabase } from '@/lib/supabase';
import { Vendor, BPU, DetailBarang } from '@/lib/types';
import {
  UploadCloud, FileSpreadsheet, Loader2, AlertCircle, CheckCircle,
  X, FileUp,
} from 'lucide-react';

interface ParsedRow {
  no_bpu: string;
  tanggal_pesanan: string;
  tanggal_pembayaran: string;
  kode_kegiatan: string;
  kode_rekening: string;
  nama_toko: string;
  alamat_toko: string;
  telepon: string;
  nama_barang: string;
  banyak_nya: number;
  satuan: string;
  harga_satuan: number;
  pph: string;
}

interface UploadResult {
  bpuCount: number;
  itemCount: number;
  vendorCount: number;
}

interface ExcelUploadProps {
  onUploaded: () => void;
}

export default function ExcelUpload({ onUploaded }: ExcelUploadProps) {
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<UploadResult | null>(null);
  const [fileName, setFileName] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const reset = useCallback(() => {
    setError('');
    setResult(null);
    setFileName('');
  }, []);

  // Normalize various possible column names from the school's Excel log
  function normalizeHeader(header: string): string {
    const h = header.toLowerCase().trim().replace(/\s+/g, '_').replace(/_+/g, '_');
    const map: Record<string, string> = {
      'no_bpu': 'no_bpu', 'no.': 'no_bpu', 'no': 'no_bpu', 'nomor_bpu': 'no_bpu', 'bpu': 'no_bpu', 'nomor': 'no_bpu',
      'tanggal_pesanan': 'tanggal_pesanan', 'tgl_pesanan': 'tanggal_pesanan', 'tgl_pesan': 'tanggal_pesanan', 'tanggal': 'tanggal_pesanan', 'tgl': 'tanggal_pesanan',
      'tanggal_pembayaran': 'tanggal_pembayaran', 'tgl_pembayaran': 'tanggal_pembayaran', 'tgl_bayar': 'tanggal_pembayaran', 'tanggal_bayar': 'tanggal_pembayaran',
      'kode_kegiatan': 'kode_kegiatan', 'kd_kegiatan': 'kode_kegiatan', 'kegiatan': 'kode_kegiatan',
      'kode_rekening': 'kode_rekening', 'kd_rekening': 'kode_rekening', 'rekening': 'kode_rekening', 'kode_rek': 'kode_rekening', 'kd_rek': 'kode_rekening', 'rek': 'kode_rekening',
      'nama_toko': 'nama_toko', 'toko': 'nama_toko', 'vendor': 'nama_toko', 'nama_vendor': 'nama_toko', 'perusahaan': 'nama_toko', 'supplier': 'nama_toko',
      'alamat_toko': 'alamat_toko', 'alamat': 'alamat_toko', 'alamat_vendor': 'alamat_toko',
      'telepon': 'telepon', 'telp': 'telepon', 'no_telp': 'telepon', 'phone': 'telepon', 'no_telepon': 'telepon', 'hp': 'telepon',
      'nama_barang': 'nama_barang', 'barang': 'nama_barang', 'jenis_barang': 'nama_barang', 'uraian': 'nama_barang', 'nama': 'nama_barang', 'keterangan': 'nama_barang',
      'banyak_nya': 'banyak_nya', 'banyaknya': 'banyak_nya', 'qty': 'banyak_nya', 'kuantitas': 'banyak_nya', 'quantity': 'banyak_nya', 'vol': 'banyak_nya', 'volume': 'banyak_nya', 'jumlah_barang': 'banyak_nya',
      'satuan': 'satuan', 'unit': 'satuan',
      'harga_satuan': 'harga_satuan', 'harga': 'harga_satuan', 'harga_unit': 'harga_satuan', 'harga@': 'harga_satuan', 'harga_@': 'harga_satuan', 'harga_satuan_': 'harga_satuan', 'hs': 'harga_satuan', 'price': 'harga_satuan',
      'pph': 'pph', 'pajak': 'pph', 'penghasilan': 'pph',
      'jumlah': 'jumlah', 'total': 'jumlah', 'jml': 'jumlah',
    };
    return map[h] || h;
  }

  function parseDate(value: unknown): string {
    if (!value) return new Date().toISOString().split('T')[0];
    if (typeof value === 'number') {
      // Excel serial date
      const date = XLSX.SSF.parse_date_code(value);
      if (date) {
        const y = date.y;
        const m = String(date.m).padStart(2, '0');
        const d = String(date.d).padStart(2, '0');
        return `${y}-${m}-${d}`;
      }
    }
    const str = String(value).trim();
    // Try DD/MM/YYYY or DD-MM-YYYY
    const slashMatch = str.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
    if (slashMatch) {
      const [, d, m, y] = slashMatch;
      return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
    }
    // Try YYYY-MM-DD
    const isoMatch = str.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (isoMatch) return str;
    // Fallback: try Date parse
    const parsed = new Date(str);
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString().split('T')[0];
    }
    return new Date().toISOString().split('T')[0];
  }

  function parseNumber(value: unknown): number {
    if (typeof value === 'number') return value;
    if (!value) return 0;
    const s = String(value).replace(/[^0-9.\-]/g, '');
    const num = parseFloat(s);
    return isNaN(num) ? 0 : num;
  }

  function parseCurrency(value: unknown): number {
    if (typeof value === 'number') {
      let n = Math.trunc(value);
      if (n > 0 && n < 1000) n = n * 1000000;
      return n;
    }
    if (!value) return 0;
    const s = String(value).replace(/[.,]/g, '').replace(/[^0-9\-]/g, '');
    let n = parseInt(s, 10);
    if (isNaN(n)) return 0;
    if (n > 0 && n < 1000) n = n * 1000000;
    return n;
  }

  const SATUAN_OPTIONS = [
    'buah', 'kotak', 'pack', 'lusin', 'set', 'rim', 'botol', 'galon',
    'hari', 'jam', 'orang', 'kegiatan', 'naskah', 'lembur', 'bulan',
    'tahun', 'pelajaran', 'lembar', 'eksemplar', 'kali',
  ];

  function normalizeSatuan(value: unknown): string {
    if (!value) return 'Unit';
    const s = String(value).trim().toLowerCase();
    if (!s) return 'Unit';
    const match = SATUAN_OPTIONS.find((opt) => opt === s);
    if (match) return match;
    // Fuzzy match: try singular/plural and common variants
    const fuzzy = SATUAN_OPTIONS.find((opt) => {
      if (s.includes(opt) || opt.includes(s)) return true;
      return false;
    });
    return fuzzy || (s === 'unit' ? 'Unit' : s);
  }

  async function processFile(file: File) {
    setProcessing(true);
    setError('');
    setResult(null);

    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array', cellDates: false });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(firstSheet, { defval: '' });

      if (rawRows.length === 0) {
        throw new Error('File Excel kosong atau tidak memiliki data.');
      }

      // Normalize headers
      const normalizedRows: Record<string, unknown>[] = rawRows.map((row) => {
        const newRow: Record<string, unknown> = {};
        for (const key of Object.keys(row)) {
          const normKey = normalizeHeader(key);
          newRow[normKey] = row[key];
        }
        return newRow;
      });

      // Parse into structured rows with column-shift detection
      const parsed: ParsedRow[] = normalizedRows.map((r) => {
        const rawSatuan = String(r['satuan'] || '').trim();
        const rawHarga = parseCurrency(r['harga_satuan']);
        const rawQty = parseNumber(r['banyak_nya']);
        const rawJumlah = parseCurrency(r['jumlah']);

        // Detect column shift: satuan contains a number, harga_satuan is 0
        // This happens when "Harga @" header isn't recognized and the price
        // lands in the adjacent "Satuan" column.
        const satuanLooksNumeric = /^\d[\d.,]*$/.test(rawSatuan);
        let harga_satuan = rawHarga;
        let satuan = normalizeSatuan(rawSatuan);
        let banyak_nya = rawQty;

        if (satuanLooksNumeric && rawHarga === 0) {
          // Price got mapped to satuan — recover it
          harga_satuan = parseCurrency(rawSatuan);
          satuan = 'Unit';
        }

        // If harga is still 0 but rawJumlah has a value, the "Jumlah" column
        // might actually be the unit price in this Excel layout.
        if (harga_satuan === 0 && rawJumlah > 0) {
          harga_satuan = rawJumlah;
        }

        return {
          no_bpu: String(r['no_bpu'] || '').trim(),
          tanggal_pesanan: parseDate(r['tanggal_pesanan']),
          tanggal_pembayaran: parseDate(r['tanggal_pembayaran']),
          kode_kegiatan: String(r['kode_kegiatan'] || '').trim(),
          kode_rekening: String(r['kode_rekening'] || '').trim(),
          nama_toko: String(r['nama_toko'] || '').trim(),
          alamat_toko: String(r['alamat_toko'] || '').trim(),
          telepon: String(r['telepon'] || '').trim(),
          nama_barang: String(r['nama_barang'] || '').trim(),
          banyak_nya,
          satuan,
          harga_satuan,
          pph: String(r['pph'] || '').trim(),
        };
      });

      // Validate: must have no_bpu, nama_barang, and valid nominal (harga_satuan > 0)
      const validRows = parsed.filter((r) => r.no_bpu && r.nama_barang && r.harga_satuan > 0);
      if (validRows.length === 0) {
        throw new Error('Tidak ada baris valid. Pastikan kolom No BPU, Nama Barang, dan Harga Satuan terisi dengan benar (harga > 0).');
      }

      // Group by no_bpu
      const bpuGroups = new Map<string, ParsedRow[]>();
      for (const row of validRows) {
        if (!bpuGroups.has(row.no_bpu)) bpuGroups.set(row.no_bpu, []);
        bpuGroups.get(row.no_bpu)!.push(row);
      }

      // Collect unique vendor names
      const vendorNames = new Map<string, { alamat_toko: string; telepon: string }>();
      for (const row of validRows) {
        if (row.nama_toko && !vendorNames.has(row.nama_toko)) {
          vendorNames.set(row.nama_toko, { alamat_toko: row.alamat_toko, telepon: row.telepon });
        }
      }

      // Fetch existing vendors
      const { data: existingVendors } = await supabase
        .from('master_vendor')
        .select('*');

      const vendorByName = new Map<string, Vendor>();
      (existingVendors || []).forEach((v: Vendor) => vendorByName.set(v.nama_toko, v));

      // Create missing vendors
      let newVendorCount = 0;
      for (const [nama, info] of vendorNames) {
        if (!vendorByName.has(nama)) {
          const { data: newVendor, error } = await supabase
            .from('master_vendor')
            .insert({ nama_toko: nama, alamat_toko: info.alamat_toko, telepon: info.telepon })
            .select('*')
            .single();
          if (!error && newVendor) {
            vendorByName.set(nama, newVendor as Vendor);
            newVendorCount++;
          }
        }
      }

      // Fetch existing BPUs to skip duplicates
      const { data: existingBpus } = await supabase
        .from('transaksi_bpu')
        .select('no_bpu');
      const existingBpuSet = new Set((existingBpus || []).map((b: { no_bpu: string }) => b.no_bpu));

      let bpuCount = 0;
      let itemCount = 0;

      for (const [noBpu, rows] of bpuGroups) {
        if (existingBpuSet.has(noBpu)) continue; // Skip existing BPU

        const firstRow = rows[0];
        const vendor = vendorByName.get(firstRow.nama_toko);

        // Insert BPU header
        const { error: headerError } = await supabase.from('transaksi_bpu').insert({
          no_bpu: noBpu,
          tanggal_pesanan: firstRow.tanggal_pesanan,
          tanggal_pembayaran: firstRow.tanggal_pembayaran,
          kode_kegiatan: firstRow.kode_kegiatan,
          kode_rekening: firstRow.kode_rekening,
          vendor_id: vendor?.id || null,
        });
        if (headerError) {
          console.error(`Failed to insert BPU ${noBpu}:`, headerError.message);
          continue;
        }
        bpuCount++;

        // Insert detail items
        const detailRows = rows.map((r) => ({
          bpu_id: noBpu,
          nama_barang: r.nama_barang,
          banyak_nya: r.banyak_nya,
          satuan: r.satuan,
          harga_satuan: r.harga_satuan,
          pph: r.pph || null,
        }));
        const { error: detailError } = await supabase.from('detail_barang_bpu').insert(detailRows);
        if (detailError) {
          console.error(`Failed to insert details for BPU ${noBpu}:`, detailError.message);
        } else {
          itemCount += detailRows.length;
        }
      }

      setResult({ bpuCount, itemCount, vendorCount: newVendorCount });
      onUploaded();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal memproses file Excel');
    }
    setProcessing(false);
  }

  function handleFileSelect(file: File | undefined) {
    if (!file) return;
    const validExts = ['.xlsx', '.xls', '.csv'];
    const ext = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    if (!validExts.includes(ext)) {
      setError('Format file tidak didukung. Gunakan .xlsx, .xls, atau .csv');
      return;
    }
    setFileName(file.name);
    processFile(file);
  }

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
        <h2 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
          <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
          Upload Database Excel
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Unggah file Excel/CSV transaksi untuk memproses BPU secara otomatis
        </p>
      </div>

      <div className="p-6">
        {error && (
          <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
            <button onClick={reset} className="ml-auto p-0.5 text-red-400 hover:text-red-600">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {result && !error && (
          <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-700">
            <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Berhasil memproses {fileName}</p>
              <p className="mt-0.5">
                {result.bpuCount} BPU baru, {result.itemCount} item barang
                {result.vendorCount > 0 && `, ${result.vendorCount} vendor baru`} dibuat.
              </p>
            </div>
            <button onClick={reset} className="ml-auto p-0.5 text-green-400 hover:text-green-600">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Drop zone */}
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            handleFileSelect(e.dataTransfer.files[0]);
          }}
          onClick={() => inputRef.current?.click()}
          className={`relative border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
            dragOver
              ? 'border-emerald-500 bg-emerald-50/50'
              : 'border-slate-300 hover:border-emerald-400 hover:bg-slate-50'
          } ${processing ? 'pointer-events-none opacity-60' : ''}`}
        >
          <input
            ref={inputRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            className="hidden"
            onChange={(e) => handleFileSelect(e.target.files?.[0] || undefined)}
          />
          {processing ? (
            <div className="flex flex-col items-center gap-3">
              <Loader2 className="w-10 h-10 text-emerald-500 animate-spin" />
              <p className="text-sm font-medium text-slate-600">Memproses file...</p>
              {fileName && <p className="text-xs text-slate-400">{fileName}</p>}
            </div>
          ) : (
            <div className="flex flex-col items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-emerald-100 flex items-center justify-center">
                <UploadCloud className="w-7 h-7 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-700">
                  Tarik file ke sini atau klik untuk memilih
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Mendukung .xlsx, .xls, .csv — Kolom: No BPU, Nama Barang, Banyaknya, Harga, Vendor
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="mt-4 flex items-start gap-2 text-xs text-slate-500">
          <FileUp className="w-4 h-4 flex-shrink-0 mt-0.5 text-slate-400" />
          <p>
            Sistem akan otomatis membuat record vendor baru jika belum ada,
            mengelompokkan baris dengan No. BPU yang sama menjadi satu BPU,
            dan menambahkan detail barang ke setiap BPU.
          </p>
        </div>
      </div>
    </div>
  );
}
