import { useState, useEffect, FormEvent, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { BpuFull, Vendor, DetailBarang, BpuDocument, BpuDocumentLog } from '@/lib/types';
import { formatRupiah } from '@/lib/terbilang';
import {
  X, Save, Loader2, AlertCircle, Plus, Trash2, Package, Calendar, Store, FileText,
  Upload, Download, FileCheck2, Image as ImageIcon, History, Paperclip,
} from 'lucide-react';

const SATUAN_OPTIONS = ['Unit', 'buah', 'kotak', 'pack', 'lusin', 'set', 'rim', 'botol', 'galon', 'hari', 'jam', 'orang', 'kegiatan', 'Naskah', 'lembur', 'bulan', 'tahun', 'pelajaran', 'lembar', 'eksemplar', 'kali'];

const ALLOWED_DOC_TYPES = ['application/pdf', 'image/jpeg', 'image/png'];
const ALLOWED_PHOTO_TYPES = ['image/jpeg', 'image/png'];
const MAX_FILE_SIZE = 5 * 1024 * 1024;

interface EditableItem {
  id: string | null;
  nama_barang: string;
  banyak_nya: string;
  satuan: string;
  harga_satuan: string;
  pph: string;
}

interface PendingDoc {
  id: string;
  doc_type: 'kwitansi' | 'foto_barang';
  file: File;
  previewUrl?: string;
}

interface EditBpuModalProps {
  bpu: BpuFull;
  vendors: Vendor[];
  onClose: () => void;
  onSaved: () => void;
}

type TabKey = 'detail' | 'documents';

export default function EditBpuModal({ bpu, vendors, onClose, onSaved }: EditBpuModalProps) {
  const [activeTab, setActiveTab] = useState<TabKey>('detail');
  const [tanggalPesanan, setTanggalPesanan] = useState(bpu.tanggal_pesanan || '');
  const [tanggalPembayaran, setTanggalPembayaran] = useState(bpu.tanggal_pembayaran || '');
  const [kodeKegiatan, setKodeKegiatan] = useState(bpu.kode_kegiatan || '');
  const [kodeRekening, setKodeRekening] = useState(bpu.kode_rekening || '');
  const [vendorId, setVendorId] = useState(bpu.vendor_id || '');
  const [penerimaNama, setPenerimaNama] = useState(bpu.penerima_nama || '');
  const [penerimaPekerjaan, setPenerimaPekerjaan] = useState(bpu.penerima_pekerjaan || '');
  const [penerimaAlamat, setPenerimaAlamat] = useState(bpu.penerima_alamat || '');
  const [items, setItems] = useState<EditableItem[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [toast, setToast] = useState(false);

  // Documents state
  const [existingDocs, setExistingDocs] = useState<BpuDocument[]>([]);
  const [pendingDocs, setPendingDocs] = useState<PendingDoc[]>([]);
  const [logs, setLogs] = useState<BpuDocumentLog[]>([]);
  const [uploading, setUploading] = useState(false);
  const [docError, setDocError] = useState('');
  const kwitansiInputRef = useRef<HTMLInputElement>(null);
  const fotoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const mapped: EditableItem[] = bpu.items.map((it: DetailBarang) => ({
      id: it.id,
      nama_barang: it.nama_barang || '',
      banyak_nya: String(it.banyak_nya ?? ''),
      satuan: it.satuan || 'Unit',
      harga_satuan: it.harga_satuan != null ? String(Math.round(Number(it.harga_satuan))) : '',
      pph: it.pph || '',
    }));
    setItems(mapped.length > 0 ? mapped : [{
      id: null, nama_barang: '', banyak_nya: '', satuan: 'Unit', harga_satuan: '', pph: '',
    }]);
    fetchDocuments();
  }, [bpu]);

  async function fetchDocuments() {
    const [docRes, logRes] = await Promise.all([
      supabase.from('bpu_documents').select('*').eq('bpu_number', bpu.no_bpu).order('created_at', { ascending: false }),
      supabase.from('bpu_document_logs').select('*').eq('bpu_number', bpu.no_bpu).order('created_at', { ascending: false }),
    ]);
    if (docRes.data) setExistingDocs(docRes.data as BpuDocument[]);
    if (logRes.data) setLogs(logRes.data as BpuDocumentLog[]);
  }

  function addItem() {
    setItems([...items, { id: null, nama_barang: '', banyak_nya: '', satuan: 'Unit', harga_satuan: '', pph: '' }]);
  }

  function removeItem(index: number) {
    setItems(items.filter((_, i) => i !== index));
  }

  function updateItem(index: number, field: keyof Omit<EditableItem, 'id'>, value: string) {
    setItems(items.map((it, i) => (i === index ? { ...it, [field]: value } : it)));
  }

  function formatRupiahInput(value: string): string {
    const numeric = value.replace(/[^0-9]/g, '');
    if (!numeric) return '';
    return formatRupiah(parseInt(numeric, 10)).replace('Rp ', '');
  }

  function parseRupiahInput(value: string): number {
    const numeric = value.replace(/[^0-9]/g, '');
    return numeric ? parseInt(numeric, 10) : 0;
  }

  function computeLineTotal(item: EditableItem): number {
    const qty = parseInt(item.banyak_nya, 10) || 0;
    const price = parseRupiahInput(item.harga_satuan);
    return qty * price;
  }

  const grandTotal = items.reduce((sum, it) => sum + computeLineTotal(it), 0);

  // Document handlers
  function validateFile(file: File, isPhoto: boolean): string | null {
    const allowed = isPhoto ? ALLOWED_PHOTO_TYPES : ALLOWED_DOC_TYPES;
    if (!allowed.includes(file.type)) {
      return isPhoto ? 'Format foto harus JPG, JPEG, atau PNG.' : 'Format file harus PDF, JPG, atau PNG.';
    }
    if (file.size > MAX_FILE_SIZE) {
      return 'Ukuran file melebihi 5MB.';
    }
    return null;
  }

  function handleFileSelect(files: FileList | null, docType: 'kwitansi' | 'foto_barang') {
    if (!files || files.length === 0) return;
    setDocError('');
    const newPending: PendingDoc[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const err = validateFile(file, docType === 'foto_barang');
      if (err) {
        setDocError(err);
        continue;
      }
      const previewUrl = file.type.startsWith('image/') ? URL.createObjectURL(file) : undefined;
      newPending.push({
        id: crypto.randomUUID(),
        doc_type: docType,
        file,
        previewUrl,
      });
    }
    if (newPending.length > 0) {
      setPendingDocs((prev) => [...prev, ...newPending]);
    }
  }

  function removePendingDoc(id: string) {
    setPendingDocs((prev) => {
      const doc = prev.find((d) => d.id === id);
      if (doc?.previewUrl) URL.revokeObjectURL(doc.previewUrl);
      return prev.filter((d) => d.id !== id);
    });
  }

  async function deleteExistingDoc(doc: BpuDocument) {
    if (!confirm(`Hapus file "${doc.file_name}"?`)) return;
    await supabase.storage.from('bpu-documents').remove([doc.file_path]);
    await supabase.from('bpu_documents').delete().eq('id', doc.id);
    await supabase.from('bpu_document_logs').insert({
      bpu_number: bpu.no_bpu,
      file_name: doc.file_name,
      action: 'delete',
      user_name: 'Admin',
    });
    fetchDocuments();
  }

  function getDocUrl(filePath: string): string {
    return `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/bpu-documents/${filePath}`;
  }

  async function uploadPendingDocs(): Promise<boolean> {
    if (pendingDocs.length === 0) return true;
    setUploading(true);
    setDocError('');
    try {
      for (const doc of pendingDocs) {
        const fileExt = doc.file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${fileExt}`;
        const filePath = `${bpu.no_bpu}/${doc.doc_type}/${fileName}`;
        const { error: uploadError } = await supabase.storage.from('bpu-documents').upload(filePath, doc.file);
        if (uploadError) throw new Error(uploadError.message);

        const { error: dbError } = await supabase.from('bpu_documents').insert({
          bpu_number: bpu.no_bpu,
          doc_type: doc.doc_type,
          file_name: doc.file.name,
          file_path: filePath,
          file_type: doc.file.type,
          file_size: doc.file.size,
        });
        if (dbError) throw new Error(dbError.message);

        await supabase.from('bpu_document_logs').insert({
          bpu_number: bpu.no_bpu,
          file_name: doc.file.name,
          action: 'upload',
          user_name: 'Admin',
        });
      }
      pendingDocs.forEach((d) => { if (d.previewUrl) URL.revokeObjectURL(d.previewUrl); });
      setPendingDocs([]);
      return true;
    } catch (err) {
      setDocError('Gagal mengunggah dokumen: ' + (err instanceof Error ? err.message : 'Unknown'));
      return false;
    } finally {
      setUploading(false);
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');

    if (!tanggalPesanan || !tanggalPembayaran) {
      setError('Tanggal pesanan dan tanggal pembayaran wajib diisi.');
      setActiveTab('detail');
      return;
    }
    if (!vendorId) {
      setError('Vendor wajib dipilih.');
      setActiveTab('detail');
      return;
    }
    if (!penerimaPekerjaan.trim()) {
      setError('Pekerjaan/Toko pada bagian Yang Menerima wajib diisi (nama toko atau jenis pekerjaan).');
      setActiveTab('detail');
      return;
    }
    const validItems = items.filter(
      (it) => it.nama_barang.trim() && parseInt(it.banyak_nya, 10) > 0
    );
    if (validItems.length === 0) {
      setError('Minimal satu barang harus diisi dengan nama dan jumlah yang valid.');
      setActiveTab('detail');
      return;
    }

    setSaving(true);

    // Upload pending documents first
    const docsOk = await uploadPendingDocs();
    if (!docsOk) {
      setSaving(false);
      setActiveTab('documents');
      return;
    }

    const sanitizedItems = validItems.map((it) => ({
      ...it,
      banyak_nya: parseInt(it.banyak_nya.replace(/[^0-9]/g, ''), 10) || 0,
      harga_satuan: parseInt(it.harga_satuan.replace(/[^0-9]/g, ''), 10) || 0,
    }));

    const { error: headerError } = await supabase.from('transaksi_bpu').update({
      tanggal_pesanan: tanggalPesanan,
      tanggal_pembayaran: tanggalPembayaran,
      kode_kegiatan: kodeKegiatan.trim(),
      kode_rekening: kodeRekening.trim(),
      vendor_id: vendorId,
      penerima_nama: penerimaNama.trim(),
      penerima_pekerjaan: penerimaPekerjaan.trim(),
      penerima_alamat: penerimaAlamat.trim(),
    }).eq('no_bpu', bpu.no_bpu);

    if (headerError) {
      console.error('EditBpu: header update failed', headerError);
      setError('Gagal memperbarui BPU: ' + headerError.message);
      setSaving(false);
      return;
    }

    const { error: delError } = await supabase
      .from('detail_barang_bpu')
      .delete()
      .eq('bpu_id', bpu.no_bpu);

    if (delError) {
      console.error('EditBpu: delete old items failed', delError);
      setError('Gagal memperbarui detail barang: ' + delError.message);
      setSaving(false);
      return;
    }

    const detailRows = sanitizedItems.map((it) => ({
      bpu_id: bpu.no_bpu,
      nama_barang: it.nama_barang.trim(),
      banyak_nya: it.banyak_nya,
      satuan: it.satuan,
      harga_satuan: it.harga_satuan,
      pph: it.pph.trim() || null,
    }));

    const { error: insertError } = await supabase.from('detail_barang_bpu').insert(detailRows);

    if (insertError) {
      console.error('EditBpu: insert new items failed', insertError);
      setError('Gagal menyimpan detail barang: ' + insertError.message);
      setSaving(false);
      return;
    }

    setSaving(false);
    setToast(true);
    setTimeout(() => {
      onSaved();
    }, 900);
  }

  const kwitansiDocs = existingDocs.filter((d) => d.doc_type === 'kwitansi');
  const fotoDocs = existingDocs.filter((d) => d.doc_type === 'foto_barang');
  const pendingKwitansi = pendingDocs.filter((d) => d.doc_type === 'kwitansi');
  const pendingFoto = pendingDocs.filter((d) => d.doc_type === 'foto_barang');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm" onClick={onClose}>
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-100 flex items-center justify-center">
              <FileText className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-800">Edit Data BPU</h2>
              <p className="text-xs text-slate-500">No. BPU: {bpu.no_bpu}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 bg-white">
          <button
            onClick={() => setActiveTab('detail')}
            className={`flex items-center gap-2 px-6 py-3 text-sm font-medium transition relative ${
              activeTab === 'detail' ? 'text-amber-600' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <Package className="w-4 h-4" />
            Detail BPU
            {activeTab === 'detail' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500 rounded-full" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('documents')}
            className={`flex items-center gap-2 px-6 py-3 text-sm font-medium transition relative ${
              activeTab === 'documents' ? 'text-amber-600' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <Paperclip className="w-4 h-4" />
            Dokumen Pendukung
            {(existingDocs.length + pendingDocs.length) > 0 && (
              <span className="ml-1 px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700 text-xs font-semibold">
                {existingDocs.length + pendingDocs.length}
              </span>
            )}
            {activeTab === 'documents' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500 rounded-full" />
            )}
          </button>
        </div>

        {/* Toast */}
        {toast && (
          <div className="mx-6 mt-4 flex items-center gap-2.5 rounded-xl bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-700">
            <svg className="w-5 h-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
            <span>Perubahan data BPU berhasil disimpan!</span>
          </div>
        )}

        {/* Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto">
          <div className="p-6 space-y-5">
            {(error || docError) && (
              <div className="flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
                <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <span>{error || docError}</span>
              </div>
            )}

            {/* ==================== TAB: DETAIL BPU ==================== */}
            {activeTab === 'detail' && (
              <>
                {/* BPU Header Fields */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1.5">Nomor BPU</label>
                    <input
                      type="text"
                      value={bpu.no_bpu}
                      disabled
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-100 text-slate-500 cursor-not-allowed"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1.5">Vendor *</label>
                    <select
                      value={vendorId}
                      onChange={(e) => {
                        setVendorId(e.target.value);
                        const v = vendors.find((x) => x.id === e.target.value);
                        if (v) {
                          setPenerimaPekerjaan(v.nama_toko);
                          setPenerimaAlamat(v.alamat_toko || '');
                        }
                      }}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                      required
                    >
                      <option value="">— Pilih Vendor —</option>
                      {vendors.map((v) => (
                        <option key={v.id} value={v.id}>{v.nama_toko}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1.5">Tanggal Pesanan *</label>
                    <input
                      type="date"
                      value={tanggalPesanan}
                      onChange={(e) => setTanggalPesanan(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1.5">Tanggal Pembayaran *</label>
                    <input
                      type="date"
                      value={tanggalPembayaran}
                      onChange={(e) => setTanggalPembayaran(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1.5">Kode Kegiatan</label>
                    <input
                      type="text"
                      value={kodeKegiatan}
                      onChange={(e) => setKodeKegiatan(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                      placeholder="06.05.09."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1.5">Kode Rekening</label>
                    <input
                      type="text"
                      value={kodeRekening}
                      onChange={(e) => setKodeRekening(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                      placeholder="5.1.02.01.01.0030"
                    />
                  </div>
                </div>

                {/* Yang Menerima Section */}
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-100 bg-slate-50/50">
                    <h3 className="text-sm font-semibold text-slate-700">Yang Menerima (Tanda Penerimaan)</h3>
                    <p className="text-xs text-slate-500 mt-0.5">Data penerima untuk dokumen Tanda Penerimaan. Pilih vendor untuk mengisi otomatis, atau ketik manual (nama toko, profesi, atau jenis pekerjaan).</p>
                  </div>
                  <div className="p-4 grid sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1.5">Nama Penerima *</label>
                      <input
                        type="text"
                        value={penerimaNama}
                        onChange={(e) => setPenerimaNama(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                        placeholder="Nama penerima uang"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1.5">Pekerjaan / Toko *</label>
                      <input
                        type="text"
                        value={penerimaPekerjaan}
                        onChange={(e) => setPenerimaPekerjaan(e.target.value)}
                        list="edit-vendor-pekerjaan-options"
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                        placeholder="KPRI Bina Rata, Teknisi AC, Tukang Bangunan, dll."
                      />
                      <datalist id="edit-vendor-pekerjaan-options">
                        {vendors.map((v) => (
                          <option key={v.id} value={v.nama_toko} />
                        ))}
                      </datalist>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1.5">Alamat</label>
                      <input
                        type="text"
                        value={penerimaAlamat}
                        onChange={(e) => setPenerimaAlamat(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                        placeholder="Alamat penerima"
                      />
                    </div>
                  </div>
                </div>

                {/* Line Items */}
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                      <Package className="w-4 h-4 text-slate-400" />
                      Detail Barang
                    </h3>
                    <button
                      type="button"
                      onClick={addItem}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 font-medium text-xs hover:bg-emerald-100 transition"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Tambah Baris
                    </button>
                  </div>

                  {/* Desktop table */}
                  <div className="hidden sm:block overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                          <th className="px-3 py-2.5 text-left font-semibold w-8">No</th>
                          <th className="px-3 py-2.5 text-left font-semibold">Nama Barang</th>
                          <th className="px-3 py-2.5 text-left font-semibold w-20">Jumlah</th>
                          <th className="px-3 py-2.5 text-left font-semibold w-24">Satuan</th>
                          <th className="px-3 py-2.5 text-right font-semibold w-36">Harga Satuan</th>
                          <th className="px-3 py-2.5 text-right font-semibold w-32">Jumlah (Rp)</th>
                          <th className="px-3 py-2.5 text-center font-semibold w-10"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {items.map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/50">
                            <td className="px-3 py-2 text-slate-500 font-medium">{idx + 1}</td>
                            <td className="px-3 py-2">
                              <input
                                type="text"
                                value={item.nama_barang}
                                onChange={(e) => updateItem(idx, 'nama_barang', e.target.value)}
                                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                                placeholder="Nama barang"
                              />
                            </td>
                            <td className="px-3 py-2">
                              <input
                                type="number"
                                min="0"
                                value={item.banyak_nya}
                                onChange={(e) => updateItem(idx, 'banyak_nya', e.target.value)}
                                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                                placeholder="0"
                              />
                            </td>
                            <td className="px-3 py-2">
                              <select
                                value={item.satuan}
                                onChange={(e) => updateItem(idx, 'satuan', e.target.value)}
                                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                              >
                                {SATUAN_OPTIONS.map((s) => (
                                  <option key={s} value={s}>{s}</option>
                                ))}
                              </select>
                            </td>
                            <td className="px-3 py-2">
                              <input
                                type="text"
                                inputMode="numeric"
                                value={item.harga_satuan ? formatRupiahInput(item.harga_satuan) : ''}
                                onChange={(e) => updateItem(idx, 'harga_satuan', e.target.value.replace(/[^0-9]/g, ''))}
                                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-800 text-right focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                                placeholder="0"
                              />
                            </td>
                            <td className="px-3 py-2 text-right font-semibold text-slate-700">
                              {formatRupiah(computeLineTotal(item))}
                            </td>
                            <td className="px-3 py-2 text-center">
                              {items.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => removeItem(idx)}
                                  className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="bg-slate-50 border-t-2 border-slate-200">
                          <td colSpan={4} className="px-3 py-2.5 text-right font-semibold text-slate-700 text-sm">
                            Total:
                          </td>
                          <td className="px-3 py-2.5 text-right font-bold text-amber-600 text-base" colSpan={3}>
                            {formatRupiah(grandTotal)}
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>

                  {/* Mobile cards */}
                  <div className="sm:hidden divide-y divide-slate-100">
                    {items.map((item, idx) => (
                      <div key={idx} className="p-3 space-y-2.5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-slate-400">Barang #{idx + 1}</span>
                          {items.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeItem(idx)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                        <input
                          type="text"
                          value={item.nama_barang}
                          onChange={(e) => updateItem(idx, 'nama_barang', e.target.value)}
                          className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                          placeholder="Nama barang"
                        />
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="number"
                            min="0"
                            value={item.banyak_nya}
                            onChange={(e) => updateItem(idx, 'banyak_nya', e.target.value)}
                            className="px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                            placeholder="Jumlah"
                          />
                          <select
                            value={item.satuan}
                            onChange={(e) => updateItem(idx, 'satuan', e.target.value)}
                            className="px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                          >
                            {SATUAN_OPTIONS.map((s) => (
                              <option key={s} value={s}>{s}</option>
                            ))}
                          </select>
                        </div>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={item.harga_satuan ? formatRupiahInput(item.harga_satuan) : ''}
                          onChange={(e) => updateItem(idx, 'harga_satuan', e.target.value.replace(/[^0-9]/g, ''))}
                          className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 text-right focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                          placeholder="Harga satuan"
                        />
                        <p className="text-right text-sm font-semibold text-slate-700">
                          Jumlah: {formatRupiah(computeLineTotal(item))}
                        </p>
                      </div>
                    ))}
                    <div className="p-3 bg-slate-50 flex items-center justify-between">
                      <span className="font-semibold text-slate-700 text-sm">Total:</span>
                      <span className="font-bold text-amber-600 text-base">{formatRupiah(grandTotal)}</span>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* ==================== TAB: DOKUMEN PENDUKUNG ==================== */}
            {activeTab === 'documents' && (
              <div className="space-y-6">
                <p className="text-xs text-slate-400 bg-slate-50 rounded-lg px-3 py-2">
                  Catatan: Seluruh unggahan dokumen bersifat opsional. Anda dapat menyimpan tanpa mengunggah dokumen apapun.
                </p>

                {/* Bukti Kwitansi / Faktur */}
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                      <FileCheck2 className="w-4 h-4 text-emerald-500" />
                      Bukti Kwitansi / Faktur
                    </h3>
                    <button
                      type="button"
                      onClick={() => kwitansiInputRef.current?.click()}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 font-medium text-xs hover:bg-emerald-100 transition"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Tambah Kwitansi/Faktur
                    </button>
                    <input
                      ref={kwitansiInputRef}
                      type="file"
                      accept=".pdf,.jpg,.jpeg,.png"
                      multiple
                      className="hidden"
                      onChange={(e) => { handleFileSelect(e.target.files, 'kwitansi'); e.target.value = ''; }}
                    />
                  </div>
                  <div className="p-4 space-y-3">
                    {/* Existing kwitansi docs */}
                    {kwitansiDocs.map((doc) => (
                      <div key={doc.id} className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-white border border-slate-200">
                        <FileCheck2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                        <span className="text-sm text-slate-700 flex-1 truncate">{doc.file_name}</span>
                        <span className="text-xs text-slate-400">{(doc.file_size / 1024).toFixed(0)} KB</span>
                        <a
                          href={getDocUrl(doc.file_path)}
                          download={doc.file_name}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-blue-500 hover:bg-blue-50 transition"
                          title="Unduh Berkas"
                        >
                          <Download className="w-4 h-4" />
                        </a>
                        <button
                          type="button"
                          onClick={() => deleteExistingDoc(doc)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                          title="Hapus"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                    {/* Pending kwitansi docs */}
                    {pendingKwitansi.map((doc) => (
                      <div key={doc.id} className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-amber-50 border border-amber-200">
                        <FileCheck2 className="w-5 h-5 text-amber-500 flex-shrink-0" />
                        <span className="text-sm text-slate-700 flex-1 truncate">{doc.file.name}</span>
                        <span className="text-xs text-slate-400">{(doc.file.size / 1024).toFixed(0)} KB</span>
                        <span className="text-xs text-amber-600 font-medium">Baru</span>
                        <button
                          type="button"
                          onClick={() => removePendingDoc(doc.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                          title="Batal"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                    {kwitansiDocs.length === 0 && pendingKwitansi.length === 0 && (
                      <div className="text-center py-6 text-sm text-slate-400">
                        Belum ada file kwitansi/faktur. Klik "Tambah Kwitansi/Faktur" untuk mengunggah.
                      </div>
                    )}
                  </div>
                </div>

                {/* Gambar / Foto Barang */}
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                      <ImageIcon className="w-4 h-4 text-blue-500" />
                      Gambar / Foto Barang
                    </h3>
                    <button
                      type="button"
                      onClick={() => fotoInputRef.current?.click()}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 font-medium text-xs hover:bg-blue-100 transition"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Tambah Foto Barang
                    </button>
                    <input
                      ref={fotoInputRef}
                      type="file"
                      accept=".jpg,.jpeg,.png"
                      multiple
                      className="hidden"
                      onChange={(e) => { handleFileSelect(e.target.files, 'foto_barang'); e.target.value = ''; }}
                    />
                  </div>
                  <div className="p-4">
                    {/* Grid of existing + pending photos */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                      {/* Existing foto docs */}
                      {fotoDocs.map((doc) => (
                        <div key={doc.id} className="relative group rounded-lg border border-slate-200 overflow-hidden bg-slate-50">
                          <div className="aspect-square flex items-center justify-center overflow-hidden">
                            <img
                              src={getDocUrl(doc.file_path)}
                              alt={doc.file_name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="px-2 py-1.5">
                            <p className="text-xs text-slate-600 truncate">{doc.file_name}</p>
                          </div>
                          <div className="absolute top-1.5 right-1.5 flex gap-1">
                            <a
                              href={getDocUrl(doc.file_path)}
                              download={doc.file_name}
                              className="p-1.5 rounded-lg bg-white/90 text-slate-500 hover:text-blue-500 shadow-sm transition"
                              title="Unduh Berkas"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </a>
                            <button
                              type="button"
                              onClick={() => deleteExistingDoc(doc)}
                              className="p-1.5 rounded-lg bg-white/90 text-slate-500 hover:text-red-500 shadow-sm transition"
                              title="Hapus"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                      {/* Pending foto docs */}
                      {pendingFoto.map((doc) => (
                        <div key={doc.id} className="relative group rounded-lg border border-amber-200 overflow-hidden bg-amber-50">
                          <div className="aspect-square flex items-center justify-center overflow-hidden">
                            {doc.previewUrl ? (
                              <img src={doc.previewUrl} alt={doc.file.name} className="w-full h-full object-cover" />
                            ) : (
                              <ImageIcon className="w-8 h-8 text-slate-300" />
                            )}
                          </div>
                          <div className="px-2 py-1.5">
                            <p className="text-xs text-slate-600 truncate">{doc.file.name}</p>
                            <span className="text-xs text-amber-600 font-medium">Baru</span>
                          </div>
                          <div className="absolute top-1.5 right-1.5">
                            <button
                              type="button"
                              onClick={() => removePendingDoc(doc.id)}
                              className="p-1.5 rounded-lg bg-white/90 text-slate-500 hover:text-red-500 shadow-sm transition"
                              title="Batal"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                    {fotoDocs.length === 0 && pendingFoto.length === 0 && (
                      <div className="text-center py-6 text-sm text-slate-400">
                        Belum ada foto barang. Klik "Tambah Foto Barang" untuk mengunggah.
                      </div>
                    )}
                  </div>
                </div>

                {/* Riwayat Dokumen */}
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-100 bg-slate-50/50">
                    <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                      <History className="w-4 h-4 text-slate-400" />
                      Riwayat Dokumen
                    </h3>
                  </div>
                  <div className="max-h-48 overflow-y-auto">
                    {logs.length === 0 ? (
                      <div className="text-center py-6 text-sm text-slate-400">
                        Belum ada riwayat perubahan dokumen.
                      </div>
                    ) : (
                      <table className="w-full text-sm">
                        <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide sticky top-0">
                          <tr>
                            <th className="px-3 py-2 text-left font-semibold">Nama Berkas</th>
                            <th className="px-3 py-2 text-left font-semibold">Aksi</th>
                            <th className="px-3 py-2 text-left font-semibold">User</th>
                            <th className="px-3 py-2 text-left font-semibold">Waktu</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {logs.map((log) => {
                            const actionColor =
                              log.action === 'upload' ? 'text-emerald-600' :
                              log.action === 'delete' ? 'text-red-600' :
                              'text-amber-600';
                            return (
                              <tr key={log.id} className="hover:bg-slate-50/50">
                                <td className="px-3 py-2 text-slate-700 truncate max-w-[160px]">{log.file_name}</td>
                                <td className={`px-3 py-2 font-medium ${actionColor}`}>
                                  {log.action === 'upload' ? 'Diunggah' : log.action === 'delete' ? 'Dihapus' : 'Diganti'}
                                </td>
                                <td className="px-3 py-2 text-slate-600">{log.user_name}</td>
                                <td className="px-3 py-2 text-slate-500 text-xs">
                                  {new Date(log.created_at || '').toLocaleString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    )}
                  </div>
                </div>

                {uploading && (
                  <div className="flex items-center gap-2 text-sm text-amber-600">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Mengunggah dokumen...
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/50 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-slate-600 font-medium text-sm hover:bg-slate-100 transition"
            >
              <X className="w-4 h-4" />
              Batal
            </button>
            <button
              type="submit"
              disabled={saving || uploading}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500/40 transition disabled:opacity-60"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {saving ? 'Menyimpan...' : 'Simpan Perubahan'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
