import { BpuFull, Pejabat } from '@/lib/types';
import { terbilang, tanggalTerbilang, formatAngka } from '@/lib/terbilang';
import { buildYaituText } from '@/lib/yaituText';
import { getLogoFromStorage, LOGO_KOP_KEY } from '@/context/LogoContext';
import { getSchoolIdentityFromStorage } from '@/context/SchoolContext';

export type DocType = 'order' | 'tanda-terima' | 'faktur' | 'berita-acara' | 'lampiran';

export const DOC_LABELS: Record<DocType, string> = {
  'order': 'Surat Pesanan',
  'tanda-terima': 'Tanda Terima',
  'faktur': 'Faktur Pembelian',
  'berita-acara': 'Berita Acara Pembayaran',
  'lampiran': 'Lampiran Pemeriksaan',
};

export const DOC_FILENAMES: Record<DocType, string> = {
  'order': 'Surat_Pesanan',
  'tanda-terima': 'Tanda_Terima',
  'faktur': 'Faktur_Pembelian',
  'berita-acara': 'Berita_Acara_Pembayaran',
  'lampiran': 'Lampiran_Pemeriksaan',
};

const LOGO_KARTIKA_SVG = `
<svg width="75" height="90" viewBox="0 0 75 90" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="greenGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#15803d"/>
      <stop offset="100%" stop-color="#14532d"/>
    </linearGradient>
    <linearGradient id="starGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#fde047"/>
      <stop offset="100%" stop-color="#eab308"/>
    </linearGradient>
    <linearGradient id="bookGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="100%" stop-color="#f1f5f9"/>
    </linearGradient>
  </defs>

  <g transform="translate(37.5, 0)">
    <g transform="translate(0, 32)">
      <circle cx="0" cy="0" r="32" fill="none" stroke="url(#greenGrad)" stroke-width="2.5"/>

      <g fill="url(#greenGrad)">
        <ellipse cx="0" cy="-26" rx="5" ry="8"/>
        <ellipse cx="0" cy="-26" rx="5" ry="8" transform="rotate(45)"/>
        <ellipse cx="0" cy="-26" rx="5" ry="8" transform="rotate(90)"/>
        <ellipse cx="0" cy="-26" rx="5" ry="8" transform="rotate(135)"/>
        <ellipse cx="0" cy="-26" rx="5" ry="8" transform="rotate(180)"/>
        <ellipse cx="0" cy="-26" rx="5" ry="8" transform="rotate(225)"/>
        <ellipse cx="0" cy="-26" rx="5" ry="8" transform="rotate(270)"/>
        <ellipse cx="0" cy="-26" rx="5" ry="8" transform="rotate(315)"/>
      </g>

      <circle cx="0" cy="0" r="20" fill="#ffffff"/>
      <circle cx="0" cy="0" r="20" fill="none" stroke="#14532d" stroke-width="1"/>

      <polygon points="0,-14 4.1,-4.3 14.5,-4.3 6.1,1.7 9.4,11.4 0,5.5 -9.4,11.4 -6.1,1.7 -14.5,-4.3 -4.1,-4.3" fill="url(#starGrad)" stroke="#ca8a04" stroke-width="0.3"/>
    </g>

    <g transform="translate(0, 58)">
      <path d="M-20,-6 Q-20,-9 -17,-9 L-1,-9 L0,-7 L1,-9 L17,-9 Q20,-9 20,-6 L20,1 Q20,4 17,4 L1,4 L0,2 L-1,4 L-17,4 Q-20,4 -20,1 Z" fill="url(#bookGrad)" stroke="#475569" stroke-width="0.6"/>
      <line x1="0" y1="-9" x2="0" y2="4" stroke="#94a3b8" stroke-width="0.5"/>
      <line x1="-15" y1="-5" x2="-4" y2="-5" stroke="#94a3b8" stroke-width="0.4"/>
      <line x1="-15" y1="-2" x2="-4" y2="-2" stroke="#94a3b8" stroke-width="0.4"/>
      <line x1="-15" y1="1" x2="-4" y2="1" stroke="#94a3b8" stroke-width="0.4"/>
      <line x1="4" y1="-5" x2="15" y2="-5" stroke="#94a3b8" stroke-width="0.4"/>
      <line x1="4" y1="-2" x2="15" y2="-2" stroke="#94a3b8" stroke-width="0.4"/>
      <line x1="4" y1="1" x2="15" y2="1" stroke="#94a3b8" stroke-width="0.4"/>
    </g>

    <g transform="translate(0, 78)">
      <path d="M-22,2 L-22,9 L-14,7 L-7,9 L0,7 L7,9 L14,7 L22,9 L22,2 L14,0 L7,2 L0,0 L-7,2 L-14,0 Z" fill="#dc2626" stroke="#991b1b" stroke-width="0.4"/>
      <path d="M-22,2 L-22,-1 L22,-1 L22,2 Z" fill="#b91c1c"/>
      <text x="0" y="6.5" text-anchor="middle" font-size="5.5" font-weight="bold" font-family="Arial, sans-serif" fill="#ffffff" letter-spacing="0.8">KARTIKA JAYA</text>
    </g>
  </g>
</svg>`;

export function KopSurat() {
  const uploadedLogo = getLogoFromStorage(LOGO_KOP_KEY);
  const school = getSchoolIdentityFromStorage();

  const logoElement = uploadedLogo ? (
    <img
      src={uploadedLogo}
      alt="Logo Kop Surat"
      style={{ display: 'block', width: '78px', height: '78px', objectFit: 'contain' }}
    />
  ) : (
    <span dangerouslySetInnerHTML={{ __html: LOGO_KARTIKA_SVG }} />
  );

  return (
    <div style={{ fontFamily: "'Arial',sans-serif", color: '#000', width: '100%' }}>
      <div style={{ position: 'relative', width: '100%', padding: '0 0 2px 0', minHeight: '70px', display: 'flex', alignItems: 'center' }}>
        {/* Logo Kop Surat — dari localStorage (upload) atau fallback SVG bawaan */}
        <div style={{ width: '78px', flexShrink: 0, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          {logoElement}
        </div>
        {/* Teks Kop — rata tengah selebar halaman penuh */}
        <div style={{ position: 'absolute', left: 0, right: 0, textAlign: 'center', lineHeight: '1.2', pointerEvents: 'none' }}>
          <p style={{ fontSize: '14px', fontWeight: 'bold', textAlign: 'center', margin: '0', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            {school.yayasan}
          </p>
          <p style={{ fontSize: '20px', fontWeight: 'bold', textAlign: 'center', margin: '2px 0', textTransform: 'uppercase' }}>
            {school.namaSekolah}
          </p>
          <p style={{ fontSize: '11px', textAlign: 'center', margin: '0', textTransform: 'uppercase' }}>
            {school.alamat}
          </p>
          <p style={{ fontSize: '13px', fontWeight: 'bold', textAlign: 'center', margin: '0', textTransform: 'uppercase' }}>
            {school.kota}
          </p>
        </div>
      </div>
      {/* Garis pembatas ganda (double line) */}
      <div
        style={{
          borderTop: '3px solid #000',
          borderBottom: '1px solid #000',
          paddingTop: '2px',
          marginTop: '8px',
          marginBottom: '15px',
        }}
      />
    </div>
  );
}

const cellStyle = { border: '1px solid #000', padding: '4px 6px' } as const;

interface DocData {
  bpu: BpuFull;
  pejabat: Record<string, Pejabat>;
}

function useDocData({ bpu, pejabat }: DocData) {
  const school = getSchoolIdentityFromStorage();
  const kepala = pejabat['Kepala Sekolah'];
  const bendahara = pejabat['Bendahara BOSP'];
  const pengurusBarang = pejabat['Pengurus Barang'];
  const vendor = bpu.vendor;
  const total = bpu.total;
  const totalTerbilang = terbilang(total);
  const tanggalBayar = tanggalTerbilang(bpu.tanggal_pembayaran);
  const tanggalPesananFormatted = new Date(bpu.tanggal_pesanan).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
  const tanggalBayarFormatted = new Date(bpu.tanggal_pembayaran).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
  const bulanTahunTransaksi = new Date(bpu.tanggal_pembayaran).toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });
  const itemsSummary = bpu.items.map((i) => i.nama_barang).join(', ') || 'Barang';
  const yaituText = buildYaituText(bpu);

  return { school, kepala, bendahara, pengurusBarang, vendor, total, totalTerbilang, tanggalBayar, tanggalPesananFormatted, tanggalBayarFormatted, bulanTahunTransaksi, itemsSummary, yaituText };
}

// 1. PESANAN / ORDER
export function OrderDoc({ bpu, pejabat }: DocData) {
  const { school, kepala, vendor, tanggalPesananFormatted } = useDocData({ bpu, pejabat });
  return (
    <div style={{ fontFamily: "'Arial',sans-serif", color: '#000' }}>
      <KopSurat />
      <h3 style={{ textAlign: 'center', fontSize: '14px', fontWeight: 'bold', textDecoration: 'underline', margin: '0 0 12px 0' }}>
        SURAT PESANAN
      </h3>
      <table style={{ width: '100%', fontSize: '12px', marginBottom: '14px', borderCollapse: 'collapse' }}>
        <tbody>
          <tr>
            <td style={{ width: '25%', padding: '2px 0' }}>Tanggal Pesanan</td>
            <td style={{ padding: '2px 0' }}>: {tanggalPesananFormatted}</td>
          </tr>
          <tr>
            <td style={{ padding: '2px 0' }}>Kepada</td>
            <td style={{ padding: '2px 0' }}>: {vendor?.nama_toko || '-'}</td>
          </tr>
          <tr>
            <td style={{ padding: '2px 0' }}></td>
            <td style={{ padding: '2px 0' }}>&nbsp;&nbsp;&nbsp;{vendor?.alamat_toko || ''}</td>
          </tr>
          <tr>
            <td style={{ padding: '2px 0' }}>No. BPU</td>
            <td style={{ padding: '2px 0' }}>: {bpu.no_bpu}</td>
          </tr>
        </tbody>
      </table>
      <p style={{ fontSize: '12px', margin: '0 0 10px 0' }}>Mohon dapat disediakan barang-barang sebagai berikut:</p>
      <table style={{ width: '100%', fontSize: '12px', borderCollapse: 'collapse', marginBottom: '30px' }}>
        <thead>
          <tr>
            <th style={{ ...cellStyle, width: '8%' }}>No</th>
            <th style={{ ...cellStyle }}>Jenis Barang</th>
            <th style={{ ...cellStyle, width: '20%' }}>Banyaknya</th>
          </tr>
        </thead>
        <tbody>
          {bpu.items.map((item, idx) => (
            <tr key={item.id}>
              <td style={{ ...cellStyle, textAlign: 'center' }}>{idx + 1}</td>
              <td style={cellStyle}>{item.nama_barang}</td>
              <td style={{ ...cellStyle, textAlign: 'center' }}>{item.banyak_nya} {item.satuan}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <table style={{ width: '100%', fontSize: '12px', marginTop: '20px' }}>
        <tbody>
          <tr>
            <td style={{ width: '55%' }}></td>
            <td style={{ textAlign: 'center' }}>
              <p style={{ margin: '0 0 4px 0' }}>{school.kota}, {tanggalPesananFormatted}</p>
              <p style={{ margin: '0 0 60px 0' }}>Kepala Sekolah,</p>
              <p style={{ margin: '0 0 2px 0', fontWeight: 'bold', textDecoration: 'underline' }}>{kepala?.nama || ''}</p>
              <p style={{ margin: '0' }}>NIP. {kepala?.nip || ''}</p>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

// 2. TANDA PENERIMAAN (KWITANSI)
export function TandaTerimaDoc({ bpu, pejabat }: DocData) {
  const { school, kepala, bendahara, pengurusBarang, total, totalTerbilang, tanggalBayarFormatted, yaituText } = useDocData({ bpu, pejabat });
  const tahun = new Date(bpu.tanggal_pembayaran).getFullYear();
  const penerimaNama = bpu.penerima_nama?.trim() || '............................................';
  const penerimaPekerjaan = bpu.penerima_pekerjaan?.trim() || bpu.vendor?.nama_toko || '-';
  const penerimaAlamat = bpu.penerima_alamat?.trim() || bpu.vendor?.alamat_toko || '-';
  const copyLabels = ['Asli', 'Kedua', 'Ketiga', 'Keempat'];

  const labelStyle: React.CSSProperties = {
    width: '25%',
    padding: '2px 0',
    verticalAlign: 'top',
    whiteSpace: 'nowrap',
  };
  const valueStyle: React.CSSProperties = {
    padding: '2px 0',
    verticalAlign: 'top',
  };
  const signatureNameStyle: React.CSSProperties = {
    margin: '0 0 2px 0',
    fontWeight: 'bold',
    textDecoration: 'underline',
  };

  return (
    <div style={{ fontFamily: "'Arial', sans-serif", color: '#000', fontSize: '12px', lineHeight: '1.25' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', margin: '0 0 24px 29%' }}>
        <div>
          <div>No <span style={{ marginLeft: '29px' }}>: {bpu.no_bpu}</span></div>
          <div>M. A <span style={{ marginLeft: '19px' }}>: <strong>BOS APBN</strong></span></div>
          <div>Tahun <span style={{ marginLeft: '7px' }}>: <strong><u>{tahun}</u></strong></span></div>
        </div>
        <div style={{ width: '90px', lineHeight: '1.35' }}>
          {copyLabels.map((label) => <div key={label}><u>{label}</u></div>)}
        </div>
      </div>

      <h3 style={{ textAlign: 'center', fontFamily: "'Times New Roman', serif", fontSize: '21px', fontWeight: 'bold', textDecoration: 'underline', margin: '0 0 40px 0' }}>
        TANDA PENERIMAAN
      </h3>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '26px' }}>
        <tbody>
          <tr>
            <td style={labelStyle}>Sudah terima dari</td>
            <td style={valueStyle}>: Bendahara BOSP {school.namaSekolah} Kota {school.kota}.</td>
          </tr>
          <tr>
            <td style={{ ...labelStyle, paddingTop: '12px' }}>Uang banyaknya</td>
            <td style={{ ...valueStyle, paddingTop: '12px', fontStyle: 'italic', fontWeight: 'bold', textDecoration: 'underline' }}>: {totalTerbilang}</td>
          </tr>
          <tr>
            <td style={{ ...labelStyle, paddingTop: '12px', letterSpacing: '3px' }}>YAITU</td>
            <td style={{ ...valueStyle, paddingTop: '12px', fontWeight: 'bold', textDecoration: 'underline' }}>
              : {yaituText}
            </td>
          </tr>
        </tbody>
      </table>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '34px', marginBottom: '30px' }}>
        <tbody>
          <tr>
            <td style={{ width: '52%', verticalAlign: 'top' }}>
              <p style={{ margin: '0 0 4px 0' }}>Setuju dibayar,</p>
              <p style={{ margin: '0 0 60px 0' }}>Kepala Sekolah</p>
              <p style={signatureNameStyle}>{kepala?.nama || ''}</p>
              <p style={{ margin: '0' }}>NIP. {kepala?.nip || ''}</p>
            </td>
            <td style={{ verticalAlign: 'top' }}>
              <p style={{ margin: '0 0 34px 0' }}>{school.kota}, {tanggalBayarFormatted}</p>
              <p style={{ margin: '0 0 58px 0' }}>Yang menerima</p>
              <table style={{ borderCollapse: 'collapse', width: '100%' }}>
                <tbody>
                  <tr><td style={{ width: '28%' }}>Nama</td><td>: <strong>{penerimaNama}</strong></td></tr>
                  <tr><td>Pekerjaan/Toko</td><td>: <strong>{penerimaPekerjaan}</strong></td></tr>
                  <tr><td>Alamat</td><td>: {penerimaAlamat}</td></tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>

      <p style={{ margin: '18px 0 42px 0', fontSize: '16px', fontWeight: 'bold' }}>
        TERBILANG: Rp. {formatAngka(total)},-
      </p>

      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <tbody>
          <tr>
            <td style={{ width: '52%', verticalAlign: 'top', paddingRight: '20px' }}>
              <p style={{ margin: '0 0 68px 0' }}>Barang2/Pekerjaan yang dimaksud telah diterima<br />Diselenggarakan dengan sempurna pada tanggal</p>
              <p style={{ margin: '0 0 4px 0' }}>Pengurus barang2/pekerjaan</p>
              <p style={{ ...signatureNameStyle, marginTop: '66px' }}>{pengurusBarang?.nama || ''}</p>
              <p style={{ margin: '0' }}>NIP.{pengurusBarang?.nip || ''}</p>
            </td>
            <td style={{ verticalAlign: 'top' }}>
              <p style={{ margin: '0 0 68px 0' }}>Lunas dibayar,<br />Bendahara BOS Sekolah</p>
              <p style={{ ...signatureNameStyle, marginTop: '66px' }}>{bendahara?.nama || ''}</p>
              <p style={{ margin: '0' }}>NIP.{bendahara?.nip || ''}</p>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

// 3. FAKTUR PEMBELIAN
export function FakturDoc({ bpu, pejabat }: DocData) {
  const { school, vendor, total, tanggalPesananFormatted } = useDocData({ bpu, pejabat });
  return (
    <div style={{ fontFamily: "'Arial',sans-serif", color: '#000' }}>
      <div style={{ textAlign: 'center', marginBottom: '16px' }}>
        <h2 style={{ fontSize: '18px', fontWeight: 'bold', margin: '0 0 4px 0' }}>{vendor?.nama_toko || ''}</h2>
        <p style={{ fontSize: '12px', margin: '0 0 2px 0' }}>{vendor?.alamat_toko || ''}</p>
        <p style={{ fontSize: '12px', margin: '0' }}>Telp: {vendor?.telepon || '-'}</p>
      </div>
      <div style={{ borderTop: '2px solid #000', borderBottom: '1px solid #000', height: '2px', marginBottom: '16px' }} />
      <h3 style={{ textAlign: 'center', fontSize: '14px', fontWeight: 'bold', textDecoration: 'underline', margin: '0 0 12px 0' }}>
        FAKTUR PEMBELIAN
      </h3>
      <table style={{ width: '100%', fontSize: '12px', marginBottom: '14px', borderCollapse: 'collapse' }}>
        <tbody>
          <tr>
            <td style={{ width: '25%', padding: '2px 0' }}>No. BPU</td>
            <td style={{ padding: '2px 0' }}>: {bpu.no_bpu}</td>
          </tr>
          <tr>
            <td style={{ padding: '2px 0' }}>Tanggal</td>
            <td style={{ padding: '2px 0' }}>: {tanggalPesananFormatted}</td>
          </tr>
        </tbody>
      </table>
      <table style={{ width: '100%', fontSize: '12px', borderCollapse: 'collapse', marginBottom: '20px' }}>
        <thead>
          <tr>
            <th style={{ ...cellStyle, width: '8%' }}>No</th>
            <th style={{ ...cellStyle }}>Nama Barang</th>
            <th style={{ ...cellStyle, width: '15%' }}>Banyaknya</th>
            <th style={{ ...cellStyle, width: '18%', textAlign: 'right' }}>Harga @ (Rp)</th>
            <th style={{ ...cellStyle, width: '20%', textAlign: 'right' }}>Jumlah (Rp)</th>
          </tr>
        </thead>
        <tbody>
          {bpu.items.map((item, idx) => (
            <tr key={item.id}>
              <td style={{ ...cellStyle, textAlign: 'center' }}>{idx + 1}</td>
              <td style={cellStyle}>{item.nama_barang}</td>
              <td style={{ ...cellStyle, textAlign: 'center' }}>{item.banyak_nya} {item.satuan}</td>
              <td style={{ ...cellStyle, textAlign: 'right' }}>{formatAngka(item.harga_satuan)}</td>
              <td style={{ ...cellStyle, textAlign: 'right' }}>{formatAngka(item.pengeluaran)}</td>
            </tr>
          ))}
          <tr>
            <td colSpan={4} style={{ ...cellStyle, textAlign: 'right', fontWeight: 'bold' }}>Jumlah</td>
            <td style={{ ...cellStyle, textAlign: 'right', fontWeight: 'bold' }}>{formatAngka(total)}</td>
          </tr>
        </tbody>
      </table>
      <table style={{ width: '100%', fontSize: '12px', marginTop: '20px' }}>
        <tbody>
          <tr>
            <td style={{ width: '55%' }}></td>
            <td style={{ textAlign: 'center' }}>
              <p style={{ margin: '0 0 4px 0' }}>{school.kota}, {tanggalPesananFormatted}</p>
              <p style={{ margin: '0 0 60px 0' }}>PIMPINAN,</p>
              <p style={{ margin: '0 0 2px 0', fontWeight: 'bold', textDecoration: 'underline' }}>{vendor?.nama_toko || ''}</p>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

// 4. BERITA ACARA PEMBAYARAN PENGADAAN BARANG/JASA
export function BeritaAcaraDoc({ bpu, pejabat }: DocData) {
  const { school, kepala, vendor, total, totalTerbilang, tanggalBayar, tanggalBayarFormatted } = useDocData({ bpu, pejabat });
  return (
    <div style={{ fontFamily: "'Arial',sans-serif", color: '#000' }}>
      <KopSurat />
      <h3 style={{ textAlign: 'center', fontSize: '14px', fontWeight: 'bold', textDecoration: 'underline', margin: '0 0 16px 0' }}>
        BERITA ACARA PEMBAYARAN PENGADAAN BARANG/JASA
      </h3>
      <p style={{ fontSize: '12px', textAlign: 'justify', margin: '0 0 12px 0', lineHeight: '1.5' }}>
        Pada hari ini {tanggalBayar}, yang bertanda tangan di bawah ini:
      </p>
      <table style={{ width: '100%', fontSize: '12px', borderCollapse: 'collapse', marginBottom: '16px' }}>
        <tbody>
          <tr>
            <td style={{ width: '5%', verticalAlign: 'top' }}>1.</td>
            <td style={{ width: '25%' }}>Nama</td>
            <td style={{ width: '3%' }}>:</td>
            <td>{kepala?.nama || ''}</td>
          </tr>
          <tr>
            <td></td>
            <td>Jabatan</td>
            <td>:</td>
            <td>Kepala Sekolah {school.namaSekolah} {school.kota}</td>
          </tr>
          <tr>
            <td></td>
            <td>NIP</td>
            <td>:</td>
            <td>{kepala?.nip || ''}</td>
          </tr>
          <tr>
            <td style={{ padding: '4px 0 0 0' }}></td>
            <td colSpan={3} style={{ padding: '4px 0 0 0' }}>Dalam hal ini bertindak untuk dan atas nama Pemerintah Kota {school.kota} selaku Pengguna Anggaran, selanjutnya disebut <strong>PIHAK PERTAMA</strong>.</td>
          </tr>
        </tbody>
      </table>
      <table style={{ width: '100%', fontSize: '12px', borderCollapse: 'collapse', marginBottom: '16px' }}>
        <tbody>
          <tr>
            <td style={{ width: '5%', verticalAlign: 'top' }}>2.</td>
            <td style={{ width: '25%' }}>Nama Perusahaan</td>
            <td style={{ width: '3%' }}>:</td>
            <td>{vendor?.nama_toko || ''}</td>
          </tr>
          <tr>
            <td></td>
            <td>Alamat</td>
            <td>:</td>
            <td>{vendor?.alamat_toko || ''}</td>
          </tr>
          <tr>
            <td></td>
            <td>Pimpinan</td>
            <td>:</td>
            <td>{vendor?.nama_toko || ''}</td>
          </tr>
          <tr>
            <td style={{ padding: '4px 0 0 0' }}></td>
            <td colSpan={3} style={{ padding: '4px 0 0 0' }}>Selanjutnya disebut <strong>PIHAK KEDUA</strong>.</td>
          </tr>
        </tbody>
      </table>
      <p style={{ fontSize: '12px', textAlign: 'justify', margin: '0 0 12px 0', lineHeight: '1.5' }}>
        PIHAK PERTAMA telah menerima pembayaran dari PIHAK KEDUA sehubungan dengan Surat Pesanan Nomor {bpu.no_bpu} untuk pengadaan barang dengan jumlah sebesar <strong>Rp {formatAngka(total)} ({totalTerbilang})</strong>.
      </p>
      <p style={{ fontSize: '12px', textAlign: 'justify', margin: '0 0 20px 0', lineHeight: '1.5' }}>
        Demikian berita acara ini dibuat dengan sebenarnya untuk dapat dipergunakan sebagaimana mestinya.
      </p>
      <table style={{ width: '100%', fontSize: '12px', marginTop: '20px' }}>
        <tbody>
          <tr>
            <td style={{ width: '50%', textAlign: 'center', verticalAlign: 'top' }}>
              <p style={{ margin: '0 0 4px 0' }}>{school.kota}, {tanggalBayarFormatted}</p>
              <p style={{ margin: '0 0 60px 0' }}>PIHAK KEDUA,</p>
              <p style={{ margin: '0 0 2px 0', fontWeight: 'bold', textDecoration: 'underline' }}>{vendor?.nama_toko || ''}</p>
            </td>
            <td style={{ width: '50%', textAlign: 'center', verticalAlign: 'top' }}>
              <p style={{ margin: '0 0 4px 0' }}>&nbsp;</p>
              <p style={{ margin: '0 0 60px 0' }}>PIHAK PERTAMA,</p>
              <p style={{ margin: '0 0 2px 0', fontWeight: 'bold', textDecoration: 'underline' }}>{kepala?.nama || ''}</p>
              <p style={{ margin: '0' }}>NIP. {kepala?.nip || ''}</p>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

// 5. LAMPIRAN BERITA ACARA PENERIMAAN HASIL PEKERJAAN
export function LampiranDoc({ bpu, pejabat }: DocData) {
  const { school, pengurusBarang, total, tanggalBayarFormatted } = useDocData({ bpu, pejabat });
  return (
    <div style={{ fontFamily: "'Arial',sans-serif", color: '#000' }}>
      <KopSurat />
      <h3 style={{ textAlign: 'center', fontSize: '13px', fontWeight: 'bold', textDecoration: 'underline', margin: '0 0 14px 0' }}>
        Lampiran Berita Acara Penerimaan Hasil Pekerjaan/Pemeriksaan Barang
      </h3>
      <table style={{ width: '100%', fontSize: '12px', borderCollapse: 'collapse', marginBottom: '20px' }}>
        <thead>
          <tr>
            <th style={{ ...cellStyle, width: '6%' }}>No</th>
            <th style={{ ...cellStyle }}>Nama Barang</th>
            <th style={{ ...cellStyle, width: '13%' }}>Banyaknya</th>
            <th style={{ ...cellStyle, width: '17%', textAlign: 'right' }}>Harga @ (Rp)</th>
            <th style={{ ...cellStyle, width: '19%', textAlign: 'right' }}>Jumlah (Rp)</th>
            <th style={{ ...cellStyle, width: '15%', textAlign: 'center' }}>Hasil Pemeriksaan</th>
          </tr>
        </thead>
        <tbody>
          {bpu.items.map((item, idx) => (
            <tr key={item.id}>
              <td style={{ ...cellStyle, textAlign: 'center' }}>{idx + 1}</td>
              <td style={cellStyle}>{item.nama_barang}</td>
              <td style={{ ...cellStyle, textAlign: 'center' }}>{item.banyak_nya} {item.satuan}</td>
              <td style={{ ...cellStyle, textAlign: 'right' }}>{formatAngka(item.harga_satuan)}</td>
              <td style={{ ...cellStyle, textAlign: 'right' }}>{formatAngka(item.pengeluaran)}</td>
              <td style={{ ...cellStyle, textAlign: 'center' }}>Baik</td>
            </tr>
          ))}
          <tr>
            <td colSpan={4} style={{ ...cellStyle, textAlign: 'right', fontWeight: 'bold' }}>Jumlah</td>
            <td style={{ ...cellStyle, textAlign: 'right', fontWeight: 'bold' }}>{formatAngka(total)}</td>
            <td style={cellStyle}></td>
          </tr>
        </tbody>
      </table>
      <table style={{ width: '100%', fontSize: '12px', marginTop: '24px' }}>
        <tbody>
          <tr>
            <td style={{ width: '55%' }}></td>
            <td style={{ textAlign: 'center' }}>
              <p style={{ margin: '0 0 4px 0' }}>{school.kota}, {tanggalBayarFormatted}</p>
              <p style={{ margin: '0 0 60px 0' }}>Ketua Penanggung Jawab Barang/Aset,</p>
              <p style={{ margin: '0 0 2px 0', fontWeight: 'bold', textDecoration: 'underline' }}>{pengurusBarang?.nama || ''}</p>
              <p style={{ margin: '0' }}>NIP. {pengurusBarang?.nip || ''}</p>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export const ALL_DOC_TYPES: DocType[] = ['order', 'tanda-terima', 'faktur', 'berita-acara', 'lampiran'];

export function renderDoc(type: DocType, data: DocData) {
  switch (type) {
    case 'order': return <OrderDoc {...data} />;
    case 'tanda-terima': return <TandaTerimaDoc {...data} />;
    case 'faktur': return <FakturDoc {...data} />;
    case 'berita-acara': return <BeritaAcaraDoc {...data} />;
    case 'lampiran': return <LampiranDoc {...data} />;
  }
}
