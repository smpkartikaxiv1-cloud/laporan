import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export const LOGO_KIRI_KEY = 'logo_kiri_dinas';
export const LOGO_KANAN_KEY = 'logo_kanan_sekolah';
export const LOGO_KOP_KEY = 'app_logo_kop';

interface LogoContextValue {
  logoKiri: string | null;
  logoKanan: string | null;
  logoKop: string | null;
  loading: boolean;
  refresh: () => void;
}

const LogoContext = createContext<LogoContextValue>({
  logoKiri: null,
  logoKanan: null,
  logoKop: null,
  loading: false,
  refresh: () => {},
});

export function LogoProvider({ children }: { children: ReactNode }) {
  const [logoKiri, setLogoKiri] = useState<string | null>(null);
  const [logoKanan, setLogoKanan] = useState<string | null>(null);
  const [logoKop, setLogoKop] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = () => {
    try {
      setLogoKiri(localStorage.getItem(LOGO_KIRI_KEY) || null);
      setLogoKanan(localStorage.getItem(LOGO_KANAN_KEY) || null);
      setLogoKop(localStorage.getItem(LOGO_KOP_KEY) || null);
    } catch {
      setLogoKiri(null);
      setLogoKanan(null);
      setLogoKop(null);
    }
    setLoading(false);
  };

  useEffect(() => {
    refresh();
  }, []);

  return (
    <LogoContext.Provider value={{ logoKiri, logoKanan, logoKop, loading, refresh }}>
      {children}
    </LogoContext.Provider>
  );
}

export function useLogo() {
  return useContext(LogoContext);
}

export function getLogoFromStorage(key: string): string | null {
  try {
    return localStorage.getItem(key) || null;
  } catch {
    return null;
  }
}

export function setLogoInStorage(key: string, base64: string): void {
  try {
    localStorage.setItem(key, base64);
  } catch {
    // ignore
  }
}

export function removeLogoFromStorage(key: string): void {
  try {
    localStorage.removeItem(key);
  } catch {
    // ignore
  }
}
