import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export const SCHOOL_IDENTITY_KEY = 'school_identity';

export interface SchoolIdentity {
  namaSekolah: string;
  kota: string;
  yayasan: string;
  alamat: string;
  email: string;
  website: string;
  kodePos: string;
  headerKop: string;
}

export const DEFAULT_SCHOOL_IDENTITY: SchoolIdentity = {
  namaSekolah: 'SMP Kartika XIV-1',
  kota: 'Banda Aceh',
  yayasan: 'Yayasan Kartika Jaya Cabang XIV Iskandar Muda',
  alamat: 'Jl. Nyak Adam Kamil II Peuniti Kecamatan Baiturrahman',
  email: 'smpkartikaxlv1@gmail.com',
  website: 'https://smpkartika.my.id',
  kodePos: '23241',
  headerKop: '',
};

interface SchoolContextValue {
  identity: SchoolIdentity;
  setIdentity: (identity: SchoolIdentity) => void;
}

const SchoolContext = createContext<SchoolContextValue>({
  identity: DEFAULT_SCHOOL_IDENTITY,
  setIdentity: () => {},
});

export function SchoolProvider({ children }: { children: ReactNode }) {
  const [identity, setIdentityState] = useState<SchoolIdentity>(DEFAULT_SCHOOL_IDENTITY);

  useEffect(() => {
    refreshIdentity();
  }, []);

  function refreshIdentity() {
    try {
      const raw = localStorage.getItem(SCHOOL_IDENTITY_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<SchoolIdentity>;
        setIdentityState({ ...DEFAULT_SCHOOL_IDENTITY, ...parsed });
      }
    } catch {
      // ignore
    }
  }

  function setIdentity(newIdentity: SchoolIdentity) {
    try {
      localStorage.setItem(SCHOOL_IDENTITY_KEY, JSON.stringify(newIdentity));
      setIdentityState(newIdentity);
    } catch {
      // ignore
    }
  }

  return (
    <SchoolContext.Provider value={{ identity, setIdentity }}>
      {children}
    </SchoolContext.Provider>
  );
}

export function useSchoolIdentity() {
  return useContext(SchoolContext);
}

export function getSchoolIdentityFromStorage(): SchoolIdentity {
  try {
    const raw = localStorage.getItem(SCHOOL_IDENTITY_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<SchoolIdentity>;
      return { ...DEFAULT_SCHOOL_IDENTITY, ...parsed };
    }
  } catch {
    // ignore
  }
  return DEFAULT_SCHOOL_IDENTITY;
}
