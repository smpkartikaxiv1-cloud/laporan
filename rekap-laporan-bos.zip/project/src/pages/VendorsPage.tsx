import { useState, useEffect, FormEvent } from 'react';
import { supabase } from '@/lib/supabase';
import { Vendor } from '@/lib/types';
import {
  Store, Plus, Pencil, Trash2, X, Loader2, AlertCircle, MapPin, Phone, Building2,
} from 'lucide-react';

interface VendorForm {
  id?: string;
  nama_toko: string;
  alamat_toko: string;
  telepon: string;
}

const EMPTY_FORM: VendorForm = { nama_toko: '', alamat_toko: '', telepon: '' };

export default function VendorsPage() {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState<VendorForm>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchVendors();
  }, []);

  async function fetchVendors() {
    setLoading(true);
    setError('');
    const { data, error } = await supabase
      .from('master_vendor')
      .select('*')
      .order('nama_toko');
    if (error) setError('Gagal memuat data vendor: ' + error.message);
    else setVendors(data || []);
    setLoading(false);
  }

  function openAdd() {
    setForm(EMPTY_FORM);
    setShowModal(true);
  }

  function openEdit(v: Vendor) {
    setForm({ id: v.id, nama_toko: v.nama_toko, alamat_toko: v.alamat_toko, telepon: v.telepon });
    setShowModal(true);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError('');
    if (form.id) {
      const { error } = await supabase
        .from('master_vendor')
        .update({
          nama_toko: form.nama_toko,
          alamat_toko: form.alamat_toko,
          telepon: form.telepon,
        })
        .eq('id', form.id);
      if (error) setError('Gagal memperbarui vendor: ' + error.message);
    } else {
      const { error } = await supabase.from('master_vendor').insert({
        nama_toko: form.nama_toko,
        alamat_toko: form.alamat_toko,
        telepon: form.telepon,
      });
      if (error) setError('Gagal menambah vendor: ' + error.message);
    }
    setSaving(false);
    if (!error) {
      setShowModal(false);
      fetchVendors();
    }
  }

  async function handleDelete(v: Vendor) {
    if (!confirm(`Hapus vendor "${v.nama_toko}"? Tindakan ini tidak dapat dibatalkan.`)) return;
    const { error } = await supabase.from('master_vendor').delete().eq('id', v.id);
    if (error) {
      setError('Gagal menghapus vendor: ' + error.message);
    } else {
      fetchVendors();
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
            <Store className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">Data Vendor</h1>
            <p className="text-slate-500 text-sm">Kelola daftar toko/penyedia barang</p>
          </div>
        </div>
        <button
          onClick={openAdd}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500/40 transition"
        >
          <Plus className="w-4 h-4" />
          Tambah Vendor
        </button>
      </div>

      {error && (
        <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Grid */}
      {vendors.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 py-16 text-center">
          <Store className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">Belum ada data vendor</p>
          <p className="text-slate-400 text-sm mt-1">Klik "Tambah Vendor" untuk mulai menambahkan</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {vendors.map((v) => (
            <div
              key={v.id}
              className="group bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition p-5"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-blue-500" />
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition">
                  <button
                    onClick={() => openEdit(v)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition"
                    title="Edit"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(v)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                    title="Hapus"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <h3 className="font-semibold text-slate-800 text-sm leading-snug mb-2">{v.nama_toko}</h3>
              {v.alamat_toko && (
                <p className="flex items-start gap-1.5 text-xs text-slate-500 mb-1.5">
                  <MapPin className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                  <span className="line-clamp-2">{v.alamat_toko}</span>
                </p>
              )}
              {v.telepon && (
                <p className="flex items-center gap-1.5 text-xs text-slate-500">
                  <Phone className="w-3.5 h-3.5 flex-shrink-0" />
                  {v.telepon}
                </p>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <h2 className="text-base font-semibold text-slate-800">
                {form.id ? 'Edit Vendor' : 'Tambah Vendor'}
              </h2>
              <button
                onClick={() => setShowModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Nama Toko / Vendor</label>
                <input
                  type="text"
                  value={form.nama_toko}
                  onChange={(e) => setForm({ ...form, nama_toko: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                  placeholder="CV. DUNIA KOMPUTER"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Alamat Toko</label>
                <textarea
                  value={form.alamat_toko}
                  onChange={(e) => setForm({ ...form, alamat_toko: e.target.value })}
                  rows={2}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition resize-none"
                  placeholder="Jl. ..."
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Telepon</label>
                <input
                  type="text"
                  value={form.telepon}
                  onChange={(e) => setForm({ ...form, telepon: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                  placeholder="0812..."
                />
              </div>
              {error && (
                <div className="flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-xs text-red-700">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 rounded-xl text-slate-600 font-medium text-sm hover:bg-slate-100 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 transition disabled:opacity-60"
                >
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                  {form.id ? 'Simpan' : 'Tambah'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
