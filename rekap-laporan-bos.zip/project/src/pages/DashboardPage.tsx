import { useState, useEffect, Fragment } from 'react';
import * as XLSX from 'xlsx';
import { supabase } from '@/lib/supabase';
import { BpuFull, Pejabat, Vendor, BPU, DetailBarang } from '@/lib/types';
import { formatRupiah } from '@/lib/terbilang';
import { printBundle, printSingleDoc, printBatchTandaTerima } from '@/lib/printUtils';
import { downloadWordDoc, downloadWordBundle, downloadWordBatchTandaTerima } from '@/lib/wordExport';
import { DocType } from '@/components/DocTemplates';
import ExcelUpload from '@/components/ExcelUpload';
import VendorImport from '@/components/VendorImport';
import {
  LayoutDashboard, FilePlus, Printer, Loader2, AlertCircle, Trash2,
  Calendar, Store, FileText, Package, FileStack, FileType,
  FileCheck2, Receipt, ScrollText, ClipboardCheck, ChevronDown, Pencil,
  Download, Upload, Edit3,
} from 'lucide-react';
import EditBpuModal from '@/components/EditBpuModal';
import { exportYaituExcel, importYaituExcel } from '@/lib/yaituExcel';

interface DashboardPageProps {
  onCreateNew: () => void;
}

export default function DashboardPage({ onCreateNew }: DashboardPageProps) {
  const [bpus, setBpus] = useState<BpuFull[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [pejabatMap, setPejabatMap] = useState<Record<string, Pejabat>>({});
  const [expandedRow, setExpandedRow] = useState<string | null>(null);
  const [wordLoading, setWordLoading] = useState<string | null>(null);
  const [editingBpu, setEditingBpu] = useState<BpuFull | null>(null);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [selectedBpus, setSelectedBpus] = useState<Set<string>>(new Set());
  const [batchLoading, setBatchLoading] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [yaituImporting, setYaituImporting] = useState(false);

  function showToast(type: 'success' | 'error', msg: string) {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 4000);
  }

  useEffect(() => {
    fetchAll();
  }, []);

  function downloadTemplate() {
    const headers = [
      'No. BPU', 'Tanggal Pesanan', 'Tanggal Pembayaran', 'Nama Barang',
      'Banyaknya', 'Harga Satuan (Rp)', 'Jumlah (Rp)', 'Total (Rp) Per BPU',
      'Vendor / Penyedia', 'Keterangan',
    ];
    const sampleData: (string | number | { t: string; f: string; v: number })[][] = [
      ['BPU-001', '2024-01-15', '2024-01-20', 'Kertas A4 80gsm', 10, 55000, { t: 'n', f: 'F2*E2', v: 550000 }, { t: 'n', f: 'SUMIF($A:$A,A2,$G:$G)', v: 720000 }, 'Toko Sumber Rezeki', 'Pembelian kertas administrasi'],
      ['BPU-001', '2024-01-15', '2024-01-20', 'Tinta Printer Canon', 2, 85000, { t: 'n', f: 'F3*E3', v: 170000 }, { t: 'n', f: 'SUMIF($A:$A,A3,$G:$G)', v: 720000 }, 'Toko Sumber Rezeki', ''],
      ['BPU-002', '2024-02-10', '2024-02-15', 'Spidol Boardmarker', 12, 15000, { t: 'n', f: 'F4*E4', v: 180000 }, { t: 'n', f: 'SUMIF($A:$A,A4,$G:$G)', v: 180000 }, 'Toko Sentosa Jaya', 'Pengadaan alat tulis kantor'],
    ];
    const aoa = [headers, ...sampleData];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = [
      { wch: 12 }, { wch: 16 }, { wch: 18 }, { wch: 26 }, { wch: 10 },
      { wch: 16 }, { wch: 16 }, { wch: 20 }, { wch: 24 }, { wch: 30 },
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Template BPU');
    XLSX.writeFile(wb, 'Template_Import_BPU_BOS.xlsx');
  }

  async function fetchAll() {
    setLoading(true);
    setError('');
    try {
      const [bpuRes, pejabatRes, vendorAllRes] = await Promise.all([
        supabase.from('transaksi_bpu').select('*').order('no_bpu'),
        supabase.from('master_pejabat').select('*'),
        supabase.from('master_vendor').select('*').order('nama_toko'),
      ]);
      if (bpuRes.error) throw new Error(bpuRes.error.message);
      if (pejabatRes.error) throw new Error(pejabatRes.error.message);
      if (vendorAllRes.error) throw new Error(vendorAllRes.error.message);
      setVendors(vendorAllRes.data || []);

      const bpuRows = (bpuRes.data || []) as BPU[];
      const pejabatRows = (pejabatRes.data || []) as Pejabat[];
      const pMap: Record<string, Pejabat> = {};
      pejabatRows.forEach((p) => { pMap[p.peran] = p; });
      setPejabatMap(pMap);

      if (bpuRows.length === 0) {
        setBpus([]);
        setLoading(false);
        return;
      }

      const vendorIds = [...new Set(bpuRows.map((b) => b.vendor_id).filter(Boolean))];
      const bpuIds = bpuRows.map((b) => b.no_bpu);

      const [vendorRes, detailRes] = await Promise.all([
        vendorIds.length > 0
          ? supabase.from('master_vendor').select('*').in('id', vendorIds)
          : Promise.resolve({ data: [], error: null }),
        supabase.from('detail_barang_bpu').select('*').in('bpu_id', bpuIds).order('created_at'),
      ]);
      if (vendorRes.error) throw new Error(vendorRes.error.message);
      if (detailRes.error) throw new Error(detailRes.error.message);

      const vendorMap: Record<string, Vendor> = {};
      (vendorRes.data || []).forEach((v: Vendor) => { vendorMap[v.id] = v; });

      const itemsByBpu: Record<string, DetailBarang[]> = {};
      (detailRes.data || []).forEach((d: DetailBarang) => {
        if (!itemsByBpu[d.bpu_id]) itemsByBpu[d.bpu_id] = [];
        itemsByBpu[d.bpu_id].push(d);
      });

      const full = bpuRows.map((b) => {
        const allItems = itemsByBpu[b.no_bpu] || [];
        const items = allItems.filter((i) => {
          const val = Number(i.pengeluaran);
          return !isNaN(val) && val >= 0;
        });
        const total = items.reduce((sum, i) => sum + Number(i.pengeluaran), 0);
        return { ...b, vendor: vendorMap[b.vendor_id] || null, items, total };
      }).filter((b) => b.items.length > 0);
      setBpus(full);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal memuat data');
    }
    setLoading(false);
  }

  async function handleDelete(bpu: BpuFull) {
    if (!confirm(`Hapus BPU ${bpu.no_bpu}? Semua detail barang akan ikut terhapus.`)) return;
    const { error } = await supabase.from('transaksi_bpu').delete().eq('no_bpu', bpu.no_bpu);
    if (error) {
      setError('Gagal menghapus BPU: ' + error.message);
    } else {
      fetchAll();
    }
  }

  const docActions: { type: DocType; label: string; icon: typeof FileText; color: string }[] = [
    { type: 'order', label: 'Order', icon: FileText, color: 'text-blue-600 hover:bg-blue-50' },
    { type: 'tanda-terima', label: 'Tanda Terima', icon: Receipt, color: 'text-cyan-600 hover:bg-cyan-50' },
    { type: 'faktur', label: 'Faktur', icon: FileCheck2, color: 'text-emerald-600 hover:bg-emerald-50' },
    { type: 'berita-acara', label: 'Berita Acara', icon: ScrollText, color: 'text-amber-600 hover:bg-amber-50' },
    { type: 'lampiran', label: 'Lampiran', icon: ClipboardCheck, color: 'text-purple-600 hover:bg-purple-50' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
      </div>
    );
  }

  function toggleSelectBpu(noBpu: string) {
    setSelectedBpus((prev) => {
      const next = new Set(prev);
      if (next.has(noBpu)) next.delete(noBpu);
      else next.add(noBpu);
      return next;
    });
  }

  function toggleSelectAll() {
    setSelectedBpus((prev) => {
      if (prev.size === bpus.length) return new Set();
      return new Set(bpus.map((b) => b.no_bpu));
    });
  }

  function handleBatchPrint() {
    const selected = bpus.filter((b) => selectedBpus.has(b.no_bpu));
    if (selected.length === 0) return;
    setBatchLoading(true);
    setTimeout(() => {
      printBatchTandaTerima(selected, pejabatMap);
      setBatchLoading(false);
    }, 100);
  }

  function handlePrintAllTandaTerima() {
    if (bpus.length === 0) return;
    setBatchLoading(true);
    setTimeout(() => {
      printBatchTandaTerima(bpus, pejabatMap);
      setBatchLoading(false);
    }, 100);
  }

  async function handleWordBatch(bpusToDownload: BpuFull[], key: string) {
    if (bpusToDownload.length === 0) return;
    setWordLoading(key);
    try {
      await downloadWordBatchTandaTerima(bpusToDownload, pejabatMap);
      showToast('success', `Berhasil mengunduh ${bpusToDownload.length} Tanda Penerimaan sebagai Word (.docx).`);
    } catch (err) {
      showToast('error', 'Gagal mengunduh Word: ' + (err instanceof Error ? err.message : 'kesalahan tidak diketahui'));
    } finally {
      setWordLoading(null);
    }
  }

  async function handleWordSingle(bpu: BpuFull, type: DocType, key: string) {
    setWordLoading(key);
    try {
      await downloadWordDoc(bpu, pejabatMap, type);
      showToast('success', `Berhasil mengunduh ${type === 'tanda-terima' ? 'Tanda Penerimaan' : type} sebagai Word (.docx).`);
    } catch (err) {
      showToast('error', 'Gagal mengunduh Word: ' + (err instanceof Error ? err.message : 'kesalahan tidak diketahui'));
    } finally {
      setWordLoading(null);
    }
  }

  function handleExportYaitu() {
    if (bpus.length === 0) return;
    exportYaituExcel(bpus);
    showToast('success', 'File Excel Data Uraian YAITU berhasil diunduh.');
  }

  async function handleImportYaitu(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setYaituImporting(true);
    try {
      const result = await importYaituExcel(file);
      if (result.updated > 0) {
        showToast('success', `Berhasil memperbarui ${result.updated} data Uraian YAITU.`);
        fetchAll();
      } else {
        showToast('error', 'Tidak ada data yang diperbarui. Periksa kembali file Excel Anda.');
      }
    } catch (err) {
      showToast('error', 'Gagal mengimpor file: ' + (err instanceof Error ? err.message : 'kesalahan tidak diketahui'));
    } finally {
      setYaituImporting(false);
      e.target.value = '';
    }
  }

  async function handleWordBundle(bpu: BpuFull, key: string) {
    setWordLoading(key);
    try {
      await downloadWordBundle(bpu, pejabatMap);
      showToast('success', 'Berhasil mengunduh Paket SPJ sebagai Word (.docx).');
    } catch (err) {
      showToast('error', 'Gagal mengunduh Word: ' + (err instanceof Error ? err.message : 'kesalahan tidak diketahui'));
    } finally {
      setWordLoading(null);
    }
  }

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-700 flex items-center justify-center">
            <LayoutDashboard className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">Dashboard BPU</h1>
            <p className="text-slate-500 text-sm">Daftar Bukti Pengeluaran Uang</p>
          </div>
        </div>
        <button
          onClick={onCreateNew}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500/40 transition"
        >
          <FilePlus className="w-4 h-4" />
          Input BPU Baru
        </button>
      </div>

      {error && (
        <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Excel Upload + Download Template */}
      <div className="mb-6 flex flex-wrap items-center gap-3">
        <ExcelUpload onUploaded={fetchAll} />
        <button
          onClick={downloadTemplate}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-semibold text-sm border border-slate-200 hover:bg-slate-200 transition"
          title="Download Template Excel"
        >
          <Download className="w-4 h-4" />
          Download Template Excel
        </button>
      </div>

      {/* Edit Kolektif Uraian YAITU */}
      {bpus.length > 0 && (
        <div className="mb-6 flex flex-wrap items-center gap-3 bg-indigo-50/60 border border-indigo-200 rounded-2xl px-4 py-3">
          <div className="flex items-center gap-2 text-sm text-indigo-700">
            <Edit3 className="w-4 h-4 text-indigo-600" />
            <span className="font-medium">Edit Kolektif Uraian YAITU:</span>
            <span className="text-xs text-indigo-500">Export, edit teks uraian di Excel, lalu import ulang</span>
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <button
              onClick={handleExportYaitu}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white text-indigo-700 font-semibold text-sm border border-indigo-200 hover:bg-indigo-50 transition"
            >
              <Download className="w-4 h-4" />
              Download Data Uraian (YAITU) .xlsx
            </button>
            <label className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold text-sm shadow-sm hover:bg-indigo-700 transition cursor-pointer disabled:opacity-60">
              {yaituImporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              {yaituImporting ? 'Mengimpor...' : 'Upload / Re-import Excel Uraian'}
              <input
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleImportYaitu}
                disabled={yaituImporting}
              />
            </label>
          </div>
        </div>
      )}

      {/* Stats + Vendor Import */}
      {bpus.length > 0 && (
        <div className="flex flex-col gap-4 mb-6">
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-xs text-slate-500 font-medium mb-1">Total BPU</p>
            <p className="text-2xl font-bold text-slate-800">{bpus.length}</p>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-xs text-slate-500 font-medium mb-1">Total Item</p>
            <p className="text-2xl font-bold text-slate-800">
              {bpus.reduce((sum, b) => sum + b.items.length, 0)}
            </p>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5 col-span-2 lg:col-span-1">
            <p className="text-xs text-slate-500 font-medium mb-1">Total Nilai</p>
            <p className="text-2xl font-bold text-amber-600">{(() => { const grandTotal = bpus.reduce((s, b) => s + b.total, 0); return grandTotal > 0 ? formatRupiah(grandTotal) : '-'; })()}</p>
          </div>
        </div>
        <div className="flex justify-end">
          <VendorImport bpus={bpus} onImported={fetchAll} />
        </div>
      </div>
      )}

      {/* Batch Print Toolbar */}
      {bpus.length > 0 && (
        <div className="mb-4 flex flex-wrap items-center gap-3 bg-white rounded-2xl border border-slate-200 px-4 py-3">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Receipt className="w-4 h-4 text-cyan-600" />
            <span className="font-medium">Cetak Tanda Penerimaan:</span>
            {selectedBpus.size > 0 && (
              <span className="text-xs text-cyan-600 font-semibold bg-cyan-50 px-2 py-0.5 rounded-full">
                {selectedBpus.size} dipilih
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <button
              onClick={handleBatchPrint}
              disabled={selectedBpus.size === 0 || batchLoading}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 text-white font-semibold text-sm shadow-sm hover:bg-cyan-700 transition disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {batchLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />}
              Cetak Terpilih{selectedBpus.size > 0 ? ` (${selectedBpus.size})` : ''}
            </button>
            <button
              onClick={handlePrintAllTandaTerima}
              disabled={batchLoading}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-700 text-white font-semibold text-sm shadow-sm hover:bg-slate-800 transition disabled:opacity-40"
            >
              {batchLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileStack className="w-4 h-4" />}
              Cetak Semua ({bpus.length})
            </button>
            <button
              onClick={() => handleWordBatch(bpus.filter((b) => selectedBpus.has(b.no_bpu)), 'batch-selected')}
              disabled={wordLoading !== null || selectedBpus.size === 0}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 text-white font-semibold text-sm shadow-sm hover:bg-blue-700 transition disabled:opacity-40"
            >
              {wordLoading === 'batch-selected' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileType className="w-4 h-4" />}
              Word Terpilih{selectedBpus.size > 0 ? ` (${selectedBpus.size})` : ''}
            </button>
            <button
              onClick={() => handleWordBatch(bpus, 'batch-all')}
              disabled={wordLoading !== null}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-800 text-white font-semibold text-sm shadow-sm hover:bg-blue-900 transition disabled:opacity-40"
            >
              {wordLoading === 'batch-all' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileType className="w-4 h-4" />}
              Word Semua ({bpus.length})
            </button>
          </div>
        </div>
      )}

      {/* Table */}
      {bpus.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 py-16 text-center">
          <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">Belum ada data BPU</p>
          <p className="text-slate-400 text-sm mt-1">Klik "Input BPU Baru" atau unggah file Excel untuk memulai</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                  <th className="px-4 py-3 text-center font-semibold w-10">
                    <input
                      type="checkbox"
                      checked={selectedBpus.size === bpus.length && bpus.length > 0}
                      onChange={toggleSelectAll}
                      className="w-4 h-4 rounded border-slate-300 text-cyan-500 focus:ring-cyan-500/30 cursor-pointer"
                    />
                  </th>
                  <th className="px-4 py-3 text-left font-semibold">No. BPU</th>
                  <th className="px-4 py-3 text-left font-semibold hidden sm:table-cell">Tanggal Pesanan</th>
                  <th className="px-4 py-3 text-left font-semibold hidden md:table-cell">Tanggal Bayar</th>
                  <th className="px-4 py-3 text-left font-semibold hidden lg:table-cell">Vendor</th>
                  <th className="px-4 py-3 text-center font-semibold">Items</th>
                  <th className="px-4 py-3 text-right font-semibold">Total</th>
                  <th className="px-4 py-3 text-center font-semibold">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {bpus.map((b) => (
                  <Fragment key={b.no_bpu}>
                    <tr className={`transition ${selectedBpus.has(b.no_bpu) ? 'bg-cyan-50/50' : 'hover:bg-slate-50/50'}`}>
                      <td className="px-4 py-3.5 text-center">
                        <input
                          type="checkbox"
                          checked={selectedBpus.has(b.no_bpu)}
                          onChange={() => toggleSelectBpu(b.no_bpu)}
                          className="w-4 h-4 rounded border-slate-300 text-cyan-500 focus:ring-cyan-500/30 cursor-pointer"
                        />
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="font-semibold text-slate-800">{b.no_bpu}</span>
                      </td>
                      <td className="px-4 py-3.5 text-slate-600 hidden sm:table-cell">
                        <span className="inline-flex items-center gap-1.5 text-xs">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          {new Date(b.tanggal_pesanan).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-slate-600 hidden md:table-cell">
                        <span className="inline-flex items-center gap-1.5 text-xs">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          {new Date(b.tanggal_pembayaran).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 hidden lg:table-cell">
                        <span className="inline-flex items-center gap-1.5 text-xs text-slate-600">
                          <Store className="w-3.5 h-3.5 text-slate-400" />
                          {b.vendor?.nama_toko || '-'}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-center text-slate-600">{b.items.length}</td>
                      <td className="px-4 py-3.5 text-right font-semibold text-slate-700">{b.total > 0 ? formatRupiah(b.total) : '-'}</td>
                      <td className="px-4 py-3.5">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* Print All Bundle */}
                          <button
                            onClick={() => printBundle(b, pejabatMap)}
                            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-amber-500 text-white font-medium text-xs hover:bg-amber-600 shadow-sm shadow-amber-500/20 transition"
                            title="Cetak Semua (Paket SPJ)"
                          >
                            <FileStack className="w-3.5 h-3.5" />
                            <span className="hidden xl:inline">Cetak Semua</span>
                          </button>
                          {/* Download Word Bundle */}
                          <button
                            onClick={() => handleWordBundle(b, `bundle-${b.no_bpu}`)}
                            disabled={wordLoading === `bundle-${b.no_bpu}`}
                            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-blue-500 text-white font-medium text-xs hover:bg-blue-600 shadow-sm shadow-blue-500/20 transition disabled:opacity-60"
                            title="Download Word (Paket SPJ)"
                          >
                            {wordLoading === `bundle-${b.no_bpu}` ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileType className="w-3.5 h-3.5" />}
                            <span className="hidden xl:inline">Word Semua</span>
                          </button>
                          {/* Expand individual downloads */}
                          <button
                            onClick={() => setExpandedRow(expandedRow === b.no_bpu ? null : b.no_bpu)}
                            className="inline-flex items-center gap-1 px-2.5 py-2 rounded-lg bg-slate-100 text-slate-600 font-medium text-xs hover:bg-slate-200 transition"
                            title="Download Dokumen Individual"
                          >
                            <Package className="w-3.5 h-3.5" />
                            <ChevronDown className={`w-3 h-3 transition ${expandedRow === b.no_bpu ? 'rotate-180' : ''}`} />
                          </button>
                          <button
                            onClick={() => setEditingBpu(b)}
                            className="p-2 rounded-lg text-slate-400 hover:text-amber-500 hover:bg-amber-50 transition"
                            title="Edit"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(b)}
                            className="p-2 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                            title="Hapus"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                    {expandedRow === b.no_bpu && (
                      <tr className="bg-slate-50/70">
                        <td colSpan={8} className="px-4 py-4">
                          <div className="flex flex-wrap gap-2">
                            {docActions.map((action) => {
                              const Icon = action.icon;
                              const wKey = `word-${b.no_bpu}-${action.type}`;
                              return (
                                <div key={action.type} className="flex items-center gap-1.5">
                                  <button
                                    onClick={() => printSingleDoc(b, pejabatMap, action.type)}
                                    className={`inline-flex items-center gap-2 px-3.5 py-2.5 rounded-lg bg-white border border-slate-200 font-medium text-xs ${action.color} transition shadow-sm`}
                                  >
                                    <Icon className="w-4 h-4" />
                                    {action.label}
                                  </button>
                                  <button
                                    onClick={() => handleWordSingle(b, action.type, wKey)}
                                    disabled={wordLoading === wKey}
                                    className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 font-medium text-xs hover:bg-blue-100 transition shadow-sm disabled:opacity-60"
                                    title={`Download Word (.docx) - ${action.label}`}
                                  >
                                    {wordLoading === wKey ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileType className="w-3.5 h-3.5" />}
                                    Word
                                  </button>
                                </div>
                              );
                            })}
                          </div>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {editingBpu && (
        <EditBpuModal
          bpu={editingBpu}
          vendors={vendors}
          onClose={() => setEditingBpu(null)}
          onSaved={() => {
            setEditingBpu(null);
            fetchAll();
          }}
        />
      )}

      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 flex items-center gap-2.5 rounded-xl px-4 py-3 text-sm font-medium shadow-lg ${toast.type === 'success' ? 'bg-green-50 border border-green-200 text-green-700' : 'bg-red-50 border border-red-200 text-red-700'}`}>
          {toast.type === 'success' ? (
            <svg className="w-5 h-5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          ) : (
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
          )}
          <span>{toast.msg}</span>
        </div>
      )}
    </div>
  );
}
