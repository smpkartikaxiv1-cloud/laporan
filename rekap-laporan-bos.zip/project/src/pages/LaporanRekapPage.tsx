import { useState, useEffect, useMemo, Fragment, Component, ReactNode } from 'react';
import * as XLSX from 'xlsx';
import { supabase } from '@/lib/supabase';
import { BpuFull, Pejabat, Vendor, BPU, DetailBarang } from '@/lib/types';
import { formatRupiah } from '@/lib/terbilang';
import { useSchoolIdentity, getSchoolIdentityFromStorage } from '@/context/SchoolContext';
import {
  ClipboardList, Loader2, AlertCircle, FileSpreadsheet, Printer,
  Calendar, Search, X, ChevronUp, ChevronDown, AlertTriangle,
} from 'lucide-react';

const REPORT_TITLE = 'Laporan Rekapitulasi BPU Dana BOS';

class LaporanErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean; error: string }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: '' };
  }
  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error: error.message || 'Terjadi kesalahan tidak diketahui' };
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="max-w-2xl mx-auto py-20 text-center">
          <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
          <h2 className="text-lg font-semibold text-slate-800 mb-2">Gagal memuat Laporan Rekap BPU</h2>
          <p className="text-sm text-slate-500 mb-1">Terjadi kesalahan saat menampilkan data laporan.</p>
          <p className="text-xs text-slate-400 mb-4">{this.state.error}</p>
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={() => this.setState({ hasError: false, error: '' })}
              className="px-5 py-2.5 rounded-xl bg-slate-200 text-slate-700 font-semibold text-sm hover:bg-slate-300 transition"
            >
              Reset Filter
            </button>
            <button
              onClick={() => window.location.reload()}
              className="px-5 py-2.5 rounded-xl bg-amber-500 text-white font-semibold text-sm hover:bg-amber-600 transition"
            >
              Muat Ulang
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function LaporanRekapContent() {
  const { identity: school } = useSchoolIdentity();
  const schoolName = `${school.namaSekolah || ''} ${school.kota || ''}`.trim();
  const [bpus, setBpus] = useState<BpuFull[]>([]);
  const [pejabatMap, setPejabatMap] = useState<Record<string, Pejabat>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [periode, setPeriode] = useState(() => {
    const y = new Date().getFullYear();
    return `${y}`;
  });
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [grouped, setGrouped] = useState(true);

  useEffect(() => {
    fetchAll();
  }, []);

  async function fetchAll() {
    setLoading(true);
    setError('');
    try {
      const [bpuRes, vendorRes, detailRes, pejabatRes] = await Promise.all([
        supabase.from('transaksi_bpu').select('*').order('no_bpu'),
        supabase.from('master_vendor').select('*'),
        supabase.from('detail_barang_bpu').select('*').order('created_at'),
        supabase.from('master_pejabat').select('*'),
      ]);
      if (bpuRes.error) throw new Error(bpuRes.error.message);
      if (vendorRes.error) throw new Error(vendorRes.error.message);
      if (detailRes.error) throw new Error(detailRes.error.message);
      if (pejabatRes.error) throw new Error(pejabatRes.error.message);

      const vendorMap: Record<string, Vendor> = {};
      (vendorRes.data || []).forEach((v: Vendor) => { vendorMap[v.id] = v; });

      const pMap: Record<string, Pejabat> = {};
      (pejabatRes.data || []).forEach((p: Pejabat) => { pMap[p.peran] = p; });
      setPejabatMap(pMap);

      const itemsByBpu: Record<string, DetailBarang[]> = {};
      (detailRes.data || []).forEach((d: DetailBarang) => {
        if (!itemsByBpu[d.bpu_id]) itemsByBpu[d.bpu_id] = [];
        itemsByBpu[d.bpu_id].push(d);
      });

      const full: BpuFull[] = (bpuRes.data || []).map((b: BPU) => {
        const allItems = itemsByBpu[b.no_bpu] || [];
        const items = (allItems || []).filter((i) => {
          const val = Number(i.pengeluaran);
          return !isNaN(val) && val >= 0;
        });
        const total = items.reduce((sum, i) => sum + Number(i.pengeluaran), 0);
        return { ...b, vendor: vendorMap[b.vendor_id] || null, items, total };
      }).filter((b) => b.items.length > 0);

      setBpus(full);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal memuat data');
    }
    setLoading(false);
  }

  const filtered = useMemo(() => {
    return bpus.filter((b) => {
      if (search) {
        const q = search.toLowerCase();
        const matchBpu = b.no_bpu.toLowerCase().includes(q);
        const matchVendor = (b.vendor?.nama_toko || '').toLowerCase().includes(q);
        const matchItem = b.items.some((i) => i.nama_barang.toLowerCase().includes(q));
        if (!matchBpu && !matchVendor && !matchItem) return false;
      }
      if (dateFrom && b.tanggal_pesanan < dateFrom) return false;
      if (dateTo && b.tanggal_pesanan > dateTo) return false;
      return true;
    });
  }, [bpus, search, dateFrom, dateTo]);

  // Flat rows for display & export
  const flatRows = useMemo(() => {
    const rows: {
      no: number;
      noBpu: string;
      kodeKegiatan: string;
      kodeRekening: string;
      noItem: number;
      namaBarang: string;
      qty: number;
      satuan: string;
      hargaSatuan: number;
      jumlahTotal: number;
    }[] = [];
    let no = 0;
    for (const b of filtered) {
      b.items.forEach((item, idx) => {
        no++;
        rows.push({
          no,
          noBpu: b.no_bpu,
          kodeKegiatan: b.kode_kegiatan || '',
          kodeRekening: b.kode_rekening || '',
          noItem: idx + 1,
          namaBarang: item.nama_barang,
          qty: item.banyak_nya,
          satuan: item.satuan,
          hargaSatuan: Number(item.harga_satuan),
          jumlahTotal: Number(item.pengeluaran),
        });
      });
    }
    return rows;
  }, [filtered]);

  const grandTotal = useMemo(() => {
    return filtered.reduce((sum, b) => sum + b.total, 0);
  }, [filtered]);

  function toggleGroup(noBpu: string) {
    setExpandedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(noBpu)) next.delete(noBpu);
      else next.add(noBpu);
      return next;
    });
  }

  function clearFilters() {
    setSearch('');
    setDateFrom('');
    setDateTo('');
  }

  function handlePrint() {
    window.print();
  }

  function exportExcel() {
    const headers = [
      'No.', 'No. BPU', 'Kode Kegiatan', 'Kode Rekening', 'No. Item',
      'Nama Barang / Belanja', 'Jumlah (Qty)', 'Satuan',
      'Harga Satuan (Rp)', 'Jumlah Total (Rp)',
    ];
    const dataRows = flatRows.map((r) => [
      r.no, r.noBpu, r.kodeKegiatan, r.kodeRekening, r.noItem,
      r.namaBarang, r.qty, r.satuan, r.hargaSatuan, r.jumlahTotal,
    ]);
    const grandTotalRow = ['', '', '', '', '', '', '', '', 'GRAND TOTAL', grandTotal];

    const aoa: (string | number)[][] = [
      [schoolName],
      [REPORT_TITLE],
      [`Tahun Anggaran: ${periode}`],
      [],
      headers,
      ...dataRows,
      grandTotalRow,
    ];

    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = [
      { wch: 5 }, { wch: 12 }, { wch: 16 }, { wch: 24 }, { wch: 8 },
      { wch: 30 }, { wch: 10 }, { wch: 10 }, { wch: 16 }, { wch: 18 },
    ];
    // Merge school name / title / periode across all columns
    ws['!merges'] = [
      { s: { r: 0, c: 0 }, e: { r: 0, c: 9 } },
      { s: { r: 1, c: 0 }, e: { r: 1, c: 9 } },
      { s: { r: 2, c: 0 }, e: { r: 2, c: 9 } },
    ];
    // Number format for currency columns (I, J = indices 8, 9)
    const lastDataRow = dataRows.length + 4;
    for (let r = 4; r <= lastDataRow; r++) {
      const cellI = ws[XLSX.utils.encode_cell({ r, c: 8 })];
      const cellJ = ws[XLSX.utils.encode_cell({ r, c: 9 })];
      if (cellI) cellI.z = '#,##0';
      if (cellJ) cellJ.z = '#,##0';
    }

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Rekap BPU');
    XLSX.writeFile(wb, `Laporan_Rekapitulasi_BPU_${periode}.xlsx`);
  }

  const kepalaSekolah = pejabatMap['Kepala Sekolah'] || pejabatMap['kepala_sekolah'];
  const bendahara = pejabatMap['Bendahara'] || pejabatMap['bendahara'];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Print-only section */}
      <div className="hidden print:block">
        <PrintLaporan
          bpus={filtered}
          grandTotal={grandTotal}
          periode={periode}
          kepalaSekolah={kepalaSekolah}
          bendahara={bendahara}
          schoolName={schoolName}
          schoolKota={school.kota || ''}
        />
      </div>

      {/* Screen UI */}
      <div className="print:hidden">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-700 flex items-center justify-center">
              <ClipboardList className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-800">Laporan Rekapitulasi BPU</h1>
              <p className="text-slate-500 text-sm">Rekap seluruh BPU untuk keperluan audit Dinas Pendidikan</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={exportExcel}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 text-white font-semibold text-sm shadow-lg shadow-emerald-500/20 hover:bg-emerald-600 transition"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Export Excel
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 transition"
            >
              <Printer className="w-4 h-4" />
              Cetak / PDF
            </button>
          </div>
        </div>

        {/* Kop Laporan */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 mb-6 text-center">
          <h2 className="text-lg font-bold text-slate-800">{schoolName}</h2>
          <h3 className="text-base font-semibold text-slate-700 mt-1">{REPORT_TITLE}</h3>
          <div className="flex items-center justify-center gap-2 mt-2">
            <label className="text-sm text-slate-500">Tahun Anggaran:</label>
            <input
              type="text"
              value={periode}
              onChange={(e) => setPeriode(e.target.value)}
              className="px-2 py-1 rounded-lg border border-slate-200 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500/30 w-24"
              placeholder="2024"
            />
          </div>
        </div>

        {error && (
          <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Filters */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 mb-6">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Cari No. BPU, Vendor, atau Nama Barang..."
                className="w-full pl-10 pr-3 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-200 text-slate-600 font-medium text-sm hover:bg-slate-50 transition"
            >
              <Calendar className="w-4 h-4" />
              Filter Tanggal
              {(dateFrom || dateTo) && <span className="w-2 h-2 rounded-full bg-amber-500" />}
            </button>
            <div className="flex items-center gap-2">
              <label className="text-sm text-slate-600 select-none">Tampilan:</label>
              <button
                onClick={() => setGrouped(true)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition ${
                  grouped ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                }`}
              >
                Dikelompokkan
              </button>
              <button
                onClick={() => setGrouped(false)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition ${
                  !grouped ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                }`}
              >
                Tabel Datar
              </button>
            </div>
            {(dateFrom || dateTo || search) && (
              <button
                onClick={clearFilters}
                className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-slate-500 text-sm hover:bg-slate-50 transition"
              >
                <X className="w-4 h-4" />
                Reset
              </button>
            )}
          </div>

          {showFilters && (
            <div className="mt-4 pt-4 border-t border-slate-100 grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Dari Tanggal Pesanan</label>
                <input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Sampai Tanggal Pesanan</label>
                <input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                />
              </div>
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-xs text-slate-500 font-medium mb-1">Jumlah BPU</p>
            <p className="text-2xl font-bold text-slate-800">{filtered.length}</p>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-xs text-slate-500 font-medium mb-1">Total Item</p>
            <p className="text-2xl font-bold text-slate-800">{flatRows.length}</p>
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 p-5 col-span-2 lg:col-span-1">
            <p className="text-xs text-slate-500 font-medium mb-1">Grand Total</p>
            <p className="text-2xl font-bold text-amber-600">{formatRupiah(grandTotal)}</p>
          </div>
        </div>

        {/* Table */}
        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl border border-dashed border-slate-300 py-16 text-center">
            <ClipboardList className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500 font-medium">Belum ada data BPU</p>
            <p className="text-slate-400 text-sm mt-1">Data BPU yang diinput akan muncul di laporan ini</p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                    <th className="px-3 py-3 text-left font-semibold w-10">No.</th>
                    <th className="px-3 py-3 text-left font-semibold">No. BPU</th>
                    <th className="px-3 py-3 text-left font-semibold hidden lg:table-cell">Kode Kegiatan</th>
                    <th className="px-3 py-3 text-left font-semibold hidden xl:table-cell">Kode Rekening</th>
                    <th className="px-3 py-3 text-center font-semibold w-12">No. Item</th>
                    <th className="px-3 py-3 text-left font-semibold">Nama Barang / Belanja</th>
                    <th className="px-3 py-3 text-center font-semibold w-16">Jumlah</th>
                    <th className="px-3 py-3 text-left font-semibold hidden md:table-cell">Satuan</th>
                    <th className="px-3 py-3 text-right font-semibold hidden md:table-cell">Harga Satuan</th>
                    <th className="px-3 py-3 text-right font-semibold">Jumlah Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {grouped ? (
                    filtered.map((b) => {
                      const isExpanded = expandedGroups.has(b.no_bpu);
                      return (
                        <Fragment key={b.no_bpu}>
                          <tr
                            className="bg-amber-50/40 cursor-pointer hover:bg-amber-50 transition"
                            onClick={() => toggleGroup(b.no_bpu)}
                          >
                            <td className="px-3 py-3 text-slate-400 font-medium">
                              {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                            </td>
                            <td className="px-3 py-3 font-bold text-slate-800" colSpan={2}>
                              {b.no_bpu}
                            </td>
                            <td className="px-3 py-3 text-slate-500 hidden xl:table-cell">{b.kode_kegiatan || '-'}</td>
                            <td className="px-3 py-3 text-slate-500 hidden xl:table-cell">{b.kode_rekening || '-'}</td>
                            <td className="px-3 py-3 text-center text-slate-500" colSpan={4}>
                              {b.items.length} item — Vendor: {b.vendor?.nama_toko || '-'}
                            </td>
                            <td className="px-3 py-3 text-right font-bold text-amber-600">
                              {formatRupiah(b.total)}
                            </td>
                          </tr>
                          {isExpanded && b.items.map((item, idx) => {
                            const globalNo = flatRows.findIndex(
                              (r) => r.noBpu === b.no_bpu && r.noItem === idx + 1
                            ) + 1;
                            return (
                              <tr key={`${b.no_bpu}-${idx}`} className="hover:bg-slate-50/50 transition">
                                <td className="px-3 py-2.5 text-slate-500">{globalNo || ''}</td>
                                <td className="px-3 py-2.5 text-slate-600">{b.no_bpu}</td>
                                <td className="px-3 py-2.5 text-slate-600 hidden lg:table-cell">{b.kode_kegiatan || '-'}</td>
                                <td className="px-3 py-2.5 text-slate-600 hidden xl:table-cell">{b.kode_rekening || '-'}</td>
                                <td className="px-3 py-2.5 text-center text-slate-500">{idx + 1}</td>
                                <td className="px-3 py-2.5 text-slate-700">{item.nama_barang}</td>
                                <td className="px-3 py-2.5 text-center text-slate-600">{item.banyak_nya}</td>
                                <td className="px-3 py-2.5 text-slate-600 hidden md:table-cell">{item.satuan}</td>
                                <td className="px-3 py-2.5 text-right text-slate-600 hidden md:table-cell">{formatRupiah(Number(item.harga_satuan))}</td>
                                <td className="px-3 py-2.5 text-right font-semibold text-slate-700">{formatRupiah(Number(item.pengeluaran))}</td>
                              </tr>
                            );
                          })}
                          {isExpanded && (
                            <tr className="bg-slate-50/70">
                              <td colSpan={9} className="px-3 py-2 text-right font-semibold text-slate-600 text-sm">
                                Subtotal {b.no_bpu}:
                              </td>
                              <td className="px-3 py-2 text-right font-bold text-slate-800">
                                {formatRupiah(b.total)}
                              </td>
                            </tr>
                          )}
                        </Fragment>
                      );
                    })
                  ) : (
                    flatRows.map((r) => (
                      <tr key={r.no} className="hover:bg-slate-50/50 transition">
                        <td className="px-3 py-2.5 text-slate-500">{r.no}</td>
                        <td className="px-3 py-2.5 text-slate-600">{r.noBpu}</td>
                        <td className="px-3 py-2.5 text-slate-600 hidden lg:table-cell">{r.kodeKegiatan || '-'}</td>
                        <td className="px-3 py-2.5 text-slate-600 hidden xl:table-cell">{r.kodeRekening || '-'}</td>
                        <td className="px-3 py-2.5 text-center text-slate-500">{r.noItem}</td>
                        <td className="px-3 py-2.5 text-slate-700">{r.namaBarang}</td>
                        <td className="px-3 py-2.5 text-center text-slate-600">{r.qty}</td>
                        <td className="px-3 py-2.5 text-slate-600 hidden md:table-cell">{r.satuan}</td>
                        <td className="px-3 py-2.5 text-right text-slate-600 hidden md:table-cell">{formatRupiah(r.hargaSatuan)}</td>
                        <td className="px-3 py-2.5 text-right font-semibold text-slate-700">{formatRupiah(r.jumlahTotal)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-800 text-white">
                    <td colSpan={9} className="px-3 py-3.5 text-right font-bold text-sm">
                      GRAND TOTAL
                    </td>
                    <td className="px-3 py-3.5 text-right font-bold text-base text-amber-400">
                      {formatRupiah(grandTotal)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function LaporanRekapPage() {
  return (
    <LaporanErrorBoundary>
      <LaporanRekapContent />
    </LaporanErrorBoundary>
  );
}

function PrintLaporan({
  bpus,
  grandTotal,
  periode,
  kepalaSekolah,
  bendahara,
  schoolName,
  schoolKota,
}: {
  bpus: BpuFull[];
  grandTotal: number;
  periode: string;
  kepalaSekolah?: Pejabat;
  bendahara?: Pejabat;
  schoolName: string;
  schoolKota: string;
}) {
  const today = new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
  const safeName = schoolName || getSchoolIdentityFromStorage().namaSekolah || '';
  const safeKota = schoolKota || getSchoolIdentityFromStorage().kota || '';
  let runningNo = 0;

  return (
    <div className="p-8 text-black" style={{ fontSize: '11px', fontFamily: 'Arial, sans-serif' }}>
      {/* Kop Laporan */}
      <div className="text-center mb-6">
        <h1 style={{ fontSize: '16px', fontWeight: 'bold' }}>{safeName}</h1>
        <h2 style={{ fontSize: '14px', fontWeight: 'bold', marginTop: '4px' }}>{REPORT_TITLE}</h2>
        <p style={{ fontSize: '11px', marginTop: '2px' }}>Tahun Anggaran: {periode}</p>
        <p style={{ fontSize: '10px', marginTop: '2px', color: '#64748b' }}>Dicetak: {today}</p>
      </div>

      {/* Table */}
      <table className="w-full border-collapse" style={{ fontSize: '9px' }}>
        <thead>
          <tr style={{ background: '#f1f5f9' }}>
            <th style={printCellStyle}>No.</th>
            <th style={printCellStyle}>No. BPU</th>
            <th style={printCellStyle}>Kode Kegiatan</th>
            <th style={printCellStyle}>Kode Rekening</th>
            <th style={printCellStyle}>No. Item</th>
            <th style={printCellStyle}>Nama Barang / Belanja</th>
            <th style={printCellStyle}>Jumlah</th>
            <th style={printCellStyle}>Satuan</th>
            <th style={{ ...printCellStyle, textAlign: 'right' }}>Harga Satuan (Rp)</th>
            <th style={{ ...printCellStyle, textAlign: 'right' }}>Jumlah Total (Rp)</th>
          </tr>
        </thead>
        <tbody>
          {bpus.map((b) =>
            b.items.map((item, idx) => {
              runningNo++;
              return (
                <tr key={`${b.no_bpu}-${idx}`}>
                  <td style={printCellStyle}>{runningNo}</td>
                  <td style={printCellStyle}>{b.no_bpu}</td>
                  <td style={printCellStyle}>{b.kode_kegiatan || '-'}</td>
                  <td style={printCellStyle}>{b.kode_rekening || '-'}</td>
                  <td style={{ ...printCellStyle, textAlign: 'center' }}>{idx + 1}</td>
                  <td style={printCellStyle}>{item.nama_barang}</td>
                  <td style={{ ...printCellStyle, textAlign: 'center' }}>{item.banyak_nya}</td>
                  <td style={printCellStyle}>{item.satuan}</td>
                  <td style={{ ...printCellStyle, textAlign: 'right' }}>{formatRupiah(Number(item.harga_satuan))}</td>
                  <td style={{ ...printCellStyle, textAlign: 'right' }}>{formatRupiah(Number(item.pengeluaran))}</td>
                </tr>
              );
            })
          )}
        </tbody>
        <tfoot>
          <tr style={{ background: '#1e293b', color: '#fff' }}>
            <td colSpan={9} style={{ ...printCellStyle, textAlign: 'right', fontWeight: 'bold', color: '#fff' }}>
              GRAND TOTAL
            </td>
            <td style={{ ...printCellStyle, textAlign: 'right', fontWeight: 'bold', color: '#fbbf24' }}>
              {formatRupiah(grandTotal)}
            </td>
          </tr>
        </tfoot>
      </table>

      {/* Tanda Tangan */}
      <div style={{ marginTop: '48px', display: 'flex', justifyContent: 'space-between', fontSize: '11px' }}>
        <div style={{ textAlign: 'center', width: '45%' }}>
          <p style={{ fontWeight: 'bold' }}>Mengetahui,</p>
          <p style={{ fontWeight: 'bold' }}>Kepala Sekolah</p>
          <div style={{ height: '70px' }} />
          <p style={{ fontWeight: 'bold', textDecoration: 'underline' }}>{kepalaSekolah?.nama || '(...........................)'}</p>
          <p>NIP. {kepalaSekolah?.nip || '...........................'}</p>
        </div>
        <div style={{ textAlign: 'center', width: '45%' }}>
          <p style={{ fontWeight: 'bold' }}>{safeKota}, {today}</p>
          <p style={{ fontWeight: 'bold' }}>Bendahara BOS</p>
          <div style={{ height: '60px' }} />
          <p style={{ fontWeight: 'bold', textDecoration: 'underline' }}>{bendahara?.nama || '(...........................)'}</p>
          <p>NIP. {bendahara?.nip || '...........................'}</p>
        </div>
      </div>
    </div>
  );
}

const printCellStyle: React.CSSProperties = {
  border: '1px solid #cbd5e1',
  padding: '3px 6px',
  textAlign: 'left',
};
