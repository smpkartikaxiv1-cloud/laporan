import { useState, useEffect, FormEvent } from 'react';
import { supabase } from '@/lib/supabase';
import { useLogo, setLogoInStorage, removeLogoFromStorage, LOGO_KOP_KEY } from '@/context/LogoContext';
import { useSchoolIdentity, SchoolIdentity } from '@/context/SchoolContext';
import { Pejabat } from '@/lib/types';
import { Save, UserCog, AlertCircle, CheckCircle, Loader2, Upload, ImageIcon, X, School } from 'lucide-react';

export default function SettingsPage() {
  const { logoKop, refresh: refreshLogo } = useLogo();
  const { identity: school, setIdentity: setSchoolIdentity } = useSchoolIdentity();
  const [schoolForm, setSchoolForm] = useState<SchoolIdentity>(school);
  const [schoolSaved, setSchoolSaved] = useState(false);
  const [pejabat, setPejabat] = useState<Pejabat[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [logoError, setLogoError] = useState('');

  useEffect(() => {
    fetchPejabat();
  }, []);

  async function fetchPejabat() {
    setLoading(true);
    setError('');
    const { data, error } = await supabase
      .from('master_pejabat')
      .select('*')
      .order('peran');
    if (error) {
      setError('Gagal memuat data pejabat: ' + error.message);
    } else {
      setPejabat(data || []);
    }
    setLoading(false);
  }

  function handleChange(id: string, field: 'nama' | 'nip', value: string) {
    setPejabat((prev) =>
      prev.map((p) => (p.id === id ? { ...p, [field]: value } : p))
    );
  }

  function handleLogoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setLogoError('');
    const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setLogoError('Format logo harus PNG, JPG, SVG, atau WebP.');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setLogoError('Ukuran logo maksimal 2MB.');
      return;
    }

    setUploading(true);
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      try {
        setLogoInStorage(LOGO_KOP_KEY, base64);
        refreshLogo();
      } catch {
        setLogoError('Gagal menyimpan logo. Penyimpanan penuh.');
      }
      setUploading(false);
    };
    reader.onerror = () => {
      setLogoError('Gagal membaca file logo.');
      setUploading(false);
    };
    reader.readAsDataURL(file);
  }

  function handleRemoveLogo() {
    setLogoError('');
    removeLogoFromStorage(LOGO_KOP_KEY);
    refreshLogo();
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError('');
    setSuccess(false);
    let allOk = true;
    for (const p of pejabat) {
      const { error } = await supabase
        .from('master_pejabat')
        .update({ nama: p.nama, nip: p.nip, updated_at: new Date().toISOString() })
        .eq('id', p.id);
      if (error) {
        allOk = false;
        setError('Gagal menyimpan data ' + p.peran + ': ' + error.message);
        break;
      }
    }
    if (allOk) setSuccess(true);
    setSaving(false);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center">
            <UserCog className="w-6 h-6 text-amber-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">Pengaturan Pejabat</h1>
            <p className="text-slate-500 text-sm">Kelola nama, NIP pejabat, dan logo untuk dokumen SPJ</p>
          </div>
        </div>
      </div>

      {/* Alerts */}
      {error && (
        <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}
      {success && (
        <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-700">
          <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <span>Data pejabat berhasil disimpan. Perubahan akan tampil pada dokumen SPJ.</span>
        </div>
      )}

      {/* School Identity Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-6">
        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-2">
            <School className="w-4 h-4 text-amber-600" />
            <h2 className="text-sm font-semibold text-slate-700">Identitas Sekolah</h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">Nama sekolah, kota, dan detail kop surat akan otomatis muncul di seluruh dokumen cetak dan tampilan aplikasi.</p>
        </div>
        <div className="px-6 py-5 space-y-4">
          {schoolSaved && (
            <div className="flex items-start gap-2.5 rounded-xl bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-700">
              <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>Identitas sekolah berhasil disimpan. Perubahan langsung berlaku di seluruh dokumen.</span>
            </div>
          )}
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Nama Sekolah <span className="text-red-500">*</span></label>
              <input
                type="text"
                value={schoolForm.namaSekolah}
                onChange={(e) => setSchoolForm({ ...schoolForm, namaSekolah: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                placeholder="SMP Kartika XIV-1 / SD Negeri 28 Banda Aceh"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Kota / Kabupaten <span className="text-red-500">*</span></label>
              <input
                type="text"
                value={schoolForm.kota}
                onChange={(e) => setSchoolForm({ ...schoolForm, kota: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                placeholder="Banda Aceh"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Yayasan / Pemerintah (baris pertama kop)</label>
            <input
              type="text"
              value={schoolForm.yayasan}
              onChange={(e) => setSchoolForm({ ...schoolForm, yayasan: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
              placeholder="Yayasan Kartika Jaya Cabang XIV Iskandar Muda"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1.5">Alamat Sekolah</label>
            <input
              type="text"
              value={schoolForm.alamat}
              onChange={(e) => setSchoolForm({ ...schoolForm, alamat: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
              placeholder="Jl. Nyak Adam Kamil II Peuniti Kecamatan Baiturrahman"
            />
          </div>
          <div className="grid sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">E-mail</label>
              <input
                type="text"
                value={schoolForm.email}
                onChange={(e) => setSchoolForm({ ...schoolForm, email: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                placeholder="email@sekolah.sch.id"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Website</label>
              <input
                type="text"
                value={schoolForm.website}
                onChange={(e) => setSchoolForm({ ...schoolForm, website: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                placeholder="https://sekolah.sch.id"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Kode Pos</label>
              <input
                type="text"
                value={schoolForm.kodePos}
                onChange={(e) => setSchoolForm({ ...schoolForm, kodePos: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                placeholder="23241"
              />
            </div>
          </div>
          <div className="flex justify-end pt-1">
            <button
              type="button"
              onClick={() => {
                setSchoolIdentity(schoolForm);
                setSchoolSaved(true);
                setTimeout(() => setSchoolSaved(false), 4000);
              }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500/40 transition"
            >
              <Save className="w-4 h-4" />
              Simpan Identitas Sekolah
            </button>
          </div>
        </div>
      </div>

      {/* Logo Upload Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-6">
        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <h2 className="text-sm font-semibold text-slate-700">Logo Kop Surat</h2>
          <p className="text-xs text-slate-500 mt-0.5">Unggah logo untuk kop surat dokumen cetak. Format PNG, JPG, SVG, atau WebP, maksimal 2MB.</p>
        </div>
        <div className="px-6 py-5">
          {logoError && (
            <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>{logoError}</span>
            </div>
          )}
          <div className="flex items-center gap-5">
            <div className="w-20 h-20 rounded-xl border-2 border-dashed border-slate-300 flex items-center justify-center overflow-hidden bg-slate-50 flex-shrink-0">
              {logoKop ? (
                <img src={logoKop} alt="Logo Kop Surat" className="w-full h-full object-contain" />
              ) : (
                <div className="flex flex-col items-center gap-1 text-slate-400">
                  <ImageIcon className="w-7 h-7" />
                  <span className="text-[10px] text-center px-1">Belum ada logo</span>
                </div>
              )}
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-slate-700">Logo Kop Surat</p>
              <p className="text-xs text-slate-400 mb-2">Tampil di sebelah kiri kop surat. Lebar maksimal 78px saat dicetak.</p>
              <div className="flex items-center gap-2 flex-wrap">
                <label className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 transition cursor-pointer">
                  {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  {uploading ? 'Mengunggah...' : 'Upload Logo Kop Surat'}
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/jpg,image/svg+xml,image/webp"
                    className="hidden"
                    onChange={handleLogoUpload}
                    disabled={uploading}
                  />
                </label>
                {logoKop && (
                  <button
                    onClick={handleRemoveLogo}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-red-50 text-red-600 font-medium text-sm hover:bg-red-100 transition"
                  >
                    <X className="w-4 h-4" />
                    Hapus
                  </button>
                )}
              </div>
              {!logoKop && (
                <p className="text-xs text-amber-600 mt-2 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5" />
                  Logo belum diunggah. Kop surat akan menggunakan logo bawaan (SVG Yayasan Kartika Jaya).
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <h2 className="text-sm font-semibold text-slate-700">Daftar Pejabat</h2>
          <p className="text-xs text-slate-500 mt-0.5">Nama dan NIP akan otomatis muncul di seluruh dokumen cetak</p>
        </div>

        <div className="divide-y divide-slate-100">
          {pejabat.map((p) => (
            <div key={p.id} className="px-6 py-5">
              <div className="flex items-center gap-2 mb-3">
                <span className="inline-flex items-center px-2.5 py-1 rounded-full bg-amber-100 text-amber-700 text-xs font-semibold">
                  {p.peran}
                </span>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5">Nama Lengkap</label>
                  <input
                    type="text"
                    value={p.nama}
                    onChange={(e) => handleChange(p.id, 'nama', e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                    placeholder="Nama pejabat"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5">NIP</label>
                  <input
                    type="text"
                    value={p.nip}
                    onChange={(e) => handleChange(p.id, 'nip', e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                    placeholder="Nomor NIP"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500/40 transition disabled:opacity-60"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saving ? 'Menyimpan...' : 'Simpan Perubahan'}
          </button>
        </div>
      </form>
    </div>
  );
}
