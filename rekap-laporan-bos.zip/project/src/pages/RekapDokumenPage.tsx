import { useState, useEffect, useMemo, useRef, Component, ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { printBatchTandaTerima } from '@/lib/printUtils';
import { downloadWordDoc, downloadWordBatchTandaTerima } from '@/lib/wordExport';
import { BpuFull, Pejabat, Vendor, BPU, DetailBarang, BpuDocument } from '@/lib/types';
import { formatRupiah } from '@/lib/terbilang';
import { useSchoolIdentity, getSchoolIdentityFromStorage } from '@/context/SchoolContext';
import {
  FolderArchive, Loader2, AlertCircle, Search, Calendar, FileCheck2,
  Image as ImageIcon, Download, Printer, FileText, ChevronDown, ChevronUp,
  Eye, Filter, X, FileStack, Receipt, Upload, FileSpreadsheet, FilePlus, AlertTriangle,
} from 'lucide-react';
import { exportPenerimaExcel, importPenerimaExcel, type ImportResult } from '@/lib/penerimaExcel';

type DocStatus = 'all' | 'lengkap' | 'tanpa_foto' | 'tanpa_kwitansi' | 'kosong';

interface RekapBpu extends BpuFull {
  documents: BpuDocument[];
  kwitansiCount: number;
  fotoCount: number;
  docStatus: 'lengkap' | 'tanpa_foto' | 'tanpa_kwitansi' | 'kosong';
}

class RekapErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean; error: string } > {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: '' };
  }
  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error: error.message || 'Terjadi kesalahan tidak diketahui' };
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="max-w-2xl mx-auto py-20 text-center">
          <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
          <h2 className="text-lg font-semibold text-slate-800 mb-2">Halaman Rekap Dokumen tidak dapat dimuat</h2>
          <p className="text-sm text-slate-500 mb-1">Terjadi kesalahan saat menampilkan data.</p>
          <p className="text-xs text-slate-400 mb-4">{this.state.error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-5 py-2.5 rounded-xl bg-amber-500 text-white font-semibold text-sm hover:bg-amber-600 transition"
          >
            Muat Ulang
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

function RekapDokumenContent() {
  const { identity: school } = useSchoolIdentity();
  const [bpus, setBpus] = useState<RekapBpu[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [statusFilter, setStatusFilter] = useState<DocStatus>('all');
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [showFilters, setShowFilters] = useState(false);
  const [printWithImages, setPrintWithImages] = useState(true);
  const [printing, setPrinting] = useState(false);
  const [pejabatMap, setPejabatMap] = useState<Record<string, Pejabat>>({});
  const [selectedBpus, setSelectedBpus] = useState<Set<string>>(new Set());
  const [batchLoading, setBatchLoading] = useState(false);
  const [wordLoading, setWordLoading] = useState<string | null>(null);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [importLoading, setImportLoading] = useState(false);

  function showToast(type: 'success' | 'error', msg: string) {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 4000);
  }
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchAll();
  }, []);

  async function fetchAll() {
    setLoading(true);
    setError('');
    try {
      const [bpuRes, vendorRes, detailRes, docRes, pejabatRes] = await Promise.all([
        supabase.from('transaksi_bpu').select('*').order('no_bpu'),
        supabase.from('master_vendor').select('*'),
        supabase.from('detail_barang_bpu').select('*').order('created_at'),
        supabase.from('bpu_documents').select('*').order('created_at', { ascending: false }),
        supabase.from('master_pejabat').select('*'),
      ]);

      if (bpuRes.error) throw new Error(bpuRes.error.message);
      if (vendorRes.error) throw new Error(vendorRes.error.message);
      if (detailRes.error) throw new Error(detailRes.error.message);
      if (docRes.error) throw new Error(docRes.error.message);
      if (pejabatRes.error) throw new Error(pejabatRes.error.message);

      const vendorMap: Record<string, Vendor> = {};
      (vendorRes.data || []).forEach((v: Vendor) => { vendorMap[v.id] = v; });

      const itemsByBpu: Record<string, DetailBarang[]> = {};
      (detailRes.data || []).forEach((d: DetailBarang) => {
        if (!itemsByBpu[d.bpu_id]) itemsByBpu[d.bpu_id] = [];
        itemsByBpu[d.bpu_id].push(d);
      });

      const docsByBpu: Record<string, BpuDocument[]> = {};
      (docRes.data || []).forEach((d: BpuDocument) => {
        if (!docsByBpu[d.bpu_number]) docsByBpu[d.bpu_number] = [];
        docsByBpu[d.bpu_number].push(d);
      });

      const pMap: Record<string, Pejabat> = {};
      (pejabatRes.data || []).forEach((p: Pejabat) => { pMap[p.peran] = p; });
      setPejabatMap(pMap);

      const rekap: RekapBpu[] = (bpuRes.data || []).map((b: BPU) => {
        const items = (itemsByBpu[b.no_bpu] || []).filter((i) => {
          const val = Number(i.pengeluaran);
          return !isNaN(val) && val >= 0;
        });
        const total = items.reduce((sum, i) => sum + Number(i.pengeluaran), 0);
        const docs = docsByBpu[b.no_bpu] || [];
        const kwitansiCount = docs.filter((d) => d.doc_type === 'kwitansi').length;
        const fotoCount = docs.filter((d) => d.doc_type === 'foto_barang').length;
        let docStatus: RekapBpu['docStatus'] = 'kosong';
        if (kwitansiCount > 0 && fotoCount > 0) docStatus = 'lengkap';
        else if (kwitansiCount > 0 && fotoCount === 0) docStatus = 'tanpa_foto';
        else if (kwitansiCount === 0 && fotoCount > 0) docStatus = 'tanpa_kwitansi';
        return {
          ...b,
          vendor: vendorMap[b.vendor_id] || null,
          items,
          total,
          documents: docs,
          kwitansiCount,
          fotoCount,
          docStatus,
        };
      });

      setBpus(rekap);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal memuat data');
    }
    setLoading(false);
  }

  const filtered = useMemo(() => {
    return bpus.filter((b) => {
      if (search) {
        const q = search.toLowerCase();
        if (!b.no_bpu.toLowerCase().includes(q) && !(b.vendor?.nama_toko || '').toLowerCase().includes(q)) {
          return false;
        }
      }
      if (dateFrom) {
        if (b.tanggal_pesanan < dateFrom) return false;
      }
      if (dateTo) {
        if (b.tanggal_pesanan > dateTo) return false;
      }
      if (statusFilter !== 'all' && b.docStatus !== statusFilter) return false;
      return true;
    });
  }, [bpus, search, dateFrom, dateTo, statusFilter]);

  function toggleRow(noBpu: string) {
    setExpandedRows((prev) => {
      const next = new Set(prev);
      if (next.has(noBpu)) next.delete(noBpu);
      else next.add(noBpu);
      return next;
    });
  }

  function clearFilters() {
    setSearch('');
    setDateFrom('');
    setDateTo('');
    setStatusFilter('all');
  }

  function getDocUrl(filePath: string): string {
    return `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/bpu-documents/${filePath}`;
  }

  function statusBadge(status: RekapBpu['docStatus']) {
    const config = {
      lengkap: { label: 'Lengkap', color: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
      tanpa_foto: { label: 'Tanpa Foto', color: 'bg-amber-100 text-amber-700 border-amber-200' },
      tanpa_kwitansi: { label: 'Tanpa Kwitansi', color: 'bg-orange-100 text-orange-700 border-orange-200' },
      kosong: { label: 'Belum Ada Dokumen', color: 'bg-red-100 text-red-700 border-red-200' },
    };
    const c = config[status];
    return (
      <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border ${c.color}`}>
        {c.label}
      </span>
    );
  }

  function toggleSelectBpu(noBpu: string) {
    setSelectedBpus((prev) => {
      const next = new Set(prev);
      if (next.has(noBpu)) next.delete(noBpu);
      else next.add(noBpu);
      return next;
    });
  }

  function toggleSelectAll() {
    setSelectedBpus((prev) => {
      if (prev.size === filtered.length) return new Set();
      return new Set(filtered.map((b) => b.no_bpu));
    });
  }

  function handleBatchPrint() {
    const selected = filtered.filter((b) => selectedBpus.has(b.no_bpu));
    if (selected.length === 0) return;
    setBatchLoading(true);
    setTimeout(() => {
      printBatchTandaTerima(selected, pejabatMap);
      setBatchLoading(false);
    }, 100);
  }

  function handlePrintAllTandaTerima() {
    if (filtered.length === 0) return;
    setBatchLoading(true);
    setTimeout(() => {
      printBatchTandaTerima(filtered, pejabatMap);
      setBatchLoading(false);
    }, 100);
  }

  async function handleWordDownload(bpu: RekapBpu) {
    setWordLoading(bpu.no_bpu);
    try {
      await downloadWordDoc(bpu, pejabatMap, 'tanda-terima');
      showToast('success', `Tanda Penerimaan ${bpu.no_bpu} berhasil diunduh.`);
    } catch (err) {
      showToast('error', 'Gagal mengunduh Word: ' + (err instanceof Error ? err.message : 'kesalahan tidak diketahui'));
    } finally {
      setWordLoading(null);
    }
  }

  async function handleWordBatch(bpus: RekapBpu[], key: string) {
    if (bpus.length === 0) return;
    setWordLoading(key);
    try {
      await downloadWordBatchTandaTerima(bpus, pejabatMap);
      showToast('success', `${bpus.length} Tanda Penerimaan berhasil diunduh sebagai Word.`);
    } catch (err) {
      showToast('error', 'Gagal mengunduh Word: ' + (err instanceof Error ? err.message : 'kesalahan tidak diketahui'));
    } finally {
      setWordLoading(null);
    }
  }

  function handlePrint() {
    setPrinting(true);
    setTimeout(() => {
      window.print();
      setPrinting(false);
    }, 300);
  }

  function handleExportPenerima() {
    exportPenerimaExcel(filtered);
  }

  async function handleImportPenerima(file: File) {
    setImportLoading(true);
    setImportResult(null);
    try {
      const result = await importPenerimaExcel(file);
      setImportResult(result);
      if (result.updated > 0) {
        await fetchAll();
      }
    } catch (err) {
      setImportResult({
        updated: 0,
        skipped: 0,
        errors: [err instanceof Error ? err.message : 'Gagal memproses file Excel'],
      });
    }
    setImportLoading(false);
  }

  const stats = useMemo(() => {
    const total = filtered.length;
    const lengkap = filtered.filter((b) => b.docStatus === 'lengkap').length;
    const tanpaFoto = filtered.filter((b) => b.docStatus === 'tanpa_foto').length;
    const tanpaKwitansi = filtered.filter((b) => b.docStatus === 'tanpa_kwitansi').length;
    const kosong = filtered.filter((b) => b.docStatus === 'kosong').length;
    return { total, lengkap, tanpaFoto, tanpaKwitansi, kosong };
  }, [filtered]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Print-only section */}
      <div className="hidden print:block">
        <PrintRekap bpus={filtered} withImages={printWithImages} getDocUrl={getDocUrl} schoolName={school.namaSekolah} />
      </div>

      {/* Screen UI - hidden during print */}
      <div className="print:hidden">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-700 flex items-center justify-center">
              <FolderArchive className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-800">Rekap Dokumen BPU</h1>
              <p className="text-slate-500 text-sm">Daftar BPU beserta lampiran dokumen pendukung</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleExportPenerima}
              disabled={filtered.length === 0}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 text-white font-semibold text-sm shadow-sm hover:bg-emerald-700 transition disabled:opacity-40"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Download Excel Data Penerima
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={importLoading}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-sm shadow-sm hover:bg-blue-700 transition disabled:opacity-40"
            >
              {importLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              Upload Excel Data Penerima
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleImportPenerima(e.target.files[0]);
                  e.target.value = '';
                }
              }}
            />
            <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={printWithImages}
                onChange={(e) => setPrintWithImages(e.target.checked)}
                className="w-4 h-4 rounded border-slate-300 text-amber-500 focus:ring-amber-500/30"
              />
              Cetak dengan gambar
            </label>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 transition"
            >
              <Printer className="w-4 h-4" />
              Cetak / Export PDF
            </button>
          </div>
        </div>

        {error && (
          <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {importResult && (
          <div className={`mb-4 flex items-start gap-2.5 rounded-xl border px-4 py-3 text-sm ${
            importResult.updated > 0 && importResult.errors.length === 0
              ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
              : 'bg-amber-50 border-amber-200 text-amber-700'
          }`}>
            <FileSpreadsheet className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p><strong>{importResult.updated}</strong> data berhasil diperbarui, <strong>{importResult.skipped}</strong> dilewati.</p>
              {importResult.errors.length > 0 && (
                <ul className="list-disc list-inside text-xs space-y-0.5">
                  {importResult.errors.slice(0, 5).map((err, idx) => (
                    <li key={idx}>{err}</li>
                  ))}
                  {importResult.errors.length > 5 && (
                    <li>...dan {importResult.errors.length - 5} error lainnya</li>
                  )}
                </ul>
              )}
            </div>
            <button
              onClick={() => setImportResult(null)}
              className="ml-auto p-1 rounded text-current opacity-60 hover:opacity-100"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-6">
          <StatCard label="Total BPU" value={stats.total} color="slate" />
          <StatCard label="Lengkap" value={stats.lengkap} color="emerald" />
          <StatCard label="Tanpa Foto" value={stats.tanpaFoto} color="amber" />
          <StatCard label="Tanpa Kwitansi" value={stats.tanpaKwitansi} color="orange" />
          <StatCard label="Belum Ada Dokumen" value={stats.kosong} color="red" />
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 mb-6">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Cari No. BPU atau Vendor..."
                className="w-full pl-10 pr-3 py-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-200 text-slate-600 font-medium text-sm hover:bg-slate-50 transition"
            >
              <Filter className="w-4 h-4" />
              Filter
              {(dateFrom || dateTo || statusFilter !== 'all') && (
                <span className="w-2 h-2 rounded-full bg-amber-500" />
              )}
            </button>
            {(dateFrom || dateTo || statusFilter !== 'all' || search) && (
              <button
                onClick={clearFilters}
                className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-slate-500 text-sm hover:bg-slate-50 transition"
              >
                <X className="w-4 h-4" />
                Reset
              </button>
            )}
          </div>

          {showFilters && (
            <div className="mt-4 pt-4 border-t border-slate-100 grid sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Dari Tanggal Pesanan</label>
                <input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Sampai Tanggal Pesanan</label>
                <input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Status Dokumen</label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as DocStatus)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                >
                  <option value="all">Semua Status</option>
                  <option value="lengkap">Lengkap</option>
                  <option value="tanpa_foto">Tanpa Foto</option>
                  <option value="tanpa_kwitansi">Tanpa Kwitansi</option>
                  <option value="kosong">Belum Ada Dokumen</option>
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Batch Print Toolbar */}
        {filtered.length > 0 && (
          <div className="mb-4 flex flex-wrap items-center gap-3 bg-white rounded-2xl border border-slate-200 px-4 py-3">
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Receipt className="w-4 h-4 text-cyan-600" />
              <span className="font-medium">Cetak Tanda Penerimaan:</span>
              {selectedBpus.size > 0 && (
                <span className="text-xs text-cyan-600 font-semibold bg-cyan-50 px-2 py-0.5 rounded-full">
                  {selectedBpus.size} dipilih
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 ml-auto">
              <button
                onClick={handleBatchPrint}
                disabled={selectedBpus.size === 0 || batchLoading}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 text-white font-semibold text-sm shadow-sm hover:bg-cyan-700 transition disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {batchLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />}
                Cetak Terpilih{selectedBpus.size > 0 ? ` (${selectedBpus.size})` : ''}
              </button>
              <button
                onClick={handlePrintAllTandaTerima}
                disabled={batchLoading}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-700 text-white font-semibold text-sm shadow-sm hover:bg-slate-800 transition disabled:opacity-40"
              >
                {batchLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileStack className="w-4 h-4" />}
                Cetak Semua ({filtered.length})
              </button>
              <button
                onClick={() => handleWordBatch(filtered.filter((b) => selectedBpus.has(b.no_bpu)), 'selected')}
                disabled={wordLoading !== null || selectedBpus.size === 0}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 text-white font-semibold text-sm shadow-sm hover:bg-blue-700 transition disabled:opacity-40"
              >
                {wordLoading === 'selected' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
                Word Terpilih{selectedBpus.size > 0 ? ` (${selectedBpus.size})` : ''}
              </button>
              <button
                onClick={() => handleWordBatch(filtered, 'all')}
                disabled={wordLoading !== null}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-800 text-white font-semibold text-sm shadow-sm hover:bg-blue-900 transition disabled:opacity-40"
              >
                {wordLoading === 'all' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
                Word Semua ({filtered.length})
              </button>
            </div>
          </div>
        )}

        {/* Table */}
        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl border border-dashed border-slate-300 py-16 text-center">
            <FolderArchive className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            {bpus.length === 0 ? (
              <>
                <p className="text-slate-500 font-medium">Belum ada data BPU/Dokumen</p>
                <p className="text-slate-400 text-sm mt-1">Silakan unggah atau input data terlebih dahulu</p>
                <button
                  onClick={() => {
                    const event = new CustomEvent('navigate', { detail: 'create' });
                    window.dispatchEvent(event);
                  }}
                  className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 transition"
                >
                  <FilePlus className="w-4 h-4" />
                  Input BPU Baru
                </button>
              </>
            ) : (
              <>
                <p className="text-slate-500 font-medium">Tidak ada data BPU yang cocok</p>
                <p className="text-slate-400 text-sm mt-1">Ubah filter atau kata kunci pencarian</p>
              </>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                    <th className="px-4 py-3 text-center font-semibold w-10">
                      <input
                        type="checkbox"
                        checked={selectedBpus.size === filtered.length && filtered.length > 0}
                        onChange={toggleSelectAll}
                        className="w-4 h-4 rounded border-slate-300 text-cyan-500 focus:ring-cyan-500/30 cursor-pointer"
                      />
                    </th>
                    <th className="px-4 py-3 text-left font-semibold w-8"></th>
                    <th className="px-4 py-3 text-left font-semibold">No. BPU</th>
                    <th className="px-4 py-3 text-left font-semibold hidden sm:table-cell">Tanggal Pesanan</th>
                    <th className="px-4 py-3 text-left font-semibold hidden lg:table-cell">Vendor</th>
                    <th className="px-4 py-3 text-right font-semibold hidden md:table-cell">Nominal</th>
                    <th className="px-4 py-3 text-center font-semibold">Kwitansi</th>
                    <th className="px-4 py-3 text-center font-semibold">Foto</th>
                    <th className="px-4 py-3 text-center font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.map((b) => {
                    const isExpanded = expandedRows.has(b.no_bpu);
                    const kwitansiDocs = b.documents.filter((d) => d.doc_type === 'kwitansi');
                    const fotoDocs = b.documents.filter((d) => d.doc_type === 'foto_barang');
                    return (
                      <>
                        <tr
                          key={b.no_bpu}
                          className={`transition ${selectedBpus.has(b.no_bpu) ? 'bg-cyan-50/50' : 'hover:bg-slate-50/50'} cursor-pointer`}
                        >
                          <td className="px-4 py-3.5 text-center" onClick={(e) => e.stopPropagation()}>
                            <input
                              type="checkbox"
                              checked={selectedBpus.has(b.no_bpu)}
                              onChange={() => toggleSelectBpu(b.no_bpu)}
                              className="w-4 h-4 rounded border-slate-300 text-cyan-500 focus:ring-cyan-500/30 cursor-pointer"
                            />
                          </td>
                          <td className="px-4 py-3.5 text-center text-slate-400">
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </td>
                          <td className="px-4 py-3.5">
                            <span className="font-semibold text-slate-800">{b.no_bpu}</span>
                          </td>
                          <td className="px-4 py-3.5 text-slate-600 hidden sm:table-cell">
                            <span className="inline-flex items-center gap-1.5 text-xs">
                              <Calendar className="w-3.5 h-3.5 text-slate-400" />
                              {new Date(b.tanggal_pesanan).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-slate-600 hidden lg:table-cell">
                            {b.vendor?.nama_toko || '-'}
                          </td>
                          <td className="px-4 py-3.5 text-right font-semibold text-slate-700 hidden md:table-cell">
                            {b.total > 0 ? formatRupiah(b.total) : '-'}
                          </td>
                          <td className="px-4 py-3.5 text-center">
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                              b.kwitansiCount > 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-400'
                            }`}>
                              <FileCheck2 className="w-3 h-3" />
                              {b.kwitansiCount}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-center">
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                              b.fotoCount > 0 ? 'bg-blue-50 text-blue-700' : 'bg-slate-100 text-slate-400'
                            }`}>
                              <ImageIcon className="w-3 h-3" />
                              {b.fotoCount}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-center">
                            {statusBadge(b.docStatus)}
                          </td>
                        </tr>
                        {isExpanded && (
                          <tr key={`${b.no_bpu}-detail`} className="bg-slate-50/30">
                            <td colSpan={9} className="px-4 py-4">
                              <ExpandedDetail
                                bpu={b}
                                kwitansiDocs={kwitansiDocs}
                                fotoDocs={fotoDocs}
                                getDocUrl={getDocUrl}
                                onDownloadWord={() => handleWordDownload(b)}
                                wordLoading={wordLoading === b.no_bpu}
                              />
                            </td>
                          </tr>
                        )}
                      </>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 flex items-center gap-2.5 rounded-xl px-4 py-3 text-sm font-medium shadow-lg ${toast.type === 'success' ? 'bg-green-50 border border-green-200 text-green-700' : 'bg-red-50 border border-red-200 text-red-700'}`}>
          {toast.type === 'success' ? <FileText className="w-5 h-5 flex-shrink-0" /> : <AlertCircle className="w-5 h-5 flex-shrink-0" />}
          <span>{toast.msg}</span>
        </div>
      )}
    </div>
  );
}

export default function RekapDokumenPage() {
  return (
    <RekapErrorBoundary>
      <RekapDokumenContent />
    </RekapErrorBoundary>
  );
}

function StatCard({ label, value, color }: { label: string; value: number; color: string }) {
  const colorMap: Record<string, string> = {
    slate: 'text-slate-800',
    emerald: 'text-emerald-600',
    amber: 'text-amber-600',
    orange: 'text-orange-600',
    red: 'text-red-600',
  };
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4">
      <p className="text-xs text-slate-500 font-medium mb-1">{label}</p>
      <p className={`text-2xl font-bold ${colorMap[color]}`}>{value}</p>
    </div>
  );
}

function ExpandedDetail({
  bpu,
  kwitansiDocs,
  fotoDocs,
  getDocUrl,
  onDownloadWord,
  wordLoading,
}: {
  bpu: RekapBpu;
  kwitansiDocs: BpuDocument[];
  fotoDocs: BpuDocument[];
  getDocUrl: (path: string) => string;
  onDownloadWord: () => void;
  wordLoading: boolean;
}) {
  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button
          onClick={onDownloadWord}
          disabled={wordLoading}
          className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-50 text-blue-700 font-semibold text-xs hover:bg-blue-100 transition disabled:opacity-50"
        >
          {wordLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
          Download Word (.docx) Tanda Penerimaan
        </button>
      </div>
      {/* Items summary */}
      <div>
        <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2 flex items-center gap-1.5">
          <FileText className="w-3.5 h-3.5" />
          Detail Barang ({bpu.items.length} item)
        </h4>
        <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
          <table className="w-full text-xs">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="px-3 py-2 text-left font-semibold">Nama Barang</th>
                <th className="px-3 py-2 text-center font-semibold">Jumlah</th>
                <th className="px-3 py-2 text-left font-semibold">Satuan</th>
                <th className="px-3 py-2 text-right font-semibold">Harga Satuan</th>
                <th className="px-3 py-2 text-right font-semibold">Subtotal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {bpu.items.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50">
                  <td className="px-3 py-2 text-slate-700">{item.nama_barang}</td>
                  <td className="px-3 py-2 text-center text-slate-600">{item.banyak_nya}</td>
                  <td className="px-3 py-2 text-slate-600">{item.satuan}</td>
                  <td className="px-3 py-2 text-right text-slate-600">{formatRupiah(item.harga_satuan)}</td>
                  <td className="px-3 py-2 text-right font-semibold text-slate-700">{formatRupiah(item.pengeluaran)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Kwitansi docs */}
      <div>
        <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2 flex items-center gap-1.5">
          <FileCheck2 className="w-3.5 h-3.5 text-emerald-500" />
          Bukti Kwitansi / Faktur ({kwitansiDocs.length})
        </h4>
        {kwitansiDocs.length === 0 ? (
          <p className="text-sm text-slate-400 italic">Belum ada file kwitansi/faktur</p>
        ) : (
          <div className="space-y-2">
            {kwitansiDocs.map((doc) => (
              <div key={doc.id} className="flex items-center gap-3 px-3 py-2 rounded-lg bg-white border border-slate-200">
                <FileCheck2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                <span className="text-sm text-slate-700 flex-1 truncate">{doc.file_name}</span>
                <span className="text-xs text-slate-400">{(doc.file_size / 1024).toFixed(0)} KB</span>
                <a
                  href={getDocUrl(doc.file_path)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-lg text-slate-400 hover:text-blue-500 hover:bg-blue-50 transition"
                  title="Pratinjau"
                >
                  <Eye className="w-4 h-4" />
                </a>
                <a
                  href={getDocUrl(doc.file_path)}
                  download={doc.file_name}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-blue-500 hover:bg-blue-50 transition"
                  title="Unduh"
                >
                  <Download className="w-4 h-4" />
                </a>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Foto docs */}
      <div>
        <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2 flex items-center gap-1.5">
          <ImageIcon className="w-3.5 h-3.5 text-blue-500" />
          Gambar / Foto Barang ({fotoDocs.length})
        </h4>
        {fotoDocs.length === 0 ? (
          <p className="text-sm text-slate-400 italic">Belum ada foto barang</p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {fotoDocs.map((doc) => (
              <div key={doc.id} className="relative group rounded-lg border border-slate-200 overflow-hidden bg-white">
                <div className="aspect-square flex items-center justify-center overflow-hidden">
                  <img
                    src={getDocUrl(doc.file_path)}
                    alt={doc.file_name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="px-2 py-1.5">
                  <p className="text-xs text-slate-600 truncate">{doc.file_name}</p>
                </div>
                <div className="absolute top-1.5 right-1.5 flex gap-1">
                  <a
                    href={getDocUrl(doc.file_path)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 rounded-lg bg-white/90 text-slate-500 hover:text-blue-500 shadow-sm transition"
                    title="Pratinjau"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </a>
                  <a
                    href={getDocUrl(doc.file_path)}
                    download={doc.file_name}
                    className="p-1.5 rounded-lg bg-white/90 text-slate-500 hover:text-blue-500 shadow-sm transition"
                    title="Unduh"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function PrintRekap({
  bpus,
  withImages,
  getDocUrl,
  schoolName,
}: {
  bpus: RekapBpu[];
  withImages: boolean;
  getDocUrl: (path: string) => string;
  schoolName: string;
}) {
  const today = new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
  const safeName = schoolName || getSchoolIdentityFromStorage().namaSekolah;
  return (
    <div className="p-8 text-black" style={{ fontSize: '11px', fontFamily: 'Arial, sans-serif' }}>
      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-lg font-bold">REKAP DOKUMEN PENDUKUNG BPU</h1>
        <p className="text-sm">SPJ BOS - {safeName}</p>
        <p className="text-xs mt-1">Dicetak: {today}</p>
      </div>

      {/* Summary table */}
      <table className="w-full border-collapse mb-6" style={{ fontSize: '10px' }}>
        <thead>
          <tr style={{ background: '#f1f5f9' }}>
            <th style={printCellStyle}>No. BPU</th>
            <th style={printCellStyle}>Tgl Pesanan</th>
            <th style={printCellStyle}>Vendor</th>
            <th style={printCellStyle}>Nominal</th>
            <th style={printCellStyle}>Kwitansi</th>
            <th style={printCellStyle}>Foto</th>
            <th style={printCellStyle}>Status</th>
          </tr>
        </thead>
        <tbody>
          {bpus.map((b) => (
            <tr key={b.no_bpu}>
              <td style={printCellStyle}>{b.no_bpu}</td>
              <td style={printCellStyle}>{new Date(b.tanggal_pesanan).toLocaleDateString('id-ID')}</td>
              <td style={printCellStyle}>{b.vendor?.nama_toko || '-'}</td>
              <td style={{ ...printCellStyle, textAlign: 'right' }}>{formatRupiah(b.total)}</td>
              <td style={{ ...printCellStyle, textAlign: 'center' }}>{b.kwitansiCount}</td>
              <td style={{ ...printCellStyle, textAlign: 'center' }}>{b.fotoCount}</td>
              <td style={printCellStyle}>
                {b.docStatus === 'lengkap' ? 'Lengkap' :
                 b.docStatus === 'tanpa_foto' ? 'Tanpa Foto' :
                 b.docStatus === 'tanpa_kwitansi' ? 'Tanpa Kwitansi' : 'Belum Ada Dokumen'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Detail with items per BPU */}
      <h2 className="text-sm font-bold mb-3">Rincian per BPU</h2>
      {bpus.map((b, idx) => (
        <div
          key={b.no_bpu}
          className="mb-5 print-page"
          style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}
        >
          <div style={{ background: '#f8fafc', padding: '6px 8px', border: '1px solid #e2e8f0', borderTop: '2px solid #475569' }}>
            <p style={{ fontWeight: 'bold', fontSize: '11px' }}>
              {idx + 1}. {b.no_bpu} — {b.vendor?.nama_toko || '-'}
              <span style={{ float: 'right', fontWeight: 'normal' }}>
                {formatRupiah(b.total)}
              </span>
            </p>
          </div>
          <table className="w-full border-collapse" style={{ fontSize: '9px' }}>
            <thead>
              <tr style={{ background: '#f8fafc' }}>
                <th style={printCellStyle}>No</th>
                <th style={printCellStyle}>Nama Barang</th>
                <th style={printCellStyle}>Jml</th>
                <th style={printCellStyle}>Satuan</th>
                <th style={printCellStyle}>Harga</th>
                <th style={printCellStyle}>Subtotal</th>
              </tr>
            </thead>
            <tbody>
              {b.items.map((item, i) => (
                <tr key={i}>
                  <td style={printCellStyle}>{i + 1}</td>
                  <td style={printCellStyle}>{item.nama_barang}</td>
                  <td style={{ ...printCellStyle, textAlign: 'center' }}>{item.banyak_nya}</td>
                  <td style={printCellStyle}>{item.satuan}</td>
                  <td style={{ ...printCellStyle, textAlign: 'right' }}>{formatRupiah(item.harga_satuan)}</td>
                  <td style={{ ...printCellStyle, textAlign: 'right' }}>{formatRupiah(item.pengeluaran)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Document list */}
          <div style={{ padding: '4px 8px', fontSize: '9px' }}>
            <p style={{ fontWeight: 'bold', marginTop: '4px' }}>
              Dokumen: Kwitansi/Faktur ({b.kwitansiCount}), Foto ({b.fotoCount})
            </p>
            {b.documents.map((doc) => (
              <p key={doc.id} style={{ marginLeft: '12px' }}>
                - [{doc.doc_type === 'kwitansi' ? 'Kwitansi' : 'Foto'}] {doc.file_name}
              </p>
            ))}
            {b.documents.length === 0 && (
              <p style={{ marginLeft: '12px', fontStyle: 'italic', color: '#94a3b8' }}>
                - Belum ada dokumen
              </p>
            )}
          </div>

          {/* Image grid preview */}
          {withImages && b.documents.filter((d) => d.doc_type === 'foto_barang').length > 0 && (
            <div style={{ padding: '8px', pageBreakInside: 'avoid' }}>
              <p style={{ fontSize: '9px', fontWeight: 'bold', marginBottom: '4px' }}>Lampiran Foto Barang:</p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {b.documents.filter((d) => d.doc_type === 'foto_barang').map((doc) => (
                  <div key={doc.id} style={{ width: '120px', border: '1px solid #e2e8f0', padding: '4px' }}>
                    <img
                      src={getDocUrl(doc.file_path)}
                      alt={doc.file_name}
                      style={{ width: '100%', height: '100px', objectFit: 'cover', display: 'block' }}
                    />
                    <p style={{ fontSize: '8px', marginTop: '2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {doc.file_name}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}

      {/* Footer */}
      <div style={{ marginTop: '20px', textAlign: 'center', fontSize: '9px', color: '#64748b' }}>
        <p>Dokumen ini dicetak secara otomatis dari Sistem SPJ BOS Manager</p>
      </div>
    </div>
  );
}

const printCellStyle: React.CSSProperties = {
  border: '1px solid #cbd5e1',
  padding: '3px 6px',
  textAlign: 'left',
};
