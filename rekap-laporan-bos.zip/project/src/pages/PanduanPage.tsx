import { useState, Component, ReactNode } from 'react';
import {
  BookOpen, Printer, Settings, FilePlus, Store,
  FolderArchive, ClipboardList, FileText,
  ChevronDown, ChevronUp, CheckCircle2,
  Info, AlertTriangle, LayoutDashboard,
} from 'lucide-react';

type TabKey = 'awal' | 'bpu' | 'penerima' | 'cetak';

const TABS: { key: TabKey; label: string; icon: typeof Settings; step: string }[] = [
  { key: 'awal', label: 'Pengaturan Awal', icon: Settings, step: 'Langkah 1' },
  { key: 'bpu', label: 'Input Data BPU', icon: FilePlus, step: 'Langkah 2' },
  { key: 'penerima', label: 'Data Penerima', icon: Store, step: 'Langkah 3' },
  { key: 'cetak', label: 'Cetak & Download', icon: Printer, step: 'Langkah 4' },
];

interface AccordionItem {
  title: string;
  content: ReactNode;
}

function Accordion({ items }: { items: AccordionItem[] }) {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="space-y-3">
      {items.map((item, idx) => (
        <div key={idx} className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <button
            onClick={() => setOpen(open === idx ? null : idx)}
            className="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-slate-50 transition"
          >
            <span className="text-sm font-semibold text-slate-800">{item.title}</span>
            {open === idx ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
          </button>
          {open === idx && (
            <div className="px-5 pb-5 text-sm text-slate-600 leading-relaxed">{item.content}</div>
          )}
        </div>
      ))}
    </div>
  );
}

function Step({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-start gap-2.5 mb-2">
      <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
      <span>{children}</span>
    </div>
  );
}

function Note({ children, type = 'info' }: { children: ReactNode; type?: 'info' | 'warn' }) {
  const Icon = type === 'warn' ? AlertTriangle : Info;
  const cls = type === 'warn'
    ? 'bg-amber-50 border-amber-200 text-amber-700'
    : 'bg-blue-50 border-blue-200 text-blue-700';
  return (
    <div className={`flex items-start gap-2.5 rounded-lg border px-4 py-3 text-sm mb-4 ${cls}`}>
      <Icon className="w-4 h-4 flex-shrink-0 mt-0.5" />
      <span>{children}</span>
    </div>
  );
}

function MenuRef({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-xs font-medium border border-slate-200">
      {children}
    </span>
  );
}

class PanduanErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="max-w-2xl mx-auto py-20 text-center">
          <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
          <h2 className="text-lg font-semibold text-slate-800 mb-2">Halaman panduan tidak dapat dimuat</h2>
          <p className="text-sm text-slate-500">Silakan muat ulang halaman atau hubungi administrator jika masalah berlanjut.</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 px-5 py-2.5 rounded-xl bg-blue-500 text-white font-semibold text-sm hover:bg-blue-600 transition"
          >
            Muat Ulang
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

function PanduanContent() {
  const [activeTab, setActiveTab] = useState<TabKey>('awal');

  const tabContent: Record<TabKey, AccordionItem[]> = {
    awal: [
      {
        title: 'Mengisi Identitas Sekolah',
        content: (
          <div>
            <p className="mb-3">Sebelum mulai mengelola BPU, pastikan identitas sekolah sudah diisi dengan benar. Data ini akan tampil otomatis di seluruh kop surat dan dokumen cetak.</p>
            <Step>Buka menu <MenuRef><Settings className="w-3 h-3" /> Pengaturan Pejabat</MenuRef> di sidebar.</Step>
            <Step>Pada kartu <strong>"Identitas Sekolah"</strong>, isi kolom berikut:
              <ul className="mt-2 ml-6 list-disc space-y-1">
                <li><strong>Nama Sekolah</strong> — contoh: SMP Kartika XIV-1 atau SD Negeri 28 Banda Aceh</li>
                <li><strong>Kota / Kabupaten</strong> — contoh: Banda Aceh</li>
                <li><strong>Yayasan / Pemerintah</strong> — baris pertama kop surat (opsional)</li>
                <li><strong>Alamat, E-mail, Website, Kode Pos</strong> — untuk kop surat dokumen</li>
              </ul>
            </Step>
            <Step>Klik tombol <strong>"Simpan Identitas Sekolah"</strong>. Perubahan langsung berlaku di seluruh dokumen dan tampilan aplikasi.</Step>
            <Note>Data identitas sekolah disimpan di browser (localStorage) dan tetap ada saat halaman di-refresh.</Note>
          </div>
        ),
      },
      {
        title: 'Mengisi Data Pejabat (Kepala Sekolah, Bendahara, Pengurus Barang)',
        content: (
          <div>
            <p className="mb-3">Nama dan NIP pejabat akan otomatis muncul di kolom tanda tangan seluruh dokumen cetak (Tanda Penerimaan, Berita Acara, Lampiran, dll).</p>
            <Step>Buka menu <MenuRef><Settings className="w-3 h-3" /> Pengaturan Pejabat</MenuRef>.</Step>
            <Step>Pada bagian <strong>"Daftar Pejabat"</strong>, isi <strong>Nama Lengkap</strong> dan <strong>NIP</strong> untuk setiap peran:
              <ul className="mt-2 ml-6 list-disc space-y-1">
                <li><strong>Kepala Sekolah</strong> — tanda tangan di Surat Pesanan, Berita Acara, dan Tanda Penerimaan</li>
                <li><strong>Bendahara BOSP</strong> — tanda tangan "Lunas dibayar" di Tanda Penerimaan</li>
                <li><strong>Pengurus Barang</strong> — tanda tangan "Pengurus barang2/pekerjaan" di Tanda Penerimaan</li>
              </ul>
            </Step>
            <Step>Klik tombol <strong>"Simpan Perubahan"</strong> di bagian bawah.</Step>
            <Note type="warn">Jika nama pejabat kosong, kolom tanda tangan akan menampilkan garis kosong. Pastikan semua pejabat terisi untuk dokumen yang lengkap.</Note>
          </div>
        ),
      },
      {
        title: 'Mengunggah Logo Kop Surat',
        content: (
          <div>
            <p className="mb-3">Logo akan tampil di sebelah kiri kop surat pada dokumen cetak (Surat Pesanan, Berita Acara, Lampiran).</p>
            <Step>Buka menu <MenuRef><Settings className="w-3 h-3" /> Pengaturan Pejabat</MenuRef>, lalu cari kartu <strong>"Logo Kop Surat"</strong>.</Step>
            <Step>Klik tombol <strong>"Upload Logo Kop Surat"</strong> dan pilih file gambar.</Step>
            <Step>Format yang didukung: PNG, JPG, SVG, atau WebP. Ukuran maksimal 2MB.</Step>
            <Step>Logo akan langsung tampil di pratinjau dan pada dokumen cetak berikutnya.</Step>
            <Step>Untuk menghapus logo, klik tombol <strong>"Hapus"</strong> di sebelah tombol upload.</Step>
            <Note>Jika logo belum diunggah, kop surat akan menggunakan logo bawaan (SVG Yayasan Kartika Jaya).</Note>
          </div>
        ),
      },
    ],
    bpu: [
      {
        title: 'Mengunduh Template Excel',
        content: (
          <div>
            <p className="mb-3">Jika Anda ingin menginput data BPU dari awal menggunakan Excel, gunakan template bawaan untuk memastikan format sesuai.</p>
            <Step>Buka menu <MenuRef><FilePlus className="w-3 h-3" /> Input BPU Baru</MenuRef>.</Step>
            <Step>Cari bagian <strong>"Upload Database Excel"</strong> di halaman tersebut.</Step>
            <Step>Klik tombol <strong>"Download Template Excel"</strong> untuk mengunduh format template.</Step>
            <Step>Buka file template di Excel, lalu isi data sesuai kolom yang tersedia (No. BPU, tanggal, vendor, item barang, harga, dll).</Step>
            <Step>Simpan file Excel, lalu unggah kembali menggunakan tombol <strong>"Upload Database Excel"</strong>.</Step>
          </div>
        ),
      },
      {
        title: 'Mengunggah File Excel Data Transaksi',
        content: (
          <div>
            <p className="mb-3">Fitur Upload Database Excel memungkinkan Anda mengimpor banyak data BPU sekaligus dari satu file Excel.</p>
            <Step>Buka menu <MenuRef><FilePlus className="w-3 h-3" /> Input BPU Baru</MenuRef>.</Step>
            <Step>Cari kartu <strong>"Upload Database Excel"</strong>.</Step>
            <Step>Klik area upload atau seret file Excel (.xlsx) ke dalam area tersebut.</Step>
            <Step>Sistem akan membaca file dan menambahkan data BPU ke database secara otomatis.</Step>
            <Step>Setelah upload selesai, data akan muncul di <MenuRef><LayoutDashboard className="w-3 h-3" /> Dashboard BPU</MenuRef>.</Step>
            <Note type="warn">Pastikan format kolom Excel sesuai dengan template. Kolom yang wajib: No. BPU, Tanggal Pesanan, Vendor, Kode Kegiatan, Kode Rekening, Nama Barang, Banyaknya, Satuan, dan Harga Satuan.</Note>
          </div>
        ),
      },
      {
        title: 'Input BPU Satu per Satu',
        content: (
          <div>
            <p className="mb-3">Jika hanya ingin menambahkan satu BPU, gunakan form input manual.</p>
            <Step>Buka menu <MenuRef><FilePlus className="w-3 h-3" /> Input BPU Baru</MenuRef>.</Step>
            <Step>Isi form BPU:
              <ul className="mt-2 ml-6 list-disc space-y-1">
                <li><strong>No. BPU</strong> — nomor unik untuk transaksi ini</li>
                <li><strong>Tanggal Pesanan</strong> — tanggal pembuatan BPU</li>
                <li><strong>Vendor</strong> — pilih dari daftar vendor yang sudah ada</li>
                <li><strong>Kode Kegiatan & Kode Rekening</strong> — sesuai standar akuntansi BOS</li>
                <li><strong>Item Barang</strong> — tambahkan nama barang, jumlah, satuan, dan harga satuan</li>
              </ul>
            </Step>
            <Step>Klik tombol <strong>"Simpan BPU"</strong> untuk menyimpan.</Step>
            <Step>Data BPU akan muncul di Dashboard dan dapat dicetak kapan saja.</Step>
          </div>
        ),
      },
    ],
    penerima: [
      {
        title: 'Mengisi Nama Penerima dan Pekerjaan/Toko',
        content: (
          <div>
            <p className="mb-3">Data penerima digunakan pada dokumen Tanda Penerimaan di bagian "Yang menerima". Data ini bisa diisi manual atau dipilih dari daftar vendor.</p>
            <Step>Buka menu <MenuRef><FolderArchive className="w-3 h-3" /> Rekap Dokumen</MenuRef>.</Step>
            <Step>Cari BPU yang ingin diisi data penerimanya, lalu klik untuk membuka detail.</Step>
            <Step>Pada bagian <strong>"Data Penerima"</strong>, isi:
              <ul className="mt-2 ml-6 list-disc space-y-1">
                <li><strong>Nama Penerima</strong> — nama lengkap orang yang menerima pembayaran</li>
                <li><strong>Pekerjaan/Toko</strong> — jenis pekerjaan atau nama toko (contoh: "Teknisi AC" atau nama vendor)</li>
                <li><strong>Alamat</strong> — alamat penerima</li>
              </ul>
            </Step>
            <Step>Jika penerima adalah vendor yang sudah terdaftar, data akan otomatis terisi dari data vendor.</Step>
            <Step>Untuk pekerja panggilan atau teknisi yang bukan vendor, isi secara manual.</Step>
            <Step>Klik <strong>"Simpan"</strong> untuk menyimpan data penerima.</Step>
          </div>
        ),
      },
      {
        title: 'Download & Upload Data Uraian (YAITU) via Excel',
        content: (
          <div>
            <p className="mb-3">Fitur YAITU memungkinkan Anda mengedit data uraian pembayaran (YAITU) secara kolektif menggunakan Excel, tanpa harus membuka setiap BPU satu per satu.</p>
            <Step>Buka menu <MenuRef><FolderArchive className="w-3 h-3" /> Rekap Dokumen</MenuRef>.</Step>
            <Step>Cari tombol <strong>"Download Data Uraian (YAITU)"</strong> dan klik untuk mengunduh file Excel berisi seluruh data YAITU.</Step>
            <Step>Buka file Excel, lalu edit kolom uraian sesuai kebutuhan. Setiap baris mewakili satu BPU.</Step>
            <Step>Simpan file Excel setelah selesai editing.</Step>
            <Step>Kembali ke aplikasi, klik tombol <strong>"Upload Data Uraian (YAITU)"</strong> dan pilih file yang sudah diedit.</Step>
            <Step>Sistem akan memperbarui data YAITU untuk semua BPU dalam file tersebut.</Step>
            <Note type="warn">Jangan mengubah kolom "No. BPU" pada file Excel — kolom ini digunakan untuk mencocokkan data. Jika berubah, upload akan gagal.</Note>
          </div>
        ),
      },
      {
        title: 'Mengelola Data Vendor',
        content: (
          <div>
            <p className="mb-3">Vendor adalah toko atau penyedia barang yang terdaftar di sistem. Data vendor digunakan saat input BPU dan otomatis mengisi data penerima.</p>
            <Step>Buka menu <MenuRef><Store className="w-3 h-3" /> Data Vendor</MenuRef>.</Step>
            <Step>Untuk menambah vendor baru, klik tombol <strong>"Tambah Vendor"</strong> dan isi nama toko, alamat, dan telepon.</Step>
            <Step>Untuk mengedit, klik ikon pensil pada baris vendor yang ingin diubah.</Step>
            <Step>Vendor yang sudah terdaftar akan muncul di pilihan saat input BPU baru.</Step>
          </div>
        ),
      },
    ],
    cetak: [
      {
        title: 'Mencetak Dokumen per BPU (Tanda Penerimaan, Kwitansi, Order, Faktur, Berita Acara)',
        content: (
          <div>
            <p className="mb-3">Setiap BPU dapat dicetak dalam berbagai format dokumen secara individual.</p>
            <Step>Buka menu <MenuRef><FolderArchive className="w-3 h-3" /> Rekap Dokumen</MenuRef> atau <MenuRef><LayoutDashboard className="w-3 h-3" /> Dashboard BPU</MenuRef>.</Step>
            <Step>Cari BPU yang ingin dicetak, lalu buka detail atau cari tombol cetak.</Step>
            <Step>Pilih jenis dokumen yang ingin dicetak:
              <ul className="mt-2 ml-6 list-disc space-y-1">
                <li><strong>Tanda Penerimaan</strong> — bukti penerimaan uang dari Bendahara</li>
                <li><strong>Surat Pesanan (Order)</strong> — surat pemesanan barang ke vendor</li>
                <li><strong>Faktur Pembelian</strong> — faktur dari vendor</li>
                <li><strong>Berita Acara Pembayaran</strong> — berita acara pembayaran pengadaan</li>
                <li><strong>Lampiran Berita Acara</strong> — lampiran pemeriksaan barang</li>
              </ul>
            </Step>
            <Step>Klik tombol cetak/icon printer untuk dokumen yang dipilih. Dokumen akan terbuka di jendela print browser.</Step>
            <Step>Pilih printer atau "Save as PDF" pada dialog print browser.</Step>
          </div>
        ),
      },
      {
        title: 'Cetak Semua / Cetak Terpilih (Batch Print)',
        content: (
          <div>
            <p className="mb-3">Anda dapat mencetak dokumen untuk beberapa BPU sekaligus menggunakan fitur batch print.</p>
            <Step>Buka menu <MenuRef><FolderArchive className="w-3 h-3" /> Rekap Dokumen</MenuRef>.</Step>
            <Step><strong>Cetak Terpilih:</strong> Centang kotak di sebelah kiri setiap BPU yang ingin dicetak, lalu klik tombol <strong>"Cetak Terpilih"</strong>.</Step>
            <Step><strong>Cetak Semua:</strong> Klik tombol <strong>"Cetak Semua Tanda Penerimaan"</strong> untuk mencetak seluruh BPU yang terfilter.</Step>
            <Step>Semua dokumen akan dihasilkan dalam satu sesi cetak, terurut berdasarkan No. BPU.</Step>
            <Note type="warn">Untuk hasil cetak yang rapi, pastikan ukuran kertas dan margin sudah diatur dengan benar (lihat panduan pengaturan kertas di bawah).</Note>
          </div>
        ),
      },
      {
        title: 'Pengaturan Ukuran Kertas (A4 dan F4/Folio) saat Print',
        content: (
          <div>
            <p className="mb-3">Saat mencetak dokumen, atur ukuran kertas di dialog print browser agar hasil sesuai standar dokumen SPJ.</p>
            <div className="mb-3">
              <strong className="text-slate-700">Untuk Kertas A4:</strong>
              <ul className="mt-1 ml-6 list-disc space-y-1">
                <li>Pada dialog print browser, pilih <strong>Paper Size: A4</strong></li>
                <li>Margin: Default atau Minimal</li>
                <li>Scale: 100% (jangan "Fit to Page")</li>
              </ul>
            </div>
            <div className="mb-3">
              <strong className="text-slate-700">Untuk Kertas F4/Folio:</strong>
              <ul className="mt-1 ml-6 list-disc space-y-1">
                <li>Pada dialog print browser, pilih <strong>Paper Size: Folio / F4</strong> (jika tersedia)</li>
                <li>Jika F4 tidak tersedia di opsi, pilih <strong>Custom Size</strong> dengan dimensi 215mm x 330mm</li>
                <li>Alternatif: pilih A4 lalu set Scale ke 95-100% — dokumen tetap terbaca dengan baik</li>
                <li>Margin: Default atau Minimal</li>
              </ul>
            </div>
            <Note>Dokumen SPJ BOS Manager dirancang untuk ukuran A4. Jika menggunakan F4/Folio, dokumen akan sedikit lebih lebar tetapi tetap rapi.</Note>
          </div>
        ),
      },
      {
        title: 'Mengunduh Dokumen Format Word (.docx)',
        content: (
          <div>
            <p className="mb-3">Selain cetak langsung, Anda dapat mengunduh dokumen dalam format Word (.docx) untuk diedit lebih lanjut atau diarsipkan.</p>
            <Step>Buka menu <MenuRef><FolderArchive className="w-3 h-3" /> Rekap Dokumen</MenuRef>.</Step>
            <Step>Cari BPU yang ingin diunduh, lalu cari ikon <FileText className="w-3.5 h-3.5 inline text-slate-500" /> atau tombol <strong>"Word"</strong>.</Step>
            <Step>Klik untuk mengunduh file .docx — dokumen akan tersimpan ke folder Downloads.</Step>
            <Step>Untuk mengunduh semua dokumen dalam satu BPU (Surat Pesanan, Tanda Penerimaan, Faktur, Berita Acara, Lampiran), gunakan tombol <strong>"Download Paket Word"</strong> — semua dokumen akan tergabung dalam satu file .docx.</Step>
            <Step>Untuk batch download Tanda Penerimaan beberapa BPU, centang BPU yang dipilih lalu klik tombol <strong>"Download Word (Terpilih)"</strong>.</Step>
            <Note type="warn">File Word (.docx) berisi kop surat dengan logo dan identitas sekolah yang sudah diatur di menu Pengaturan. Pastikan identitas sekolah sudah benar sebelum mengunduh.</Note>
          </div>
        ),
      },
      {
        title: 'Mencetak Laporan Rekapitulasi BPU',
        content: (
          <div>
            <p className="mb-3">Laporan Rekapitulasi berisi ringkasan seluruh BPU untuk keperluan audit Dinas Pendidikan.</p>
            <Step>Buka menu <MenuRef><ClipboardList className="w-3 h-3" /> Laporan Rekap BPU</MenuRef>.</Step>
            <Step>Atur <strong>Tahun Anggaran</strong> sesuai periode yang diinginkan.</Step>
            <Step>Gunakan filter pencarian dan filter tanggal untuk mempersempit data jika perlu.</Step>
            <Step>Klik tombol <strong>"Export Excel"</strong> untuk mengunduh laporan dalam format Excel (.xlsx).</Step>
            <Step>Klik tombol <strong>"Cetak / PDF"</strong> untuk mencetak laporan atau menyimpan sebagai PDF.</Step>
            <Step>Laporan akan menampilkan kop surat sekolah, nama pejabat, dan tanda tangan Kepala Sekolah dan Bendahara secara otomatis.</Step>
          </div>
        ),
      },
    ],
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Print-only header */}
      <div className="hidden print:block text-center mb-8">
        <h1 className="text-2xl font-bold">Panduan Penggunaan SPJ BOS Manager</h1>
        <p className="text-sm text-slate-600 mt-2">Buku Petunjuk Admin — Sistem Pengelolaan Bukti Pengeluaran Uang Dana BOS</p>
        <div className="border-t-2 border-b-2 border-slate-800 my-4 py-2">
          <p className="text-xs">Dicetak pada {new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
        </div>
      </div>

      {/* Screen header */}
      <div className="print:hidden mb-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-800">Panduan Penggunaan</h1>
              <p className="text-slate-500 text-sm">Buku petunjuk admin untuk mengoperasikan SPJ BOS Manager</p>
            </div>
          </div>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold text-sm shadow-lg shadow-blue-500/20 hover:from-blue-600 hover:to-blue-700 transition"
          >
            <Printer className="w-4 h-4" />
            Cetak / Download PDF
          </button>
        </div>
      </div>

      {/* Quick overview cards */}
      <div className="print:hidden grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => {
                setActiveTab(tab.key);
                const el = document.getElementById('panduan-tabs');
                if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }}
              className="bg-white rounded-xl border border-slate-200 p-4 text-left hover:border-blue-300 hover:shadow-md transition group"
            >
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center group-hover:bg-blue-100 transition">
                  <Icon className="w-4 h-4 text-blue-600" />
                </div>
                <span className="text-[10px] font-bold text-blue-500 uppercase tracking-wide">{tab.step}</span>
              </div>
              <p className="text-sm font-semibold text-slate-700">{tab.label}</p>
            </button>
          );
        })}
      </div>

      {/* Tabs */}
      <div id="panduan-tabs" className="print:hidden bg-white rounded-2xl border border-slate-200 overflow-hidden mb-6">
        <div className="flex border-b border-slate-200 overflow-x-auto">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center gap-2 px-5 py-4 text-sm font-medium whitespace-nowrap transition border-b-2 ${
                  active
                    ? 'border-blue-500 text-blue-600 bg-blue-50/50'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="hidden sm:inline">{tab.step}:</span>
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab content (screen) */}
      <div className="print:hidden">
        <Accordion items={tabContent[activeTab] || []} />
      </div>

      {/* Print content (all tabs) */}
      <div className="hidden print:block space-y-8">
        {TABS.map((tab) => (
          <div key={tab.key}>
            <h2 className="text-lg font-bold border-b-2 border-slate-300 pb-2 mb-4">
              {tab.step}: {tab.label}
            </h2>
            <div className="space-y-3">
              {(tabContent[tab.key] || []).map((item, idx) => (
                <div key={idx} className="border border-slate-200 rounded-lg p-4">
                  <h3 className="font-semibold text-slate-800 mb-2">{item.title}</h3>
                  <div className="text-sm text-slate-600">{item.content}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="mt-8 pt-6 border-t border-slate-200 text-center">
        <p className="text-xs text-slate-400">
          SPJ BOS Manager — Sistem Pengelolaan Bukti Pengeluaran Uang Dana BOS
        </p>
        <p className="text-xs text-slate-400 mt-1">
          Panduan ini dapat dicetak atau disimpan sebagai PDF menggunakan tombol "Cetak / Download PDF" di atas.
        </p>
      </div>
    </div>
  );
}

export default function PanduanPage() {
  return (
    <PanduanErrorBoundary>
      <PanduanContent />
    </PanduanErrorBoundary>
  );
}
