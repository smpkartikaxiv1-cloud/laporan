import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { BpuFull, PajakFull, PajakBPU, NotaPajakFile, PajakStatus, DetailBarang, BpuDocument } from '@/lib/types';
import { formatRupiah, formatAngka } from '@/lib/terbilang';
import { downloadPajakWord, exportPajakPDF } from '@/lib/pajakExport';
import {
  Receipt, FilePlus, Loader2, AlertCircle, Trash2, Pencil, X,
  Upload, FileText, CheckCircle2, Clock, XCircle, FileDown,
  Send, ChevronDown, Paperclip, FileCheck2,
} from 'lucide-react';

const JENIS_PAJAK_OPTIONS = ['PPN', 'PPh 21', 'PPh 22', 'PPh 23', 'PPh 25', 'PPh Final', 'Lainnya'];

const STATUS_CONFIG: Record<PajakStatus, { color: string; bg: string; icon: typeof Clock; label: string }> = {
  'Draft': { color: 'text-slate-600', bg: 'bg-slate-100', icon: FileText, label: 'Draft' },
  'Menunggu Persetujuan': { color: 'text-amber-700', bg: 'bg-amber-100', icon: Clock, label: 'Menunggu' },
  'Disetujui': { color: 'text-emerald-700', bg: 'bg-emerald-100', icon: CheckCircle2, label: 'Disetujui' },
  'Ditolak': { color: 'text-red-700', bg: 'bg-red-100', icon: XCircle, label: 'Ditolak' },
};

const ALLOWED_TYPES = ['application/pdf', 'image/jpeg', 'image/png'];
const MAX_FILE_SIZE = 5 * 1024 * 1024;

function sanitizeNumber(value: string): number {
  return parseInt(value.replace(/[^0-9]/g, ''), 10) || 0;
}

function formatNumberInput(value: number): string {
  if (!value) return '';
  return new Intl.NumberFormat('id-ID').format(value);
}

export default function PajakPage() {
  const [bpus, setBpus] = useState<BpuFull[]>([]);
  const [pajakList, setPajakList] = useState<PajakFull[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingPajak, setEditingPajak] = useState<PajakFull | null>(null);
  const [expandedRow, setExpandedRow] = useState<string | null>(null);
  const [exportLoading, setExportLoading] = useState<string | null>(null);

  async function fetchAll() {
    setLoading(true);
    setError('');
    try {
      const [bpuRes, pajakRes, filesRes, detailRes, docsRes] = await Promise.all([
        supabase.from('transaksi_bpu').select('*').order('no_bpu'),
        supabase.from('pajak_bpu').select('*').order('created_at', { ascending: false }),
        supabase.from('nota_pajak_files').select('*'),
        supabase.from('detail_barang_bpu').select('*'),
        supabase.from('bpu_documents').select('*'),
      ]);
      if (bpuRes.error) throw new Error(bpuRes.error.message);
      if (pajakRes.error) throw new Error(pajakRes.error.message);
      if (filesRes.error) throw new Error(filesRes.error.message);
      if (detailRes.error) throw new Error(detailRes.error.message);
      if (docsRes.error) throw new Error(docsRes.error.message);

      const bpuRows = (bpuRes.data || []) as any[];
      const detailRows = (detailRes.data || []) as DetailBarang[];
      const docRows = (docsRes.data || []) as BpuDocument[];

      // Group items and photos by BPU number
      const itemsByBpu: Record<string, DetailBarang[]> = {};
      detailRows.forEach((d) => {
        if (!itemsByBpu[d.bpu_id]) itemsByBpu[d.bpu_id] = [];
        itemsByBpu[d.bpu_id].push(d);
      });
      const photosByBpu: Record<string, BpuDocument[]> = {};
      docRows.forEach((d) => {
        if (d.doc_type !== 'foto_barang') return;
        if (!photosByBpu[d.bpu_number]) photosByBpu[d.bpu_number] = [];
        photosByBpu[d.bpu_number].push(d);
      });

      const fullBpus = bpuRows.map((b) => ({
        ...b,
        vendor: null,
        items: (itemsByBpu[b.no_bpu] || []).filter((i) => {
          const val = Number(i.pengeluaran);
          return !isNaN(val) && val >= 0;
        }),
        total: (itemsByBpu[b.no_bpu] || []).reduce((s, i) => s + Number(i.pengeluaran), 0),
      }));
      setBpus(fullBpus);

      // Store photos map on window for export access
      (window as any).__bpuPhotos = photosByBpu;

      const pajakRows = (pajakRes.data || []) as PajakBPU[];
      const fileRows = (filesRes.data || []) as NotaPajakFile[];

      const filesByPajak: Record<string, NotaPajakFile[]> = {};
      fileRows.forEach((f) => {
        if (!filesByPajak[f.pajak_id]) filesByPajak[f.pajak_id] = [];
        filesByPajak[f.pajak_id].push(f);
      });

      const full: PajakFull[] = pajakRows.map((p) => ({
        ...p,
        files: filesByPajak[p.id] || [],
      }));
      setPajakList(full);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal memuat data');
    }
    setLoading(false);
  }

  useEffect(() => {
    fetchAll();
  }, []);

  async function handleDelete(pajak: PajakFull) {
    if (!confirm(`Hapus data pajak ${pajak.tax_number}?`)) return;
    for (const file of pajak.files) {
      await supabase.storage.from('nota-pajak').remove([file.file_path]);
    }
    const { error: delError } = await supabase.from('pajak_bpu').delete().eq('id', pajak.id);
    if (delError) {
      setError('Gagal menghapus: ' + delError.message);
    } else {
      fetchAll();
    }
  }

  async function handleSubmitApproval(pajak: PajakFull) {
    const { error: updError } = await supabase
      .from('pajak_bpu')
      .update({ status: 'Menunggu Persetujuan' as PajakStatus })
      .eq('id', pajak.id);
    if (updError) {
      setError('Gagal mengajukan: ' + updError.message);
    } else {
      fetchAll();
    }
  }

  async function handleApprove(pajak: PajakFull) {
    const { error: updError } = await supabase
      .from('pajak_bpu')
      .update({ status: 'Disetujui' as PajakStatus })
      .eq('id', pajak.id);
    if (updError) {
      setError('Gagal menyetujui: ' + updError.message);
    } else {
      fetchAll();
    }
  }

  async function handleReject(pajak: PajakFull) {
    const { error: updError } = await supabase
      .from('pajak_bpu')
      .update({ status: 'Ditolak' as PajakStatus })
      .eq('id', pajak.id);
    if (updError) {
      setError('Gagal menolak: ' + updError.message);
    } else {
      fetchAll();
    }
  }

  async function handleExport(pajak: PajakFull, format: 'pdf' | 'word') {
    setExportLoading(`${format}-${pajak.id}`);
    try {
      const bpu = bpus.find((b) => b.no_bpu === pajak.bpu_number);
      const items = bpu?.items || [];
      const photosMap = (window as any).__bpuPhotos || {};
      const photos = (photosMap[pajak.bpu_number] || []) as BpuDocument[];
      if (format === 'pdf') {
        exportPajakPDF(pajak, items, photos);
      } else {
        await downloadPajakWord(pajak, items, photos);
      }
    } catch (err) {
      setError('Gagal ekspor: ' + (err instanceof Error ? err.message : 'Unknown error'));
    } finally {
      setExportLoading(null);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-700 flex items-center justify-center">
            <Receipt className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">Form Pajak Mandiri</h1>
            <p className="text-slate-500 text-sm">Manajemen Pajak per BPU</p>
          </div>
        </div>
        <button
          onClick={() => { setEditingPajak(null); setShowForm(true); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500/40 transition"
        >
          <FilePlus className="w-4 h-4" />
          Input Pajak Baru
        </button>
      </div>

      {error && (
        <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <span>{error}</span>
          <button onClick={() => setError('')} className="ml-auto"><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* Stats */}
      {pajakList.length > 0 && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {(['Draft', 'Menunggu Persetujuan', 'Disetujui', 'Ditolak'] as PajakStatus[]).map((status) => {
            const count = pajakList.filter((p) => p.status === status).length;
            const cfg = STATUS_CONFIG[status];
            const Icon = cfg.icon;
            return (
              <div key={status} className="bg-white rounded-2xl border border-slate-200 p-5">
                <div className="flex items-center gap-2 mb-2">
                  <Icon className={`w-4 h-4 ${cfg.color}`} />
                  <p className="text-xs text-slate-500 font-medium">{cfg.label}</p>
                </div>
                <p className="text-2xl font-bold text-slate-800">{count}</p>
              </div>
            );
          })}
        </div>
      )}

      {/* List */}
      {pajakList.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 py-16 text-center">
          <Receipt className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">Belum ada data pajak</p>
          <p className="text-slate-400 text-sm mt-1">Klik "Input Pajak Baru" untuk membuat data pajak pertama</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                  <th className="px-4 py-3 text-left font-semibold">Nomor Pajak</th>
                  <th className="px-4 py-3 text-left font-semibold hidden sm:table-cell">No. BPU</th>
                  <th className="px-4 py-3 text-left font-semibold hidden md:table-cell">Jenis Pajak</th>
                  <th className="px-4 py-3 text-right font-semibold hidden lg:table-cell">DPP</th>
                  <th className="px-4 py-3 text-right font-semibold">Nominal Pajak</th>
                  <th className="px-4 py-3 text-center font-semibold">Status</th>
                  <th className="px-4 py-3 text-center font-semibold">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {pajakList.map((pajak) => {
                  const cfg = STATUS_CONFIG[pajak.status];
                  const StatusIcon = cfg.icon;
                  const isApproved = pajak.status === 'Disetujui';
                  return (
                    <>
                      <tr key={pajak.id} className="hover:bg-slate-50/50 transition">
                        <td className="px-4 py-3.5">
                          <span className="font-semibold text-slate-800">{pajak.tax_number}</span>
                          {pajak.files.length > 0 && (
                            <span className="ml-2 inline-flex items-center gap-1 text-xs text-slate-400">
                              <Paperclip className="w-3 h-3" />
                              {pajak.files.length}
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3.5 text-slate-600 hidden sm:table-cell">{pajak.bpu_number}</td>
                        <td className="px-4 py-3.5 text-slate-600 hidden md:table-cell">{pajak.jenis_pajak}</td>
                        <td className="px-4 py-3.5 text-right text-slate-600 hidden lg:table-cell">{formatRupiah(pajak.dasar_pengenaan_pajak)}</td>
                        <td className="px-4 py-3.5 text-right font-semibold text-slate-700">{formatRupiah(pajak.nominal_pajak)}</td>
                        <td className="px-4 py-3.5 text-center">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${cfg.bg} ${cfg.color}`}>
                            <StatusIcon className="w-3.5 h-3.5" />
                            {cfg.label}
                          </span>
                        </td>
                        <td className="px-4 py-3.5">
                          <div className="flex items-center justify-center gap-1.5">
                            {pajak.status === 'Draft' && (
                              <button
                                onClick={() => handleSubmitApproval(pajak)}
                                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-blue-500 text-white font-medium text-xs hover:bg-blue-600 shadow-sm transition"
                                title="Ajukan Persetujuan"
                              >
                                <Send className="w-3.5 h-3.5" />
                                <span className="hidden xl:inline">Ajukan</span>
                              </button>
                            )}
                            {pajak.status === 'Menunggu Persetujuan' && (
                              <>
                                <button
                                  onClick={() => handleApprove(pajak)}
                                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-500 text-white font-medium text-xs hover:bg-emerald-600 shadow-sm transition"
                                  title="Setujui"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span className="hidden xl:inline">Setujui</span>
                                </button>
                                <button
                                  onClick={() => handleReject(pajak)}
                                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-red-500 text-white font-medium text-xs hover:bg-red-600 shadow-sm transition"
                                  title="Tolak"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                  <span className="hidden xl:inline">Tolak</span>
                                </button>
                              </>
                            )}
                            {isApproved && (
                              <>
                                <button
                                  onClick={() => handleExport(pajak, 'pdf')}
                                  disabled={exportLoading === `pdf-${pajak.id}`}
                                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-amber-500 text-white font-medium text-xs hover:bg-amber-600 shadow-sm transition disabled:opacity-60"
                                  title="Ekspor PDF"
                                >
                                  {exportLoading === `pdf-${pajak.id}` ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileDown className="w-3.5 h-3.5" />}
                                  <span className="hidden xl:inline">PDF</span>
                                </button>
                                <button
                                  onClick={() => handleExport(pajak, 'word')}
                                  disabled={exportLoading === `word-${pajak.id}`}
                                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-blue-500 text-white font-medium text-xs hover:bg-blue-600 shadow-sm transition disabled:opacity-60"
                                  title="Ekspor Word"
                                >
                                  {exportLoading === `word-${pajak.id}` ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileText className="w-3.5 h-3.5" />}
                                  <span className="hidden xl:inline">Word</span>
                                </button>
                              </>
                            )}
                            <button
                              onClick={() => { setEditingPajak(pajak); setShowForm(true); }}
                              disabled={isApproved}
                              className="p-2 rounded-lg text-slate-400 hover:text-amber-500 hover:bg-amber-50 transition disabled:opacity-30 disabled:cursor-not-allowed"
                              title={isApproved ? 'Data disetujui, tidak dapat diedit' : 'Edit'}
                            >
                              <Pencil className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setExpandedRow(expandedRow === pajak.id ? null : pajak.id)}
                              className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
                              title="Lihat Detail"
                            >
                              <ChevronDown className={`w-4 h-4 transition ${expandedRow === pajak.id ? 'rotate-180' : ''}`} />
                            </button>
                            <button
                              onClick={() => handleDelete(pajak)}
                              className="p-2 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                              title="Hapus"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                      {expandedRow === pajak.id && (
                        <tr className="bg-slate-50/70">
                          <td colSpan={7} className="px-4 py-4">
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                              <div><span className="text-slate-400">NTPN:</span> <span className="text-slate-700 font-medium">{pajak.ntpn || '-'}</span></div>
                              <div><span className="text-slate-400">Tanggal Setor:</span> <span className="text-slate-700 font-medium">{new Date(pajak.tanggal_setor).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })}</span></div>
                              <div><span className="text-slate-400">DPP:</span> <span className="text-slate-700 font-medium">{formatRupiah(pajak.dasar_pengenaan_pajak)}</span></div>
                              <div className="sm:col-span-2 lg:col-span-3">
                                <span className="text-slate-400">File Nota:</span>
                                {pajak.files.length === 0 ? (
                                  <span className="text-slate-400 ml-2">Tidak ada file</span>
                                ) : (
                                  <div className="mt-2 flex flex-wrap gap-2">
                                    {pajak.files.map((file) => (
                                      <a
                                        key={file.id}
                                        href={`${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/nota-pajak/${file.file_path}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-white border border-slate-200 text-xs text-slate-600 hover:bg-slate-50 transition"
                                      >
                                        <FileCheck2 className="w-4 h-4 text-emerald-500" />
                                        {file.file_name}
                                      </a>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showForm && (
        <PajakFormModal
          bpus={bpus}
          editingPajak={editingPajak}
          onClose={() => { setShowForm(false); setEditingPajak(null); }}
          onSaved={() => { setShowForm(false); setEditingPajak(null); fetchAll(); }}
        />
      )}
    </div>
  );
}

// ============================================================
// PajakFormModal — Form for creating/editing tax records
// ============================================================
interface PajakFormModalProps {
  bpus: BpuFull[];
  editingPajak: PajakFull | null;
  onClose: () => void;
  onSaved: () => void;
}

function PajakFormModal({ bpus, editingPajak, onClose, onSaved }: PajakFormModalProps) {
  const isEdit = !!editingPajak;
  const [bpuNumber, setBpuNumber] = useState(editingPajak?.bpu_number || '');
  const [taxNumber, setTaxNumber] = useState(editingPajak?.tax_number || '');
  const [jenisPajak, setJenisPajak] = useState(editingPajak?.jenis_pajak || 'PPN');
  const [dpp, setDpp] = useState(editingPajak ? formatNumberInput(editingPajak.dasar_pengenaan_pajak) : '');
  const [nominalPajak, setNominalPajak] = useState(editingPajak ? formatNumberInput(editingPajak.nominal_pajak) : '');
  const [ntpn, setNtpn] = useState(editingPajak?.ntpn || '');
  const [tanggalSetor, setTanggalSetor] = useState(editingPajak?.tanggal_setor || new Date().toISOString().slice(0, 10));
  const [files, setFiles] = useState<NotaPajakFile[]>(editingPajak?.files || []);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-generate tax number when BPU is selected (create mode only)
  useEffect(() => {
    if (!isEdit && bpuNumber) {
      setTaxNumber(`TAX-${bpuNumber}`);
    }
  }, [bpuNumber, isEdit]);

  // Auto-calculate nominal pajak based on jenis_pajak and DPP (only when DPP changes, user can still override)
  useEffect(() => {
    if (!isEdit || nominalPajak === '') {
      const dppNum = sanitizeNumber(dpp);
      if (dppNum > 0) {
        let rate = 0.11;
        if (jenisPajak === 'PPh 21') rate = 0.05;
        else if (jenisPajak === 'PPh 22') rate = 0.015;
        else if (jenisPajak === 'PPh 23') rate = 0.02;
        else if (jenisPajak === 'PPh 25') rate = 0.025;
        else if (jenisPajak === 'PPh Final') rate = 0.04;
        else if (jenisPajak === 'PPN') rate = 0.11;
        else rate = 0;
        if (rate > 0) {
          setNominalPajak(formatNumberInput(Math.round(dppNum * rate)));
        }
      }
    }
  }, [dpp, jenisPajak, isEdit]);

  async function handleFileUpload(file: File) {
    setError('');
    if (!ALLOWED_TYPES.includes(file.type)) {
      setError('Format file tidak didukung. Hanya PDF, JPG, dan PNG.');
      return;
    }
    if (file.size > MAX_FILE_SIZE) {
      setError('Ukuran file melebihi 5MB.');
      return;
    }
    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${fileExt}`;
      const filePath = `${bpuNumber || 'temp'}/${fileName}`;
      const { error: uploadError } = await supabase.storage.from('nota-pajak').upload(filePath, file);
      if (uploadError) throw new Error(uploadError.message);

      const newFile: NotaPajakFile = {
        id: crypto.randomUUID(),
        pajak_id: editingPajak?.id || 'temp',
        file_name: file.name,
        file_path: filePath,
        file_type: file.type,
        file_size: file.size,
      };
      setFiles((prev) => [...prev, newFile]);
    } catch (err) {
      setError('Gagal mengunggah: ' + (err instanceof Error ? err.message : 'Unknown'));
    }
    setUploading(false);
  }

  async function handleRemoveFile(file: NotaPajakFile) {
    if (file.file_path && !file.file_path.startsWith('temp')) {
      await supabase.storage.from('nota-pajak').remove([file.file_path]);
    }
    setFiles((prev) => prev.filter((f) => f.id !== file.id));
  }

  async function handleSave() {
    setError('');
    if (!bpuNumber) { setError('Pilih No. BPU terlebih dahulu.'); return; }
    if (!taxNumber) { setError('Nomor pajak tidak boleh kosong.'); return; }

    setSaving(true);
    const dppNum = sanitizeNumber(dpp);
    const nominalNum = sanitizeNumber(nominalPajak);

    try {
      let pajakId = editingPajak?.id || '';

      if (isEdit) {
        const { error: updError } = await supabase.from('pajak_bpu').update({
          bpu_number: bpuNumber,
          jenis_pajak: jenisPajak,
          dasar_pengenaan_pajak: dppNum,
          nominal_pajak: nominalNum,
          ntpn: ntpn.trim(),
          tanggal_setor: tanggalSetor,
          updated_at: new Date().toISOString(),
        }).eq('id', pajakId);
        if (updError) throw new Error(updError.message);
      } else {
        const { data, error: insError } = await supabase.from('pajak_bpu').insert({
          tax_number: taxNumber,
          bpu_number: bpuNumber,
          jenis_pajak: jenisPajak,
          dasar_pengenaan_pajak: dppNum,
          nominal_pajak: nominalNum,
          ntpn: ntpn.trim(),
          tanggal_setor: tanggalSetor,
          status: 'Draft' as PajakStatus,
        }).select('id').single();
        if (insError) throw new Error(insError.message);
        pajakId = data.id;
      }

      // Save files metadata
      for (const file of files) {
        if (file.pajak_id === 'temp' || !file.pajak_id) {
          const { error: fileInsError } = await supabase.from('nota_pajak_files').insert({
            pajak_id: pajakId,
            file_name: file.file_name,
            file_path: file.file_path,
            file_type: file.file_type,
            file_size: file.file_size,
          });
          if (fileInsError) console.error('File save error:', fileInsError);
        }
      }

      onSaved();
    } catch (err) {
      setError('Gagal menyimpan: ' + (err instanceof Error ? err.message : 'Unknown'));
    }
    setSaving(false);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-100 flex items-center justify-center">
              <Receipt className="w-5 h-5 text-amber-600" />
            </div>
            <h2 className="text-lg font-bold text-slate-800">{isEdit ? 'Edit Data Pajak' : 'Input Pajak Baru'}</h2>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-5 space-y-5">
          {error && (
            <div className="flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* BPU Selection */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">No. BPU (Referensi)</label>
            <select
              value={bpuNumber}
              onChange={(e) => setBpuNumber(e.target.value)}
              disabled={isEdit}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/40 disabled:bg-slate-50 disabled:text-slate-400"
            >
              <option value="">Pilih No. BPU...</option>
              {bpus.map((b) => (
                <option key={b.no_bpu} value={b.no_bpu}>{b.no_bpu}</option>
              ))}
            </select>
          </div>

          {/* Tax Number (auto-generated, read-only) */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Nomor Pajak (Otomatis)</label>
            <input
              type="text"
              value={taxNumber}
              readOnly
              placeholder="Pilih BPU untuk generate nomor..."
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-slate-50 text-slate-600 font-medium"
            />
          </div>

          {/* Jenis Pajak */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Jenis Pajak</label>
            <select
              value={jenisPajak}
              onChange={(e) => setJenisPajak(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/40"
            >
              {JENIS_PAJAK_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>

          {/* DPP & Nominal Pajak */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Dasar Pengenaan Pajak / DPP (Rp)</label>
              <input
                type="text"
                value={dpp}
                onChange={(e) => setDpp(formatNumberInput(sanitizeNumber(e.target.value)))}
                placeholder="0"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/40"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Nominal Pajak (Rp) <span className="text-xs text-slate-400 font-normal">- dapat diedit manual</span>
              </label>
              <input
                type="text"
                value={nominalPajak}
                onChange={(e) => setNominalPajak(formatNumberInput(sanitizeNumber(e.target.value)))}
                placeholder="0"
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/40"
              />
            </div>
          </div>

          {/* NTPN & Tanggal Setor */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">NTPN / Nomor Tanda Penerimaan Negara</label>
              <input
                type="text"
                value={ntpn}
                onChange={(e) => setNtpn(e.target.value)}
                placeholder="Masukkan NTPN..."
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/40"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Tanggal Setor/Bayar</label>
              <input
                type="date"
                value={tanggalSetor}
                onChange={(e) => setTanggalSetor(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/40"
              />
            </div>
          </div>

          {/* File Upload */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Upload Nota / Bukti Bayar Pajak</label>
            <div
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                const droppedFile = e.dataTransfer.files[0];
                if (droppedFile) handleFileUpload(droppedFile);
              }}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl px-4 py-8 text-center cursor-pointer transition ${
                dragOver ? 'border-amber-400 bg-amber-50' : 'border-slate-300 hover:border-slate-400'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                className="hidden"
                onChange={(e) => {
                  const selectedFile = e.target.files?.[0];
                  if (selectedFile) handleFileUpload(selectedFile);
                  e.target.value = '';
                }}
              />
              {uploading ? (
                <div className="flex flex-col items-center gap-2">
                  <Loader2 className="w-6 h-6 text-amber-500 animate-spin" />
                  <p className="text-sm text-slate-500">Mengunggah...</p>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2">
                  <Upload className="w-6 h-6 text-slate-400" />
                  <p className="text-sm text-slate-500">Seret file ke sini atau klik untuk memilih</p>
                  <p className="text-xs text-slate-400">PDF, JPG, PNG - maks 5MB</p>
                </div>
              )}
            </div>

            {/* Uploaded files list */}
            {files.length > 0 && (
              <div className="mt-3 space-y-2">
                {files.map((file) => (
                  <div key={file.id} className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-slate-50 border border-slate-200">
                    <FileCheck2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                    <span className="text-sm text-slate-700 flex-1 truncate">{file.file_name}</span>
                    <span className="text-xs text-slate-400">{(file.file_size / 1024).toFixed(0)} KB</span>
                    <button
                      onClick={() => handleRemoveFile(file)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-white border-t border-slate-200 px-6 py-4 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-100 transition"
          >
            Batal
          </button>
          <button
            onClick={handleSave}
            disabled={saving || uploading}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 transition disabled:opacity-60"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileCheck2 className="w-4 h-4" />}
            {isEdit ? 'Simpan Perubahan' : 'Simpan Pajak'}
          </button>
        </div>
      </div>
    </div>
  );
}
