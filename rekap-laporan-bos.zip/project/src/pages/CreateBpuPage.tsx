import { useState, useEffect, FormEvent } from 'react';
import { supabase } from '@/lib/supabase';
import { Vendor } from '@/lib/types';
import { formatAngka, formatRupiah } from '@/lib/terbilang';
import {
  FilePlus, Plus, Trash2, Loader2, AlertCircle, Save, X, ArrowLeft, Package,
} from 'lucide-react';

interface LineItem {
  key: string;
  nama_barang: string;
  banyak_nya: string;
  satuan: string;
  harga_satuan: string;
  pph: string;
}

let itemKeyCounter = 0;
function nextKey() {
  itemKeyCounter += 1;
  return `item-${itemKeyCounter}-${Date.now()}`;
}

function emptyItem(): LineItem {
  return { key: nextKey(), nama_barang: '', banyak_nya: '', satuan: 'Unit', harga_satuan: '', pph: '' };
}

const SATUAN_OPTIONS = ['Unit', 'buah', 'kotak', 'pack', 'lusin', 'set', 'rim', 'botol', 'galon', 'pelajaran', 'lembar', 'eksemplar', 'kali'];

interface CreateBpuPageProps {
  onDone: () => void;
  onCancel: () => void;
}

export default function CreateBpuPage({ onDone, onCancel }: CreateBpuPageProps) {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const [noBpu, setNoBpu] = useState('');
  const [tanggalPesanan, setTanggalPesanan] = useState('');
  const [tanggalPembayaran, setTanggalPembayaran] = useState('');
  const [kodeKegiatan, setKodeKegiatan] = useState('');
  const [kodeRekening, setKodeRekening] = useState('');
  const [vendorId, setVendorId] = useState('');
  const [penerimaNama, setPenerimaNama] = useState('');
  const [penerimaPekerjaan, setPenerimaPekerjaan] = useState('');
  const [penerimaAlamat, setPenerimaAlamat] = useState('');
  const [items, setItems] = useState<LineItem[]>([emptyItem()]);

  useEffect(() => {
    fetchVendors();
  }, []);

  async function fetchVendors() {
    setLoading(true);
    const { data, error } = await supabase
      .from('master_vendor')
      .select('*')
      .order('nama_toko');
    if (error) setError('Gagal memuat vendor: ' + error.message);
    else setVendors(data || []);
    setLoading(false);
  }

  function addItem() {
    setItems([...items, emptyItem()]);
  }

  function removeItem(key: string) {
    setItems(items.filter((i) => i.key !== key));
  }

  function updateItem(key: string, field: keyof Omit<LineItem, 'key'>, value: string) {
    setItems(items.map((i) => (i.key === key ? { ...i, [field]: value } : i)));
  }

  function computeLineTotal(item: LineItem): number {
    const qty = parseFloat(item.banyak_nya) || 0;
    const price = parseFloat(item.harga_satuan) || 0;
    return qty * price;
  }

  const grandTotal = items.reduce((sum, i) => sum + computeLineTotal(i), 0);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');

    if (!noBpu.trim()) {
      setError('Nomor BPU wajib diisi.');
      return;
    }
    if (!tanggalPesanan || !tanggalPembayaran) {
      setError('Tanggal pesanan dan tanggal pembayaran wajib diisi.');
      return;
    }
    if (!vendorId) {
      setError('Vendor wajib dipilih.');
      return;
    }
    if (!penerimaPekerjaan.trim()) {
      setError('Pekerjaan/Toko pada bagian Yang Menerima wajib diisi (nama toko atau jenis pekerjaan).');
      return;
    }
    const validItems = items.filter(
      (i) => i.nama_barang.trim() && parseFloat(i.banyak_nya) > 0
    );
    if (validItems.length === 0) {
      setError('Minimal satu barang harus diisi dengan nama dan jumlah yang valid.');
      return;
    }

    setSaving(true);

    // Check for duplicate no_bpu
    const { data: existing } = await supabase
      .from('transaksi_bpu')
      .select('no_bpu')
      .eq('no_bpu', noBpu.trim())
      .maybeSingle();
    if (existing) {
      setError('Nomor BPU sudah ada. Gunakan nomor yang berbeda.');
      setSaving(false);
      return;
    }

    // Insert header
    const { error: headerError } = await supabase.from('transaksi_bpu').insert({
      no_bpu: noBpu.trim(),
      tanggal_pesanan: tanggalPesanan,
      tanggal_pembayaran: tanggalPembayaran,
      kode_kegiatan: kodeKegiatan.trim(),
      kode_rekening: kodeRekening.trim(),
      vendor_id: vendorId,
      penerima_nama: penerimaNama.trim(),
      penerima_pekerjaan: penerimaPekerjaan.trim(),
      penerima_alamat: penerimaAlamat.trim(),
    });
    if (headerError) {
      setError('Gagal menyimpan BPU: ' + headerError.message);
      setSaving(false);
      return;
    }

    // Insert line items
    const detailRows = validItems.map((i) => ({
      bpu_id: noBpu.trim(),
      nama_barang: i.nama_barang.trim(),
      banyak_nya: parseInt(i.banyak_nya, 10),
      satuan: i.satuan,
      harga_satuan: parseFloat(i.harga_satuan) || 0,
      pph: i.pph.trim() || null,
    }));
    const { error: detailError } = await supabase.from('detail_barang_bpu').insert(detailRows);
    if (detailError) {
      // Rollback header
      await supabase.from('transaksi_bpu').delete().eq('no_bpu', noBpu.trim());
      setError('Gagal menyimpan detail barang: ' + detailError.message);
      setSaving(false);
      return;
    }

    setSaving(false);
    onDone();
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={onCancel}
          className="p-2 rounded-xl bg-white border border-slate-200 text-slate-500 hover:text-slate-700 hover:bg-slate-50 transition"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center">
            <FilePlus className="w-6 h-6 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">Input BPU Baru</h1>
            <p className="text-slate-500 text-sm">Buat Bukti Pengeluaran Uang dengan detail barang</p>
          </div>
        </div>
      </div>

      {error && (
        <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Header Section */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
            <h2 className="text-sm font-semibold text-slate-700">Informasi BPU</h2>
            <p className="text-xs text-slate-500 mt-0.5">Data ini berlaku untuk semua barang dalam BPU</p>
          </div>
          <div className="p-6 grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Nomor BPU *</label>
              <input
                type="text"
                value={noBpu}
                onChange={(e) => setNoBpu(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                placeholder="BPU01"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Vendor *</label>
              <select
                value={vendorId}
                onChange={(e) => {
                  setVendorId(e.target.value);
                  const v = vendors.find((x) => x.id === e.target.value);
                  if (v) {
                    setPenerimaPekerjaan(v.nama_toko);
                    setPenerimaAlamat(v.alamat_toko || '');
                  }
                }}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                required
              >
                <option value="">— Pilih Vendor —</option>
                {vendors.map((v) => (
                  <option key={v.id} value={v.id}>{v.nama_toko}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Tanggal Pesanan *</label>
              <input
                type="date"
                value={tanggalPesanan}
                onChange={(e) => setTanggalPesanan(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Tanggal Pembayaran *</label>
              <input
                type="date"
                value={tanggalPembayaran}
                onChange={(e) => setTanggalPembayaran(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Kode Kegiatan</label>
              <input
                type="text"
                value={kodeKegiatan}
                onChange={(e) => setKodeKegiatan(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                placeholder="06.05.09."
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Kode Rekening</label>
              <input
                type="text"
                value={kodeRekening}
                onChange={(e) => setKodeRekening(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                placeholder="5.1.02.01.01.0030"
              />
            </div>
          </div>
        </div>

        {/* Yang Menerima Section */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
            <h2 className="text-sm font-semibold text-slate-700">Yang Menerima (Tanda Penerimaan)</h2>
            <p className="text-xs text-slate-500 mt-0.5">Data penerima untuk dokumen Tanda Penerimaan. Pilih vendor untuk mengisi otomatis, atau ketik manual (nama toko, profesi, atau jenis pekerjaan).</p>
          </div>
          <div className="p-6 grid sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Nama Penerima *</label>
              <input
                type="text"
                value={penerimaNama}
                onChange={(e) => setPenerimaNama(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                placeholder="Nama penerima uang"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Pekerjaan / Toko *</label>
              <input
                type="text"
                value={penerimaPekerjaan}
                onChange={(e) => setPenerimaPekerjaan(e.target.value)}
                list="vendor-pekerjaan-options"
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                placeholder="KPRI Bina Rata, Teknisi AC, Tukang Bangunan, dll."
              />
              <datalist id="vendor-pekerjaan-options">
                {vendors.map((v) => (
                  <option key={v.id} value={v.nama_toko} />
                ))}
              </datalist>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1.5">Alamat</label>
              <input
                type="text"
                value={penerimaAlamat}
                onChange={(e) => setPenerimaAlamat(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                placeholder="Alamat penerima"
              />
            </div>
          </div>
        </div>

        {/* Line Items */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                <Package className="w-4 h-4 text-slate-400" />
                Detail Barang
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">Tambahkan satu atau lebih barang dalam BPU ini</p>
            </div>
            <button
              type="button"
              onClick={addItem}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-50 text-emerald-700 font-medium text-xs hover:bg-emerald-100 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              Tambah Baris
            </button>
          </div>

          {/* Desktop table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
                  <th className="px-4 py-3 text-left font-semibold w-8">No</th>
                  <th className="px-4 py-3 text-left font-semibold">Nama Barang</th>
                  <th className="px-4 py-3 text-left font-semibold w-24">Banyaknya</th>
                  <th className="px-4 py-3 text-left font-semibold w-28">Satuan</th>
                  <th className="px-4 py-3 text-right font-semibold w-32">Harga Satuan (Rp)</th>
                  <th className="px-4 py-3 text-right font-semibold w-32">Jumlah (Rp)</th>
                  <th className="px-4 py-3 text-left font-semibold w-24">PPh</th>
                  <th className="px-4 py-3 text-center font-semibold w-12"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {items.map((item, idx) => (
                  <tr key={item.key} className="hover:bg-slate-50/50">
                    <td className="px-4 py-2.5 text-slate-500 font-medium">{idx + 1}</td>
                    <td className="px-4 py-2.5">
                      <input
                        type="text"
                        value={item.nama_barang}
                        onChange={(e) => updateItem(item.key, 'nama_barang', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                        placeholder="Sabun pencuci piring"
                      />
                    </td>
                    <td className="px-4 py-2.5">
                      <input
                        type="number"
                        min="0"
                        value={item.banyak_nya}
                        onChange={(e) => updateItem(item.key, 'banyak_nya', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                        placeholder="0"
                      />
                    </td>
                    <td className="px-4 py-2.5">
                      <select
                        value={item.satuan}
                        onChange={(e) => updateItem(item.key, 'satuan', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                      >
                        {SATUAN_OPTIONS.map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </td>
                    <td className="px-4 py-2.5">
                      <input
                        type="number"
                        min="0"
                        step="100"
                        value={item.harga_satuan}
                        onChange={(e) => updateItem(item.key, 'harga_satuan', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 text-right focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                        placeholder="0"
                      />
                    </td>
                    <td className="px-4 py-2.5 text-right font-semibold text-slate-700">
                      {formatAngka(computeLineTotal(item))}
                    </td>
                    <td className="px-4 py-2.5">
                      <input
                        type="text"
                        value={item.pph}
                        onChange={(e) => updateItem(item.key, 'pph', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                        placeholder="-"
                      />
                    </td>
                    <td className="px-4 py-2.5 text-center">
                      {items.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeItem(item.key)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-50 border-t-2 border-slate-200">
                  <td colSpan={5} className="px-4 py-3 text-right font-semibold text-slate-700 text-sm">
                    Total Pengeluaran:
                  </td>
                  <td className="px-4 py-3 text-right font-bold text-amber-600 text-base">
                    {formatRupiah(grandTotal)}
                  </td>
                  <td colSpan={2}></td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="md:hidden divide-y divide-slate-100">
            {items.map((item, idx) => (
              <div key={item.key} className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-400">Barang #{idx + 1}</span>
                  {items.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeItem(item.key)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
                <input
                  type="text"
                  value={item.nama_barang}
                  onChange={(e) => updateItem(item.key, 'nama_barang', e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                  placeholder="Nama barang"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    min="0"
                    value={item.banyak_nya}
                    onChange={(e) => updateItem(item.key, 'banyak_nya', e.target.value)}
                    className="px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                    placeholder="Jumlah"
                  />
                  <select
                    value={item.satuan}
                    onChange={(e) => updateItem(item.key, 'satuan', e.target.value)}
                    className="px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                  >
                    {SATUAN_OPTIONS.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <input
                  type="number"
                  min="0"
                  step="100"
                  value={item.harga_satuan}
                  onChange={(e) => updateItem(item.key, 'harga_satuan', e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                  placeholder="Harga satuan"
                />
                <input
                  type="text"
                  value={item.pph}
                  onChange={(e) => updateItem(item.key, 'pph', e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition"
                  placeholder="PPh (opsional)"
                />
                <p className="text-right text-sm font-semibold text-slate-700">
                  Jumlah: {formatRupiah(computeLineTotal(item))}
                </p>
              </div>
            ))}
            <div className="p-4 bg-slate-50 flex items-center justify-between">
              <span className="font-semibold text-slate-700 text-sm">Total:</span>
              <span className="font-bold text-amber-600 text-base">{formatRupiah(grandTotal)}</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-slate-600 font-medium text-sm hover:bg-slate-100 transition"
          >
            <X className="w-4 h-4" />
            Batal
          </button>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold text-sm shadow-lg shadow-amber-500/20 hover:from-amber-600 hover:to-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500/40 transition disabled:opacity-60"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saving ? 'Menyimpan...' : 'Simpan BPU'}
          </button>
        </div>
      </form>
    </div>
  );
}
