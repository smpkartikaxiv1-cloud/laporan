import { renderToString } from 'react-dom/server';
import { renderDoc, DocType, DOC_FILENAMES } from '@/components/DocTemplates';
import { BpuFull, Pejabat } from '@/lib/types';

const PRINT_CSS = `
  @page { size: auto; margin: 15mm; }
  * { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  html, body { margin: 0; padding: 0; background: #fff; }
  body { font-family: Arial, sans-serif; font-size: 12pt; line-height: 1.25; }
  .print-page {
    width: 100%;
    min-height: calc(100vh - 30mm);
    page-break-after: always;
    break-after: page;
    page-break-inside: avoid;
    break-inside: avoid;
  }
  .print-page:last-child { page-break-after: auto; break-after: auto; }
  table { max-width: 100%; page-break-inside: auto; break-inside: auto; }
  tr, img { page-break-inside: avoid; break-inside: avoid; }
  @media print {
    .no-print { display: none !important; }
    h1, h2, h3, p { orphans: 3; widows: 3; }
  }
`;

function buildHtml(content: string): string {
  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SPJ Document</title>
  <style>${PRINT_CSS}</style>
</head>
<body>
${content}
</body>
</html>`;
}

/**
 * Opens a hidden iframe, writes the document HTML, triggers print, then removes the iframe.
 * Works for both "print" (user picks printer) and "save as PDF".
 */
export function printDocuments(
  bpu: BpuFull,
  pejabat: Record<string, Pejabat>,
  types: DocType[],
  filenamePrefix: string,
): void {
  const pages = types
    .map((type) => {
      const element = renderDoc(type, { bpu, pejabat });
      const html = renderToString(element);
      return `<div class="print-page">${html}</div>`;
    })
    .join('\n');

  const fullHtml = buildHtml(pages);

  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  iframe.title = filenamePrefix;
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc) return;

  doc.open();
  doc.write(fullHtml);
  doc.close();

  // Wait for images to load before printing
  const images = doc.images || [];
  const imagePromises: Promise<void>[] = [];
  for (let i = 0; i < images.length; i++) {
    if (!images[i].complete) {
      imagePromises.push(
        new Promise((resolve) => {
          images[i].onload = () => resolve();
          images[i].onerror = () => resolve();
        }),
      );
    }
  }

  const doPrint = () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch {
      // ignore
    }
    setTimeout(() => {
      document.body.removeChild(iframe);
    }, 1000);
  };

  if (imagePromises.length > 0) {
    Promise.all(imagePromises).then(() => setTimeout(doPrint, 200));
  } else {
    setTimeout(doPrint, 300);
  }
}

/** Prints all 5 documents as a single bundle. */
export function printBundle(bpu: BpuFull, pejabat: Record<string, Pejabat>): void {
  const allTypes: DocType[] = ['order', 'tanda-terima', 'faktur', 'berita-acara', 'lampiran'];
  printDocuments(bpu, pejabat, allTypes, `Paket_SPJ_${bpu.no_bpu}`);
}

/** Prints a single document type. The browser print dialog lets the user save as PDF. */
export function printSingleDoc(
  bpu: BpuFull,
  pejabat: Record<string, Pejabat>,
  type: DocType,
): void {
  const filename = `${DOC_FILENAMES[type]}_${bpu.no_bpu}`;
  printDocuments(bpu, pejabat, [type], filename);
}

/**
 * Prints Tanda Penerimaan for multiple BPUs in one continuous print job.
 * Each BPU gets its own page (page-break-after: always).
 * The browser print dialog lets the user save as a single combined PDF.
 */
export function printBatchTandaTerima(
  bpus: BpuFull[],
  pejabat: Record<string, Pejabat>,
): void {
  const pages = bpus
    .map((bpu) => {
      const element = renderDoc('tanda-terima', { bpu, pejabat });
      const html = renderToString(element);
      return `<div class="print-page">${html}</div>`;
    })
    .join('\n');

  const fullHtml = buildHtml(pages);

  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  iframe.title = 'Tanda_Penerimaan_Batch';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc) return;

  doc.open();
  doc.write(fullHtml);
  doc.close();

  const images = doc.images || [];
  const imagePromises: Promise<void>[] = [];
  for (let i = 0; i < images.length; i++) {
    if (!images[i].complete) {
      imagePromises.push(
        new Promise((resolve) => {
          images[i].onload = () => resolve();
          images[i].onerror = () => resolve();
        }),
      );
    }
  }

  const doPrint = () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch {
      // ignore
    }
    setTimeout(() => {
      document.body.removeChild(iframe);
    }, 1000);
  };

  if (imagePromises.length > 0) {
    Promise.all(imagePromises).then(() => setTimeout(doPrint, 200));
  } else {
    setTimeout(doPrint, 300);
  }
}
