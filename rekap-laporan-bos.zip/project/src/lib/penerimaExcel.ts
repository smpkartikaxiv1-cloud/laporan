import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { supabase } from '@/lib/supabase';
import { BpuFull } from '@/lib/types';
import { buildYaituText } from '@/lib/yaituText';

export interface PenerimaExportRow {
  'No. BPU': string;
  'Tanggal Pembayaran': string;
  'Uraian/YAITU': string;
  'Nominal': string;
  'Nama Penerima': string;
  'Pekerjaan/Toko': string;
}

function formatTanggal(dateStr: string): string {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
}

function formatAngka(n: number): string {
  return new Intl.NumberFormat('id-ID').format(n || 0);
}

export function exportPenerimaExcel(bpus: BpuFull[]): void {
  const rows: PenerimaExportRow[] = bpus.map((b) => {
    return {
      'No. BPU': b.no_bpu,
      'Tanggal Pembayaran': formatTanggal(b.tanggal_pembayaran),
      'Uraian/YAITU': buildYaituText(b),
      'Nominal': formatAngka(b.total),
      'Nama Penerima': b.penerima_nama || '',
      'Pekerjaan/Toko': b.penerima_pekerjaan || b.vendor?.nama_toko || '',
    };
  });

  const ws = XLSX.utils.json_to_sheet(rows, {
    header: ['No. BPU', 'Tanggal Pembayaran', 'Uraian/YAITU', 'Nominal', 'Nama Penerima', 'Pekerjaan/Toko'],
  });

  ws['!cols'] = [
    { wch: 12 },
    { wch: 22 },
    { wch: 50 },
    { wch: 16 },
    { wch: 28 },
    { wch: 28 },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Data Penerima');

  const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  saveAs(blob, `Data_Penerima_BPU_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

export interface ImportResult {
  updated: number;
  skipped: number;
  errors: string[];
}

export async function importPenerimaExcel(file: File): Promise<ImportResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: 'array' });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: '' });

  const result: ImportResult = { updated: 0, skipped: 0, errors: [] };

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const noBpu = String(row['No. BPU'] ?? '').trim();
    const nama = String(row['Nama Penerima'] ?? '').trim();
    const pekerjaan = String(row['Pekerjaan/Toko'] ?? '').trim();

    if (!noBpu) {
      result.errors.push(`Baris ${i + 2}: No. BPU kosong, dilewati.`);
      result.skipped++;
      continue;
    }

    if (!nama && !pekerjaan) {
      result.skipped++;
      continue;
    }

    const update: Record<string, string> = {};
    if (nama) update.penerima_nama = nama;
    if (pekerjaan) update.penerima_pekerjaan = pekerjaan;

    const { error } = await supabase
      .from('transaksi_bpu')
      .update(update)
      .eq('no_bpu', noBpu);

    if (error) {
      result.errors.push(`Baris ${i + 2} (No. BPU ${noBpu}): ${error.message}`);
      result.skipped++;
    } else {
      result.updated++;
    }
  }

  return result;
}
