export interface Pejabat {
  id: string;
  peran: string;
  nama: string;
  nip: string;
  created_at?: string;
  updated_at?: string;
}

export interface Vendor {
  id: string;
  nama_toko: string;
  alamat_toko: string;
  telepon: string;
  created_at?: string;
}

export interface BPU {
  no_bpu: string;
  tanggal_pesanan: string;
  tanggal_pembayaran: string;
  kode_kegiatan: string;
  kode_rekening: string;
  vendor_id: string;
  penerima_nama?: string;
  penerima_pekerjaan?: string;
  penerima_alamat?: string;
  uraian_yaitu?: string | null;
  created_at?: string;
}

export interface DetailBarang {
  id: string;
  bpu_id: string;
  nama_barang: string;
  banyak_nya: number;
  satuan: string;
  harga_satuan: number;
  pengeluaran: number;
  pph?: string | null;
  created_at?: string;
}

export interface BpuWithRelations extends BPU {
  vendor?: Vendor;
  detail_barang?: DetailBarang[];
}

export interface BpuFull extends BPU {
  vendor: Vendor | null;
  items: DetailBarang[];
  total: number;
}

export type PajakStatus = 'Draft' | 'Menunggu Persetujuan' | 'Disetujui' | 'Ditolak';

export interface PajakBPU {
  id: string;
  tax_number: string;
  bpu_number: string;
  jenis_pajak: string;
  dasar_pengenaan_pajak: number;
  nominal_pajak: number;
  ntpn: string;
  tanggal_setor: string;
  status: PajakStatus;
  created_at?: string;
  updated_at?: string;
}

export interface NotaPajakFile {
  id: string;
  pajak_id: string;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
  created_at?: string;
}

export interface PajakFull extends PajakBPU {
  files: NotaPajakFile[];
}

export type BpuDocType = 'kwitansi' | 'foto_barang';

export interface BpuDocument {
  id: string;
  bpu_number: string;
  doc_type: BpuDocType;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
  created_at?: string;
}

export interface BpuDocumentLog {
  id: string;
  bpu_number: string;
  file_name: string;
  action: 'upload' | 'replace' | 'delete';
  user_name: string;
  created_at?: string;
}
