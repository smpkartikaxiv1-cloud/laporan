import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { supabase } from '@/lib/supabase';
import { BpuFull } from '@/lib/types';
import { buildYaituText } from '@/lib/yaituText';

export interface YaituExportRow {
  'No_BPU': string;
  'Tanggal_BPU': string;
  'Uraian_Yaitu_Lama': string;
  'Uraian_Yaitu_Baru': string;
}

function formatTanggal(dateStr: string): string {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
}

export function exportYaituExcel(bpus: BpuFull[]): void {
  const rows: YaituExportRow[] = bpus.map((b) => ({
    'No_BPU': b.no_bpu,
    'Tanggal_BPU': formatTanggal(b.tanggal_pembayaran),
    'Uraian_Yaitu_Lama': buildYaituText(b),
    'Uraian_Yaitu_Baru': '',
  }));

  const ws = XLSX.utils.json_to_sheet(rows, {
    header: ['No_BPU', 'Tanggal_BPU', 'Uraian_Yaitu_Lama', 'Uraian_Yaitu_Baru'],
  });

  ws['!cols'] = [
    { wch: 12 },
    { wch: 22 },
    { wch: 55 },
    { wch: 55 },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Data Uraian YAITU');

  const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  saveAs(blob, `Data_Uraian_YAITU_BPU_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

export interface YaituImportResult {
  updated: number;
  skipped: number;
  errors: string[];
}

export async function importYaituExcel(file: File): Promise<YaituImportResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: 'array' });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: '' });

  const result: YaituImportResult = { updated: 0, skipped: 0, errors: [] };

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const noBpu = String(row['No_BPU'] ?? '').trim();
    const uraianBaru = String(row['Uraian_Yaitu_Baru'] ?? '').trim();
    const uraianLama = String(row['Uraian_Yaitu_Lama'] ?? '').trim();

    if (!noBpu) {
      result.errors.push(`Baris ${i + 2}: No_BPU kosong, dilewati.`);
      result.skipped++;
      continue;
    }

    const finalUraian = uraianBaru || uraianLama;
    if (!finalUraian) {
      result.skipped++;
      continue;
    }

    const { error } = await supabase
      .from('transaksi_bpu')
      .update({ uraian_yaitu: finalUraian })
      .eq('no_bpu', noBpu);

    if (error) {
      result.errors.push(`Baris ${i + 2} (No_BPU ${noBpu}): ${error.message}`);
      result.skipped++;
    } else {
      result.updated++;
    }
  }

  return result;
}
