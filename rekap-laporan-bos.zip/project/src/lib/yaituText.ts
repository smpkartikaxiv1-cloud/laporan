import { BpuFull } from '@/lib/types';

const TAGIHAN_RUTIN_PATTERNS = [
  'tagihan internet',
  'internet',
  'tagihan listrik',
  'listrik',
];

export function isTagihanRutini(bpu: BpuFull): boolean {
  const itemText = bpu.items.map((i) => i.nama_barang.toLowerCase()).join(' ');
  const pekerjaan = (bpu.penerima_pekerjaan || '').toLowerCase();
  const vendor = (bpu.vendor?.nama_toko || '').toLowerCase();
  const combined = `${itemText} ${pekerjaan} ${vendor}`;
  return TAGIHAN_RUTIN_PATTERNS.some((p) => combined.includes(p));
}

export function buildYaituText(bpu: BpuFull): string {
  if (bpu.uraian_yaitu && bpu.uraian_yaitu.trim()) {
    return bpu.uraian_yaitu.trim();
  }

  const itemsSummary = bpu.items.map((i) => i.nama_barang).join(', ') || 'Barang';
  const rutin = isTagihanRutini(bpu);

  if (rutin) {
    const bulanTahun = new Date(bpu.tanggal_pembayaran).toLocaleDateString('id-ID', {
      month: 'long',
      year: 'numeric',
    });
    return `Pembayaran Biaya Pembelian ${itemsSummary} - ${bulanTahun}`;
  }

  return `Pembayaran Biaya Pembelian ${itemsSummary}`;
}
