// Indonesian currency + date helpers for official SPJ documents.

const SATUAN = [
  '',
  'satu',
  'dua',
  'tiga',
  'empat',
  'lima',
  'enam',
  'tujuh',
  'delapan',
  'sembilan',
  'sepuluh',
  'sebelas',
];

function terbilangBasic(n: number): string {
  if (n < 12) return SATUAN[n];
  if (n < 20) return terbilangBasic(n - 10) + ' belas';
  if (n < 100) {
    const puluh = Math.floor(n / 10);
    const sisa = n % 10;
    return SATUAN[puluh] + ' puluh' + (sisa ? ' ' + terbilangBasic(sisa) : '');
  }
  if (n < 200) return 'seratus' + (n - 100 ? ' ' + terbilangBasic(n - 100) : '');
  if (n < 1000) {
    const ratus = Math.floor(n / 100);
    const sisa = n % 100;
    return SATUAN[ratus] + ' ratus' + (sisa ? ' ' + terbilangBasic(sisa) : '');
  }
  if (n < 2000) return 'seribu' + (n - 1000 ? ' ' + terbilangBasic(n - 1000) : '');
  if (n < 1000000) {
    const ribu = Math.floor(n / 1000);
    const sisa = n % 1000;
    return terbilangBasic(ribu) + ' ribu' + (sisa ? ' ' + terbilangBasic(sisa) : '');
  }
  if (n < 1000000000) {
    const juta = Math.floor(n / 1000000);
    const sisa = n % 1000000;
    return terbilangBasic(juta) + ' juta' + (sisa ? ' ' + terbilangBasic(sisa) : '');
  }
  if (n < 1000000000000) {
    const miliar = Math.floor(n / 1000000000);
    const sisa = n % 1000000000;
    return terbilangBasic(miliar) + ' miliar' + (sisa ? ' ' + terbilangBasic(sisa) : '');
  }
  const triliun = Math.floor(n / 1000000000000);
  const sisa = n % 1000000000000;
  return terbilangBasic(triliun) + ' triliun' + (sisa ? ' ' + terbilangBasic(sisa) : '');
}

/**
 * Converts a number into Indonesian currency words in proper case,
 * ending with "rupiah".
 * Example: 676300 -> "Enam ratus tujuh puluh enam ribu tiga ratus rupiah"
 */
export function terbilang(angka: number): string {
  const rounded = Math.round(Math.abs(angka));
  if (rounded === 0) return 'Nol rupiah';
  const lower = terbilangBasic(rounded) + ' rupiah';
  // Proper case: capitalize first letter only, keep rest lowercase.
  return lower.charAt(0).toUpperCase() + lower.slice(1);
}

const NAMA_HARI = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

const NAMA_BULAN = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

/**
 * Converts a YYYY-MM-DD date string into a formal Indonesian document date
 * narration including the day name.
 * Example: "2026-01-28" -> "Kamis tanggal Dua Puluh Delapan Bulan Januari Tahun Dua Ribu Dua Puluh Enam"
 */
export function tanggalTerbilang(stringTanggal: string): string {
  const parts = stringTanggal.split('-');
  if (parts.length !== 3) return stringTanggal;
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const day = parseInt(parts[2], 10);
  if (Number.isNaN(year) || Number.isNaN(month) || Number.isNaN(day)) return stringTanggal;

  const date = new Date(year, month - 1, day);
  const hari = NAMA_HARI[date.getDay()];
  const hariText = terbilang(day);
  const bulanText = NAMA_BULAN[month - 1];
  const tahunText = terbilang(year);

  return `${hari} tanggal ${hariText} Bulan ${bulanText} Tahun ${tahunText}`;
}

/** Formats a number as Indonesian rupiah currency string (e.g. "Rp 676.300"). */
export function formatRupiah(value: number): string {
  return 'Rp ' + new Intl.NumberFormat('id-ID', { maximumFractionDigits: 0 }).format(value);
}

/** Formats a number with Indonesian thousand separators, no currency prefix. */
export function formatAngka(value: number): string {
  return new Intl.NumberFormat('id-ID', { maximumFractionDigits: 0 }).format(value);
}
