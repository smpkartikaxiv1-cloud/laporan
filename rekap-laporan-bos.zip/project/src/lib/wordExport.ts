import {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  WidthType, AlignmentType, BorderStyle, ImageRun, PageOrientation,
  convertInchesToTwip,
} from 'docx';
import { saveAs } from 'file-saver';
import { BpuFull, Pejabat } from '@/lib/types';
import { terbilang, tanggalTerbilang, formatAngka } from '@/lib/terbilang';
import { DocType, DOC_FILENAMES } from '@/components/DocTemplates';
import { getLogoFromStorage, LOGO_KIRI_KEY, LOGO_KANAN_KEY } from '@/context/LogoContext';
import { getSchoolIdentityFromStorage } from '@/context/SchoolContext';
import { buildYaituText } from '@/lib/yaituText';

const BLACK = '000000';
const NO_BORDER = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' } as const;
const GRID_BORDER = { style: BorderStyle.SINGLE, size: 1, color: BLACK } as const;
const ALL_BORDERS = { top: GRID_BORDER, bottom: GRID_BORDER, left: GRID_BORDER, right: GRID_BORDER };
const NO_CELL_BORDERS = { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER };

async function fetchLogoData(key: string): Promise<ArrayBuffer | null> {
  const logoUrl = getLogoFromStorage(key);
  if (!logoUrl) return null;
  try {
    const res = await fetch(logoUrl);
    if (!res.ok) return null;
    return await res.arrayBuffer();
  } catch {
    return null;
  }
}

function p(text: string, opts?: { bold?: boolean; size?: number; align?: (typeof AlignmentType)[keyof typeof AlignmentType]; underline?: boolean; italics?: boolean; color?: string }): Paragraph {
  return new Paragraph({
    alignment: opts?.align,
    children: [new TextRun({ text, bold: opts?.bold, size: opts?.size ?? 22, underline: opts?.underline ? {} : undefined, italics: opts?.italics, color: opts?.color ?? BLACK })],
    spacing: { after: 40 },
  });
}

function emptyP(after = 40): Paragraph {
  return new Paragraph({ children: [new TextRun({ text: '' })], spacing: { after } });
}

function cell(children: Paragraph[], opts?: { width?: number; borders?: typeof ALL_BORDERS; shading?: string; verticalAlign?: 'center' | 'top' | 'bottom' }): TableCell {
  return new TableCell({
    children,
    width: opts?.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
    borders: opts?.borders ?? NO_CELL_BORDERS,
    margins: { top: 40, bottom: 40, left: 80, right: 80 },
  });
}

async function fetchImage(url: string): Promise<ArrayBuffer | null> {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    return await res.arrayBuffer();
  } catch {
    return null;
  }
}

async function kopSurat(): Promise<(Table | Paragraph)[]> {
  const school = getSchoolIdentityFromStorage();
  const dinasData = await fetchLogoData(LOGO_KIRI_KEY);
  const sekolahData = await fetchLogoData(LOGO_KANAN_KEY);
  const dinasImg = dinasData ? new Uint8Array(dinasData) : null;
  const sekolahImg = sekolahData ? new Uint8Array(sekolahData) : null;

  // Left: Logo Dinas Pendidikan / Pemda
  const dinasPara: Paragraph = dinasImg
    ? new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new ImageRun({ data: dinasImg, transformation: { width: 70, height: 75 } })],
      })
    : new Paragraph({ children: [new TextRun({ text: '', size: 16 })], alignment: AlignmentType.CENTER });

  // Right: Logo Sekolah from localStorage
  const schoolLogoPara: Paragraph = sekolahImg
    ? new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new ImageRun({ data: sekolahImg, transformation: { width: 70, height: 75 } })],
      })
    : new Paragraph({ children: [new TextRun({ text: '', size: 16 })], alignment: AlignmentType.CENTER });

  const centerText = (text: string, bold: boolean, size: number) =>
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text, bold, size, color: BLACK })],
      spacing: { after: 20 },
    });

  const headerTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      new TableRow({
        children: [
          cell([dinasPara], { width: 14 }),
          cell([
            centerText(`PEMERINTAH KOTA ${school.kota.toUpperCase()}`, true, 28),
            centerText('DINAS PENDIDIKAN DAN KEBUDAYAAN', true, 32),
            centerText(school.namaSekolah.toUpperCase(), true, 44),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [new TextRun({ text: school.alamat, size: 20, color: '333333' })],
              spacing: { after: 0 },
            }),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [new TextRun({ text: `E-mail: ${school.email} | Website: ${school.website}`, size: 20, color: '333333' })],
              spacing: { after: 0 },
            }),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [new TextRun({ text: `Kode Pos: ${school.kodePos}`, bold: true, size: 20, color: BLACK })],
              spacing: { after: 0 },
            }),
          ], { width: 72 }),
          cell([schoolLogoPara], { width: 14 }),
        ],
      }),
    ],
  });

  const lineP = new Paragraph({
    border: { bottom: { style: BorderStyle.SINGLE, size: 18, color: BLACK } },
    spacing: { after: 0, before: 60 },
    children: [new TextRun({ text: '' })],
  });
  const thinLineP = new Paragraph({
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: BLACK } },
    spacing: { after: 200 },
    children: [new TextRun({ text: '' })],
  });

  return [headerTable, lineP, thinLineP];
}

function infoRow(label: string, value: string): TableRow {
  return new TableRow({
    children: [
      cell([p(label)], { width: 25 }),
      cell([p(`: ${value}`)], { width: 75 }),
    ],
  });
}

function infoRow2(label: string, value: string): TableRow {
  return new TableRow({
    children: [
      cell([p(label)], { width: 30 }),
      cell([p(`: ${value}`)], { width: 70 }),
    ],
  });
}

function gridCell(text: string, opts?: { bold?: boolean; align?: (typeof AlignmentType)[keyof typeof AlignmentType]; width?: number }): TableCell {
  return cell([p(text, { bold: opts?.bold, align: opts?.align })], { borders: ALL_BORDERS, width: opts?.width });
}

function signatureBlock(
  role: string,
  name: string,
  nip: string,
  dateStr: string,
  widthPct: number,
  extraLine?: string,
): TableCell {
  const school = getSchoolIdentityFromStorage();
  const children: Paragraph[] = [
    p(`${school.kota}, ${dateStr}`, { align: AlignmentType.CENTER, size: 22 }),
    p(role, { align: AlignmentType.CENTER, size: 22 }),
    emptyP(1200),
    p(name || '', { align: AlignmentType.CENTER, bold: true, underline: true, size: 22 }),
  ];
  if (nip) children.push(p(`NIP. ${nip}`, { align: AlignmentType.CENTER, size: 22 }));
  if (extraLine) children.push(p(extraLine, { align: AlignmentType.CENTER, bold: true, size: 22 }));
  return cell(children, { width: widthPct });
}

function buildOrderDoc(bpu: BpuFull, pejabat: Record<string, Pejabat>, kop: (Table | Paragraph)[]): (Table | Paragraph)[] {
  const kepala = pejabat['Kepala Sekolah'];
  const vendor = bpu.vendor;
  const tgl = new Date(bpu.tanggal_pesanan).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });

  const headerInfo = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      infoRow('Tanggal Pesanan', tgl),
      infoRow('Kepada', vendor?.nama_toko || '-'),
      infoRow('', vendor?.alamat_toko || ''),
      infoRow('No. BPU', bpu.no_bpu),
    ],
  });

  const itemRows = bpu.items.map((item, idx) =>
    new TableRow({
      children: [
        gridCell(String(idx + 1), { align: AlignmentType.CENTER, width: 8 }),
        gridCell(item.nama_barang),
        gridCell(`${item.banyak_nya} ${item.satuan}`, { align: AlignmentType.CENTER, width: 20 }),
      ],
    }),
  );

  const itemTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      new TableRow({
        tableHeader: true,
        children: [
          gridCell('No', { bold: true, align: AlignmentType.CENTER, width: 8 }),
          gridCell('Jenis Barang', { bold: true, width: 72 }),
          gridCell('Banyaknya', { bold: true, align: AlignmentType.CENTER, width: 20 }),
        ],
      }),
      ...itemRows,
    ],
  });

  const sigTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      new TableRow({
        children: [
          cell([emptyP()], { width: 55 }),
          signatureBlock('Kepala Sekolah,', kepala?.nama || '', kepala?.nip || '', tgl, 45),
        ],
      }),
    ],
  });

  return [...kop, p('SURAT PESANAN', { bold: true, underline: true, align: AlignmentType.CENTER, size: 28 }), emptyP(120), headerInfo, emptyP(120), p('Mohon dapat disediakan barang-barang sebagai berikut:'), emptyP(80), itemTable, sigTable];
}

function buildTandaTerimaDoc(bpu: BpuFull, pejabat: Record<string, Pejabat>, _kop: (Table | Paragraph)[]): (Table | Paragraph)[] {
  const school = getSchoolIdentityFromStorage();
  const kepala = pejabat['Kepala Sekolah'];
  const bendahara = pejabat['Bendahara BOSP'];
  const pengurusBarang = pejabat['Pengurus Barang'];
  const total = bpu.total;
  const totalTerbilang = terbilang(total);
  const tanggalBayar = new Date(bpu.tanggal_pembayaran).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
  const tahun = new Date(bpu.tanggal_pembayaran).getFullYear();
  const penerimaNama = bpu.penerima_nama?.trim() || '............................................';
  const penerimaPekerjaan = bpu.penerima_pekerjaan?.trim() || bpu.vendor?.nama_toko || '-';
  const penerimaAlamat = bpu.penerima_alamat?.trim() || bpu.vendor?.alamat_toko || '-';

  const metadataTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      new TableRow({ children: [cell([p(`No                 : ${bpu.no_bpu}`)]), cell([p('Asli', { underline: true })], { width: 15 })] }),
      new TableRow({ children: [cell([p('M. A              : BOS APBN')]), cell([p('Kedua', { underline: true })], { width: 15 })] }),
      new TableRow({ children: [cell([p(`Tahun           : ${tahun}`, { bold: true })]), cell([p('Ketiga', { underline: true })], { width: 15 })] }),
      new TableRow({ children: [cell([p('')]), cell([p('Keempat', { underline: true })], { width: 15 })] }),
    ],
  });

  const bodyInfo = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      infoRow('Sudah terima dari', `Bendahara BOSP ${school.namaSekolah} Kota ${school.kota}.`),
      new TableRow({ children: [cell([p('Uang banyaknya')], { width: 25 }), cell([p(`: ${totalTerbilang}`, { bold: true, italics: true, underline: true })], { width: 75 })] }),
      new TableRow({ children: [cell([p('Yaitu', { bold: true })], { width: 25 }), cell([p(`: ${buildYaituText(bpu)}`, { bold: true, underline: true })], { width: 75 })] }),
    ],
  });

  const totalTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [infoRow2('TERBILANG', `Rp. ${formatAngka(total)},-`)],
  });

  const penerimaParas: Paragraph[] = [
    p(`Nama              : ${penerimaNama}`, { size: 22 }),
    p(`Pekerjaan/Toko : ${penerimaPekerjaan}`, { size: 22 }),
    p(`Alamat            : ${penerimaAlamat}`, { size: 22 }),
  ];

  const signatures = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      new TableRow({
        children: [
          cell([
            p('Setuju dibayar,', { size: 22 }),
            p('Kepala Sekolah', { size: 22 }),
            emptyP(1200),
            p(kepala?.nama || '', { align: AlignmentType.CENTER, bold: true, underline: true, size: 22 }),
            p(`NIP. ${kepala?.nip || ''}`, { align: AlignmentType.CENTER, size: 22 }),
          ], { width: 52 }),
          cell([
            p(`${school.kota}, ${tanggalBayar}`, { align: AlignmentType.CENTER, size: 22 }),
            p('Yang menerima', { align: AlignmentType.CENTER, size: 22 }),
            emptyP(1000),
            ...penerimaParas,
          ], { width: 48 }),
        ],
      }),
      new TableRow({
        children: [
          cell([
            p('Barang2/Pekerjaan yang dimaksud telah diterima', { size: 20 }),
            p('Diselenggarakan dengan sempurna pada tanggal', { size: 20 }),
            emptyP(1200),
            p('Pengurus barang2/pekerjaan', { size: 20 }),
            emptyP(600),
            p(pengurusBarang?.nama || '', { bold: true, underline: true, size: 20 }),
            p(`NIP.${pengurusBarang?.nip || ''}`, { size: 20 }),
          ], { width: 52 }),
          cell([
            p('Lunas dibayar,', { align: AlignmentType.CENTER, size: 22 }),
            p('Bendahara BOS Sekolah', { align: AlignmentType.CENTER, size: 22 }),
            emptyP(1200),
            p(bendahara?.nama || '', { align: AlignmentType.CENTER, bold: true, underline: true, size: 22 }),
            p(`NIP. ${bendahara?.nip || ''}`, { align: AlignmentType.CENTER, size: 22 }),
          ], { width: 48 }),
        ],
      }),
    ],
  });

  return [metadataTable, emptyP(160), p('TANDA PENERIMAAN', { bold: true, underline: true, align: AlignmentType.CENTER, size: 30 }), emptyP(240), bodyInfo, emptyP(220), signatures, emptyP(100), totalTable];
}

function buildFakturDoc(bpu: BpuFull, _pejabat: Record<string, Pejabat>, _kop: (Table | Paragraph)[]): (Table | Paragraph)[] {
  const vendor = bpu.vendor;
  const total = bpu.total;
  const tgl = new Date(bpu.tanggal_pesanan).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });

  const vendorHeader = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      new TableRow({
        children: [
          cell([
            p(vendor?.nama_toko || '', { bold: true, align: AlignmentType.CENTER, size: 36 }),
            p(vendor?.alamat_toko || '', { align: AlignmentType.CENTER, size: 22 }),
            p(`Telp: ${vendor?.telepon || '-'}`, { align: AlignmentType.CENTER, size: 22 }),
          ]),
        ],
      }),
    ],
  });

  const lineP = new Paragraph({
    border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: BLACK } },
    spacing: { after: 0, before: 40 },
    children: [new TextRun({ text: '' })],
  });
  const thinLineP = new Paragraph({
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: BLACK } },
    spacing: { after: 200 },
    children: [new TextRun({ text: '' })],
  });

  const headerInfo = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [infoRow('No. BPU', bpu.no_bpu), infoRow('Tanggal', tgl)],
  });

  const itemRows = bpu.items.map((item, idx) =>
    new TableRow({
      children: [
        gridCell(String(idx + 1), { align: AlignmentType.CENTER, width: 8 }),
        gridCell(item.nama_barang),
        gridCell(`${item.banyak_nya} ${item.satuan}`, { align: AlignmentType.CENTER, width: 15 }),
        gridCell(formatAngka(item.harga_satuan), { align: AlignmentType.RIGHT, width: 18 }),
        gridCell(formatAngka(item.pengeluaran), { align: AlignmentType.RIGHT, width: 20 }),
      ],
    }),
  );

  const totalRow = new TableRow({
    children: [
      new TableCell({
        children: [p('Jumlah', { bold: true, align: AlignmentType.RIGHT })],
        columnSpan: 4,
        borders: ALL_BORDERS,
        margins: { top: 40, bottom: 40, left: 80, right: 80 },
      }),
      gridCell(formatAngka(total), { bold: true, align: AlignmentType.RIGHT, width: 20 }),
    ],
  });

  const itemTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      new TableRow({
        tableHeader: true,
        children: [
          gridCell('No', { bold: true, align: AlignmentType.CENTER, width: 8 }),
          gridCell('Nama Barang', { bold: true }),
          gridCell('Banyaknya', { bold: true, align: AlignmentType.CENTER, width: 15 }),
          gridCell('Harga @ (Rp)', { bold: true, align: AlignmentType.RIGHT, width: 18 }),
          gridCell('Jumlah (Rp)', { bold: true, align: AlignmentType.RIGHT, width: 20 }),
        ],
      }),
      ...itemRows,
      totalRow,
    ],
  });

  const sigTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      new TableRow({
        children: [
          cell([emptyP()], { width: 55 }),
          signatureBlock('PIMPINAN,', vendor?.nama_toko || '', '', tgl, 45),
        ],
      }),
    ],
  });

  return [vendorHeader, lineP, thinLineP, p('FAKTUR PEMBELIAN', { bold: true, underline: true, align: AlignmentType.CENTER, size: 28 }), emptyP(120), headerInfo, emptyP(120), itemTable, sigTable];
}

function buildBeritaAcaraDoc(bpu: BpuFull, pejabat: Record<string, Pejabat>, kop: (Table | Paragraph)[]): (Table | Paragraph)[] {
  const school = getSchoolIdentityFromStorage();
  const kepala = pejabat['Kepala Sekolah'];
  const vendor = bpu.vendor;
  const total = bpu.total;
  const totalTerbilang = terbilang(total);
  const tanggalBayar = tanggalTerbilang(bpu.tanggal_pembayaran);
  const tgl = new Date(bpu.tanggal_pembayaran).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });

  const party1Table = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      new TableRow({
        children: [
          cell([p('1.', { size: 22 })], { width: 5 }),
          cell([p('Nama', { size: 22 })], { width: 25 }),
          cell([p(':', { size: 22 })], { width: 3 }),
          cell([p(kepala?.nama || '', { size: 22 })], { width: 67 }),
        ],
      }),
      new TableRow({
        children: [
          cell([p('', { size: 22 })], { width: 5 }),
          cell([p('Jabatan', { size: 22 })], { width: 25 }),
          cell([p(':', { size: 22 })], { width: 3 }),
          cell([p(`Kepala Sekolah ${school.namaSekolah} ${school.kota}`, { size: 22 })], { width: 67 }),
        ],
      }),
      new TableRow({
        children: [
          cell([p('', { size: 22 })], { width: 5 }),
          cell([p('NIP', { size: 22 })], { width: 25 }),
          cell([p(':', { size: 22 })], { width: 3 }),
          cell([p(kepala?.nip || '', { size: 22 })], { width: 67 }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({
            children: [p('', { size: 22 })],
            borders: NO_CELL_BORDERS,
            columnSpan: 4,
            margins: { top: 40, bottom: 40, left: 80, right: 80 },
          }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({
            children: [new Paragraph({
              children: [new TextRun({ text: `Dalam hal ini bertindak untuk dan atas nama Pemerintah Kota ${school.kota} selaku Pengguna Anggaran, selanjutnya disebut `, size: 22 }), new TextRun({ text: 'PIHAK PERTAMA', bold: true, size: 22 }), new TextRun({ text: '.', size: 22 })],
              spacing: { after: 80 },
            })],
            borders: NO_CELL_BORDERS,
            columnSpan: 4,
            margins: { top: 0, bottom: 0, left: 80, right: 80 },
          }),
        ],
      }),
    ],
  });

  const party2Table = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      new TableRow({
        children: [
          cell([p('2.', { size: 22 })], { width: 5 }),
          cell([p('Nama Perusahaan', { size: 22 })], { width: 25 }),
          cell([p(':', { size: 22 })], { width: 3 }),
          cell([p(vendor?.nama_toko || '', { size: 22 })], { width: 67 }),
        ],
      }),
      new TableRow({
        children: [
          cell([p('', { size: 22 })], { width: 5 }),
          cell([p('Alamat', { size: 22 })], { width: 25 }),
          cell([p(':', { size: 22 })], { width: 3 }),
          cell([p(vendor?.alamat_toko || '', { size: 22 })], { width: 67 }),
        ],
      }),
      new TableRow({
        children: [
          cell([p('', { size: 22 })], { width: 5 }),
          cell([p('Pimpinan', { size: 22 })], { width: 25 }),
          cell([p(':', { size: 22 })], { width: 3 }),
          cell([p(vendor?.nama_toko || '', { size: 22 })], { width: 67 }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({
            children: [new Paragraph({
              children: [new TextRun({ text: 'Selanjutnya disebut ', size: 22 }), new TextRun({ text: 'PIHAK KEDUA', bold: true, size: 22 }), new TextRun({ text: '.', size: 22 })],
              spacing: { after: 80 },
            })],
            borders: NO_CELL_BORDERS,
            columnSpan: 4,
            margins: { top: 40, bottom: 40, left: 80, right: 80 },
          }),
        ],
      }),
    ],
  });

  const sigTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      new TableRow({
        children: [
          signatureBlock('PIHAK KEDUA,', vendor?.nama_toko || '', '', tgl, 50),
          signatureBlock('PIHAK PERTAMA,', kepala?.nama || '', kepala?.nip || '', '', 50),
        ],
      }),
    ],
  });

  return [
    ...kop,
    p('BERITA ACARA PEMBAYARAN PENGADAAN BARANG/JASA', { bold: true, underline: true, align: AlignmentType.CENTER, size: 28 }),
    emptyP(160),
    new Paragraph({
      children: [new TextRun({ text: `Pada hari ini ${tanggalBayar}, yang bertanda tangan di bawah ini:`, size: 22 })],
      spacing: { after: 120 },
    }),
    party1Table,
    emptyP(80),
    party2Table,
    emptyP(80),
    new Paragraph({
      children: [new TextRun({ text: `PIHAK PERTAMA telah menerima pembayaran dari PIHAK KEDUA sehubungan dengan Surat Pesanan Nomor ${bpu.no_bpu} untuk pengadaan barang dengan jumlah sebesar `, size: 22 }), new TextRun({ text: `Rp ${formatAngka(total)} (${totalTerbilang})`, bold: true, size: 22 }), new TextRun({ text: '.', size: 22 })],
      spacing: { after: 120 },
    }),
    p('Demikian berita acara ini dibuat dengan sebenarnya untuk dapat dipergunakan sebagaimana mestinya.'),
    emptyP(200),
    sigTable,
  ];
}

function buildLampiranDoc(bpu: BpuFull, pejabat: Record<string, Pejabat>, kop: (Table | Paragraph)[]): (Table | Paragraph)[] {
  const pengurusBarang = pejabat['Pengurus Barang'];
  const total = bpu.total;
  const tgl = new Date(bpu.tanggal_pembayaran).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });

  const itemRows = bpu.items.map((item, idx) =>
    new TableRow({
      children: [
        gridCell(String(idx + 1), { align: AlignmentType.CENTER, width: 6 }),
        gridCell(item.nama_barang),
        gridCell(`${item.banyak_nya} ${item.satuan}`, { align: AlignmentType.CENTER, width: 13 }),
        gridCell(formatAngka(item.harga_satuan), { align: AlignmentType.RIGHT, width: 17 }),
        gridCell(formatAngka(item.pengeluaran), { align: AlignmentType.RIGHT, width: 19 }),
        gridCell('Baik', { align: AlignmentType.CENTER, width: 15 }),
      ],
    }),
  );

  const totalRow = new TableRow({
    children: [
      new TableCell({
        children: [p('Jumlah', { bold: true, align: AlignmentType.RIGHT })],
        columnSpan: 4,
        borders: ALL_BORDERS,
        margins: { top: 40, bottom: 40, left: 80, right: 80 },
      }),
      gridCell(formatAngka(total), { bold: true, align: AlignmentType.RIGHT, width: 19 }),
      gridCell('', { width: 15 }),
    ],
  });

  const itemTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      new TableRow({
        tableHeader: true,
        children: [
          gridCell('No', { bold: true, align: AlignmentType.CENTER, width: 6 }),
          gridCell('Nama Barang', { bold: true }),
          gridCell('Banyaknya', { bold: true, align: AlignmentType.CENTER, width: 13 }),
          gridCell('Harga @ (Rp)', { bold: true, align: AlignmentType.RIGHT, width: 17 }),
          gridCell('Jumlah (Rp)', { bold: true, align: AlignmentType.RIGHT, width: 19 }),
          gridCell('Hasil Pemeriksaan', { bold: true, align: AlignmentType.CENTER, width: 15 }),
        ],
      }),
      ...itemRows,
      totalRow,
    ],
  });

  const sigTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      new TableRow({
        children: [
          cell([emptyP()], { width: 55 }),
          signatureBlock('Ketua Penanggung Jawab Barang/Aset,', pengurusBarang?.nama || '', pengurusBarang?.nip || '', tgl, 45),
        ],
      }),
    ],
  });

  return [
    ...kop,
    p('Lampiran Berita Acara Penerimaan Hasil Pekerjaan/Pemeriksaan Barang', { bold: true, underline: true, align: AlignmentType.CENTER, size: 26 }),
    emptyP(160),
    itemTable,
    sigTable,
  ];
}

async function buildDocument(type: DocType, bpu: BpuFull, pejabat: Record<string, Pejabat>): Promise<Document> {
  const needsKop = type === 'order' || type === 'berita-acara' || type === 'lampiran';
  const kop = needsKop ? await kopSurat() : [];

  let children: (Table | Paragraph)[] = [];
  switch (type) {
    case 'order': children = buildOrderDoc(bpu, pejabat, kop); break;
    case 'tanda-terima': children = buildTandaTerimaDoc(bpu, pejabat, kop); break;
    case 'faktur': children = buildFakturDoc(bpu, pejabat, kop); break;
    case 'berita-acara': children = buildBeritaAcaraDoc(bpu, pejabat, kop); break;
    case 'lampiran': children = buildLampiranDoc(bpu, pejabat, kop); break;
  }

  return new Document({
    sections: [{
      properties: {
        page: {
          size: { orientation: PageOrientation.PORTRAIT, width: convertInchesToTwip(8.27), height: convertInchesToTwip(11.69) },
          margin: { top: convertInchesToTwip(0.6), bottom: convertInchesToTwip(0.6), left: convertInchesToTwip(0.6), right: convertInchesToTwip(0.6) },
        },
      },
      children,
    }],
  });
}

export async function downloadWordDoc(bpu: BpuFull, pejabat: Record<string, Pejabat>, type: DocType): Promise<void> {
  const doc = await buildDocument(type, bpu, pejabat);
  const blob = await Packer.toBlob(doc);
  saveAs(blob, `${DOC_FILENAMES[type]}_${bpu.no_bpu}.docx`);
}

export async function downloadWordBatchTandaTerima(bpus: BpuFull[], pejabat: Record<string, Pejabat>): Promise<void> {
  if (bpus.length === 0) return;

  const doc = new Document({
    sections: bpus.map((bpu) => ({
      properties: {
        page: {
          size: { orientation: PageOrientation.PORTRAIT, width: convertInchesToTwip(8.27), height: convertInchesToTwip(11.69) },
          margin: { top: convertInchesToTwip(0.6), bottom: convertInchesToTwip(0.6), left: convertInchesToTwip(0.6), right: convertInchesToTwip(0.6) },
        },
      },
      children: buildTandaTerimaDoc(bpu, pejabat, []),
    })),
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `Tanda_Penerimaan_${bpus.length}_BPU.docx`);
}

export async function downloadWordBundle(bpu: BpuFull, pejabat: Record<string, Pejabat>): Promise<void> {
  const allTypes: DocType[] = ['order', 'tanda-terima', 'faktur', 'berita-acara', 'lampiran'];
  const sections = await Promise.all(
    allTypes.map(async (type) => {
      const needsKop = type === 'order' || type === 'berita-acara' || type === 'lampiran';
      const kop = needsKop ? await kopSurat() : [];
      let children: (Table | Paragraph)[] = [];
      switch (type) {
        case 'order': children = buildOrderDoc(bpu, pejabat, kop); break;
        case 'tanda-terima': children = buildTandaTerimaDoc(bpu, pejabat, kop); break;
        case 'faktur': children = buildFakturDoc(bpu, pejabat, kop); break;
        case 'berita-acara': children = buildBeritaAcaraDoc(bpu, pejabat, kop); break;
        case 'lampiran': children = buildLampiranDoc(bpu, pejabat, kop); break;
      }
      return { children };
    }),
  );

  const doc = new Document({
    sections: sections.map((s) => ({
      properties: {
        page: {
          size: { orientation: PageOrientation.PORTRAIT, width: convertInchesToTwip(8.27), height: convertInchesToTwip(11.69) },
          margin: { top: convertInchesToTwip(0.6), bottom: convertInchesToTwip(0.6), left: convertInchesToTwip(0.6), right: convertInchesToTwip(0.6) },
        },
      },
      children: s.children,
    })),
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `Paket_SPJ_${bpu.no_bpu}.docx`);
}
