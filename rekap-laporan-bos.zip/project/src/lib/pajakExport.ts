import {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  WidthType, AlignmentType, BorderStyle, PageOrientation, ImageRun,
  convertInchesToTwip,
} from 'docx';
import { saveAs } from 'file-saver';
import { PajakFull, DetailBarang, BpuDocument } from '@/lib/types';
import { formatAngka, terbilang } from '@/lib/terbilang';

const BLACK = '000000';
const GRID = 'BFBFBF';
const NO_BORDER = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' } as const;
const GRID_BORDER = { style: BorderStyle.SINGLE, size: 1, color: GRID } as const;
const ALL_BORDERS = { top: GRID_BORDER, bottom: GRID_BORDER, left: GRID_BORDER, right: GRID_BORDER };
const NO_CELL_BORDERS = { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER };

const SHEET_TABS = [
  { label: '1. Pesanan Order', color: 'D6E4F0' },
  { label: '2. KWITANSI', color: 'FFF2CC' },
  { label: '3. Faktur', color: 'E2EFDA' },
  { label: '4. Tanda Bukti Pembayaran', color: 'FCE4D6' },
  { label: 'BA-PBR', color: 'D9D9D9' },
  { label: '5. Lampiran', color: 'DDEBF7' },
];

function p(text: string, opts?: { bold?: boolean; size?: number; align?: (typeof AlignmentType)[keyof typeof AlignmentType]; underline?: boolean; color?: string }): Paragraph {
  return new Paragraph({
    alignment: opts?.align,
    children: [new TextRun({ text, bold: opts?.bold, size: opts?.size ?? 20, underline: opts?.underline ? {} : undefined, color: opts?.color ?? BLACK })],
    spacing: { after: 40 },
  });
}

function emptyP(after = 40): Paragraph {
  return new Paragraph({ children: [new TextRun({ text: '' })], spacing: { after } });
}

function cell(children: Paragraph[], opts?: { width?: number; borders?: typeof ALL_BORDERS; shading?: string; columnSpan?: number }): TableCell {
  return new TableCell({
    children,
    width: opts?.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
    borders: opts?.borders ?? NO_CELL_BORDERS,
    margins: { top: 30, bottom: 30, left: 60, right: 60 },
    columnSpan: opts?.columnSpan,
    shading: opts?.shading ? { fill: opts.shading } : undefined,
  });
}

function gridCell(text: string, opts?: { bold?: boolean; align?: (typeof AlignmentType)[keyof typeof AlignmentType]; width?: number; shading?: string }): TableCell {
  return cell([p(text, { bold: opts?.bold, align: opts?.align, size: 18 })], { borders: ALL_BORDERS, width: opts?.width, shading: opts?.shading });
}

function formatDate(dateStr: string): string {
  if (!dateStr) return '-';
  return new Date(dateStr).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
}

function getStorageUrl(filePath: string): string {
  return `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/bpu-documents/${filePath}`;
}

async function fetchImageBuffer(url: string): Promise<ArrayBuffer | null> {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    return await res.arrayBuffer();
  } catch {
    return null;
  }
}

function getDocxImageType(fileType: string): 'png' | 'jpg' | 'jpeg' | 'gif' | 'bmp' {
  if (fileType.includes('png')) return 'png';
  if (fileType.includes('jpeg') || fileType.includes('jpg')) return 'jpg';
  return 'png';
}

// Column widths (percentages) — with photo column
const COLS_WITH_PHOTO = [
  { key: 'no', width: 4 },
  { key: 'photo', width: 12 },
  { key: 'nama', width: 18 },
  { key: 'jumlah', width: 7 },
  { key: 'satuan', width: 8 },
  { key: 'harga', width: 11 },
  { key: 'dpp', width: 11 },
  { key: 'jenis', width: 9 },
  { key: 'nominal', width: 10 },
  { key: 'total', width: 10 },
];

// Column widths — without photo column
const COLS_NO_PHOTO = [
  { key: 'no', width: 5 },
  { key: 'nama', width: 22 },
  { key: 'jumlah', width: 8 },
  { key: 'satuan', width: 9 },
  { key: 'harga', width: 13 },
  { key: 'dpp', width: 13 },
  { key: 'jenis', width: 10 },
  { key: 'nominal', width: 10 },
  { key: 'total', width: 10 },
];

// ============================================================
// WORD EXPORT
// ============================================================
async function buildPajakWordDoc(
  pajak: PajakFull,
  items: DetailBarang[],
  photos: BpuDocument[],
): Promise<(Table | Paragraph)[]> {
  const hasPhotos = photos.length > 0;
  const cols = hasPhotos ? COLS_WITH_PHOTO : COLS_NO_PHOTO;
  const colCount = cols.length;

  // Header info table
  const headerInfo = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER, insideHorizontal: NO_BORDER, insideVertical: NO_BORDER },
    rows: [
      new TableRow({ children: [
        cell([p('Nomor Pajak', { size: 18 })], { width: 20 }),
        cell([p(`: ${pajak.tax_number}`, { size: 18 })], { width: 30 }),
        cell([p('No. BPU', { size: 18 })], { width: 20 }),
        cell([p(`: ${pajak.bpu_number}`, { size: 18 })], { width: 30 }),
      ]}),
      new TableRow({ children: [
        cell([p('NTPN', { size: 18 })]),
        cell([p(`: ${pajak.ntpn || '-'}`, { size: 18 })]),
        cell([p('Tanggal Setor', { size: 18 })]),
        cell([p(`: ${formatDate(pajak.tanggal_setor)}`, { size: 18 })]),
      ]}),
      new TableRow({ children: [
        cell([p('Jenis Pajak', { size: 18 })]),
        cell([p(`: ${pajak.jenis_pajak}`, { size: 18 })]),
        cell([p('Status', { size: 18 })]),
        cell([p(`: ${pajak.status}`, { size: 18 })]),
      ]}),
    ],
  });

  // Merged title row
  const titleRow = new TableRow({
    children: [
      cell(
        [p('TANDA BUKTI PEMBAYARAN / PEMBELIAN ( FAKTUR )', { bold: true, align: AlignmentType.CENTER, size: 22 })],
        { borders: ALL_BORDERS, shading: 'F2F2F2', columnSpan: colCount },
      ),
    ],
  });

  // Header row
  const headerCells: TableCell[] = cols.map((col) => {
    const labels: Record<string, string> = {
      no: 'No',
      photo: 'Gambar/Foto Barang',
      nama: 'Nama Barang',
      jumlah: 'Jumlah',
      satuan: 'Satuan',
      harga: 'Harga Satuan',
      dpp: 'DPP',
      jenis: 'Jenis Pajak',
      nominal: 'Nominal Pajak',
      total: 'Total Akhir',
    };
    return gridCell(labels[col.key], { bold: true, align: AlignmentType.CENTER, width: col.width, shading: 'E7E6E6' });
  });
  const headerRow = new TableRow({ tableHeader: true, children: headerCells });

  // Data rows — stored as cell arrays so we can replace photo cells after async load
  const dataRowCells: TableCell[][] = items.map((item, idx) => {
    const lineTotal = (Number(item.banyak_nya) || 0) * (Number(item.harga_satuan) || 0);
    const cells: TableCell[] = [];

    cells.push(gridCell(String(idx + 1), { align: AlignmentType.CENTER, width: cols[0].width }));

    if (hasPhotos) {
      const photo = photos[idx];
      if (photo) {
        cells.push(cell([p('(foto)', { align: AlignmentType.CENTER, size: 16 })], { borders: ALL_BORDERS, width: cols[1].width }));
      } else {
        cells.push(cell([p('', { size: 16 })], { borders: ALL_BORDERS, width: cols[1].width }));
      }
    }

    const namaIdx = hasPhotos ? 2 : 1;
    const jumlahIdx = hasPhotos ? 3 : 2;
    const satuanIdx = hasPhotos ? 4 : 3;
    const hargaIdx = hasPhotos ? 5 : 4;
    const dppIdx = hasPhotos ? 6 : 5;
    const jenisIdx = hasPhotos ? 7 : 6;
    const nominalIdx = hasPhotos ? 8 : 7;
    const totalIdx = hasPhotos ? 9 : 8;

    cells.push(gridCell(item.nama_barang, { width: cols[namaIdx].width }));
    cells.push(gridCell(String(item.banyak_nya), { align: AlignmentType.CENTER, width: cols[jumlahIdx].width }));
    cells.push(gridCell(item.satuan, { align: AlignmentType.CENTER, width: cols[satuanIdx].width }));
    cells.push(gridCell(formatAngka(Number(item.harga_satuan) || 0), { align: AlignmentType.RIGHT, width: cols[hargaIdx].width }));
    cells.push(gridCell(formatAngka(pajak.dasar_pengenaan_pajak), { align: AlignmentType.RIGHT, width: cols[dppIdx].width }));
    cells.push(gridCell(pajak.jenis_pajak, { align: AlignmentType.CENTER, width: cols[jenisIdx].width }));
    cells.push(gridCell(formatAngka(pajak.nominal_pajak), { align: AlignmentType.RIGHT, width: cols[nominalIdx].width }));
    cells.push(gridCell(formatAngka(lineTotal), { align: AlignmentType.RIGHT, width: cols[totalIdx].width }));

    return cells;
  });

  // Async image loading for photo cells
  if (hasPhotos) {
    for (let i = 0; i < Math.min(items.length, photos.length); i++) {
      const photo = photos[i];
      if (!photo) continue;
      const url = getStorageUrl(photo.file_path);
      const buf = await fetchImageBuffer(url);
      if (buf) {
        const imgType = getDocxImageType(photo.file_type);
        const imgPara = new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new ImageRun({
            data: new Uint8Array(buf),
            transformation: { width: 60, height: 60 },
            type: imgType,
          } as any)],
        });
        dataRowCells[i][1] = cell([imgPara], { borders: ALL_BORDERS, width: cols[1].width });
      }
    }
  }

  const dataRows: TableRow[] = dataRowCells.map((cells) => new TableRow({ children: cells }));

  // Total row
  const grandTotal = items.reduce((sum, item) => sum + (Number(item.banyak_nya) || 0) * (Number(item.harga_satuan) || 0), 0);
  const totalRow = new TableRow({
    children: [
      cell([p('TOTAL', { bold: true, align: AlignmentType.RIGHT, size: 18 })], { borders: ALL_BORDERS, shading: 'F2F2F2', columnSpan: colCount - 1 }),
      gridCell(formatAngka(grandTotal), { bold: true, align: AlignmentType.RIGHT, width: cols[cols.length - 1].width, shading: 'F2F2F2' }),
    ],
  });

  // Main table
  const mainTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [titleRow, headerRow, ...dataRows, totalRow],
  });

  // Sheet tabs footer
  const sheetTabCells: TableCell[] = SHEET_TABS.map((tab) =>
    cell([p(tab.label, { bold: true, size: 16, align: AlignmentType.CENTER })], { borders: ALL_BORDERS, shading: tab.color }),
  );
  const sheetTabRow = new TableRow({ children: sheetTabCells });
  const sheetTabTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [sheetTabRow],
  });

  return [
    headerInfo,
    emptyP(120),
    mainTable,
    emptyP(200),
    p('Terbilang: ' + terbilang(pajak.nominal_pajak), { size: 18 }),
    emptyP(300),
    sheetTabTable,
  ];
}

export async function downloadPajakWord(
  pajak: PajakFull,
  items: DetailBarang[],
  photos: BpuDocument[],
): Promise<void> {
  const children = await buildPajakWordDoc(pajak, items, photos);
  const doc = new Document({
    sections: [{
      properties: {
        page: {
          size: { orientation: PageOrientation.PORTRAIT, width: convertInchesToTwip(8.27), height: convertInchesToTwip(11.69) },
          margin: { top: convertInchesToTwip(0.5), bottom: convertInchesToTwip(0.5), left: convertInchesToTwip(0.5), right: convertInchesToTwip(0.5) },
        },
      },
      children,
    }],
  });
  const blob = await Packer.toBlob(doc);
  saveAs(blob, `Bukti_Pajak_${pajak.tax_number}.docx`);
}

// ============================================================
// PDF EXPORT (HTML print)
// ============================================================
export function exportPajakPDF(
  pajak: PajakFull,
  items: DetailBarang[],
  photos: BpuDocument[],
): void {
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;

  const hasPhotos = photos.length > 0;

  // Header info
  const headerInfo = `
    <table class="info-table">
      <tr><td class="info-label">Nomor Pajak</td><td>: ${pajak.tax_number}</td>
          <td class="info-label">No. BPU</td><td>: ${pajak.bpu_number}</td></tr>
      <tr><td class="info-label">NTPN</td><td>: ${pajak.ntpn || '-'}</td>
          <td class="info-label">Tanggal Setor</td><td>: ${formatDate(pajak.tanggal_setor)}</td></tr>
      <tr><td class="info-label">Jenis Pajak</td><td>: ${pajak.jenis_pajak}</td>
          <td class="info-label">Status</td><td>: ${pajak.status}</td></tr>
    </table>
  `;

  // Column definitions
  const photoCol = hasPhotos ? '<th class="col-photo">Gambar/Foto Barang</th>' : '';
  const colCount = hasPhotos ? 10 : 9;

  // Header row
  const tableHeader = `
    <tr>
      <th class="col-no">No</th>
      ${photoCol}
      <th class="col-name">Nama Barang</th>
      <th class="col-qty">Jumlah</th>
      <th class="col-unit">Satuan</th>
      <th class="col-price">Harga Satuan</th>
      <th class="col-dpp">DPP</th>
      <th class="col-jenis">Jenis Pajak</th>
      <th class="col-nominal">Nominal Pajak</th>
      <th class="col-total">Total Akhir</th>
    </tr>
  `;

  // Data rows
  const grandTotal = items.reduce((sum, item) => sum + (Number(item.banyak_nya) || 0) * (Number(item.harga_satuan) || 0), 0);

  const dataRows = items.map((item, idx) => {
    const lineTotal = (Number(item.banyak_nya) || 0) * (Number(item.harga_satuan) || 0);
    const photo = hasPhotos ? photos[idx] : null;
    const photoCell = hasPhotos
      ? `<td class="cell-photo">${photo ? `<img src="${getStorageUrl(photo.file_path)}" alt="${photo.file_name}" />` : ''}</td>`
      : '';
    return `
      <tr>
        <td class="cell-center">${idx + 1}</td>
        ${photoCell}
        <td class="cell-left">${item.nama_barang}</td>
        <td class="cell-center">${item.banyak_nya}</td>
        <td class="cell-center">${item.satuan}</td>
        <td class="cell-right">${formatAngka(Number(item.harga_satuan) || 0)}</td>
        <td class="cell-right">${formatAngka(pajak.dasar_pengenaan_pajak)}</td>
        <td class="cell-center">${pajak.jenis_pajak}</td>
        <td class="cell-right">${formatAngka(pajak.nominal_pajak)}</td>
        <td class="cell-right">${formatAngka(lineTotal)}</td>
      </tr>
    `;
  }).join('');

  // Total row
  const totalRow = `
    <tr class="total-row">
      <td colspan="${colCount - 1}" class="cell-right total-label">TOTAL</td>
      <td class="cell-right total-value">${formatAngka(grandTotal)}</td>
    </tr>
  `;

  // Sheet tabs
  const sheetTabs = SHEET_TABS.map((tab) =>
    `<span class="sheet-tab" style="background-color: #${tab.color};">${tab.label}</span>`
  ).join('');

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Tanda Bukti Pembayaran - ${pajak.tax_number}</title>
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        @page { size: auto; margin: 15mm; }
        html, body { margin: 0; padding: 0; background: #fff; }
        body { font-family: 'Calibri', 'Segoe UI', sans-serif; width: 100%; color: #333; line-height: 1.25; }
        table, img { max-width: 100%; }
        tr, img { break-inside: avoid; page-break-inside: avoid; }
        .info-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 12px; }
        .info-table td { padding: 3px 8px; }
        .info-label { font-weight: 600; width: 12%; white-space: nowrap; }
        .info-table td:nth-child(3) { font-weight: 600; width: 12%; }
        .main-table { width: 100%; border-collapse: collapse; font-size: 11px; table-layout: fixed; }
        .main-table th, .main-table td { border: 1px solid #BFBFBF; padding: 4px 6px; overflow: hidden; text-overflow: ellipsis; }
        .main-table th { background-color: #E7E6E6; font-weight: 700; text-align: center; vertical-align: middle; }
        .title-row td { background-color: #F2F2F2; font-weight: bold; font-size: 14px; text-align: center; padding: 8px; }
        .col-no { width: 4%; }
        .col-photo { width: 12%; }
        .col-name { width: ${hasPhotos ? '18%' : '22%'}; }
        .col-qty { width: ${hasPhotos ? '7%' : '8%'}; }
        .col-unit { width: ${hasPhotos ? '8%' : '9%'}; }
        .col-price { width: ${hasPhotos ? '11%' : '13%'}; }
        .col-dpp { width: ${hasPhotos ? '11%' : '13%'}; }
        .col-jenis { width: ${hasPhotos ? '9%' : '10%'}; }
        .col-nominal { width: ${hasPhotos ? '10%' : '10%'}; }
        .col-total { width: ${hasPhotos ? '10%' : '10%'}; }
        .cell-center { text-align: center; }
        .cell-left { text-align: left; }
        .cell-right { text-align: right; }
        .cell-photo { text-align: center; padding: 2px; }
        .cell-photo img { max-width: 60px; max-height: 60px; object-fit: cover; }
        .total-row td { background-color: #F2F2F2; font-weight: bold; }
        .total-label { font-size: 12px; }
        .total-value { font-size: 12px; }
        .terbilang { margin-top: 12px; font-size: 12px; font-style: italic; }
        .sheet-tabs { margin-top: 40px; display: flex; gap: 2px; border-top: 2px solid #ccc; padding-top: 4px; }
        .sheet-tab { padding: 4px 12px; font-size: 10px; font-weight: 600; border: 1px solid #BFBFBF; border-radius: 3px 3px 0 0; white-space: nowrap; }
        @media print {
          body { width: 100%; }
          .sheet-tab { border: 1px solid #999; }
          h1, h2, h3, p { orphans: 3; widows: 3; }
        }
      </style>
    </head>
    <body>
      ${headerInfo}
      <table class="main-table">
        <tr class="title-row"><td colspan="${colCount}">TANDA BUKTI PEMBAYARAN / PEMBELIAN ( FAKTUR )</td></tr>
        ${tableHeader}
        ${dataRows}
        ${totalRow}
      </table>
      <p class="terbilang">Terbilang: ${terbilang(pajak.nominal_pajak)}</p>
      <div class="sheet-tabs">${sheetTabs}</div>
      <script>window.onload = function() { setTimeout(function() { window.print(); }, 500); }</script>
    </body>
    </html>
  `);
  printWindow.document.close();
}
